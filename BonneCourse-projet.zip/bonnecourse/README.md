# Bonne Course

Appli Android tout-en-un pour un chauffeur VTC en **SASU**, avec une **Tesla Model Y Grande Autonomie Propulsion**
au nom d'un proche et **louée à la société** (pas d'indemnités kilométriques : la SASU paie loyer, assurance, recharge, entretien).

## Les 5 onglets (version 2)

- **Rouler** : la bulle, la journée (encaissé, courses, km, €/h), démarrer une course privée, courses à faire signer, trajets à classer.
- **Courses** : la boîte noire. Chaque course Uber, Bolt ou privée est enregistrée à la seconde (acceptation, client à bord, dépose),
  avec les lieux, les km, la plateforme reconnue sur l'offre, le verdict de la bulle et le **tracé GPS**. Détail d'une course :
  dessin du trajet (orange = approche, vert = client à bord), ouverture dans Google Maps, export GPX.
- **Frais** : recharge Tesla, loyer, assurance, repas, péages, lavage, entretien, téléphone, abonnements, bureau, comptable…
  Montant TTC, TVA, note, photo du ticket, frais qui se répètent chaque mois. Tant qu'un poste n'est pas saisi, il est estimé.
- **Mon mois** : net dans la poche, graphique de l'encaissé sur 6 mois par plateforme (Uber, Bolt, Privé), frais par poste,
  « Te payer au mieux » (salaire / dividendes), kilomètres, export tableur, rapprochement des relevés Uber/Bolt.
- **Réglages** : société (imprimée sur les factures), voiture, exigence de la bulle, impôts, détection automatique des trajets.

## Carnet kilométrique (justificatif)

- GPS « fused » de Google, une position par seconde ; un point de tracé tous les 6 m : le tracé suit les rues.
- Chaque course : km d'approche et km client à bord au mètre près, heures à la seconde, lieux, tracé sur un vrai plan (OpenStreetMap).
- Domicile (Réglages → Mon domicile) : bulle lancée devant chez soi = « Départ du domicile » jusqu'à la 1re course ;
  appui long sur la bulle → « Rentrer au domicile » : le trajet se termine tout seul devant chez soi.
- Export du mois : section « Carnet kilométrique » chronologique (départ, courses, retour), valeur au barème 2026.

## Supprimer

Appui long sur une course, corbeille en haut du détail, bouton rouge en bas du détail, ou « Sélectionner pour supprimer »
(plusieurs d'un coup). Toujours avec confirmation. Une course facturée ne se supprime pas.

## Verdict de la bulle

Vert = **ACCEPTER**, orange = **MOYEN** (à prendre si rien de mieux), rouge = **REFUSER**. La tuile affiche le net, la
**rentabilité** (part du gain qui reste après recharge, usure, loyer, assurance et TVA 10 %), le €/h et le €/km.

## Course privée et facture

1. Onglet Rouler → **Démarrer une course privée** (ou appui long sur la bulle → Course client privé). La bulle suit l'approche,
   puis « Client à bord », puis « Course terminée ». Ou **Saisir une course à la main**.
2. À l'arrivée, l'écran de facture s'ouvre : heures de prise en charge et de dépose, lieux, km, prix, paiement, date de réservation
   préalable, coordonnées du client (carnet des clients habituels, client professionnel avec SIREN).
3. **Signature du client obligatoire** pour valider. La facture reçoit un numéro sans trou (F-2026-0001…).
4. PDF avec les mentions légales et la signature, puis **Outlook s'ouvre avec le PDF joint**, l'adresse du client, l'objet et un
   message de remerciement (modifiable dans Réglages). Sans Outlook, le téléphone propose une autre appli. Bouton « Télécharger ».
5. Après validation, la course ne se modifie plus ; les coordonnées du client peuvent être corrigées (le PDF est refait).

Les coordonnées de la société sont demandées avant la première facture (nom, adresse, SIRET, n° d'inscription au registre VTC).

---

Appli Android pour chauffeurs VTC. Une bulle reste à l'écran par-dessus Uber, Bolt ou Heetch.
Quand une course sonne, tu touches la bulle : l'appli lit l'offre à l'écran et affiche une tuile
**ACCEPTER / À VOIR / REFUSER** avec un score sur 10, le bénéfice net, le €/h réel et le €/km.

La lecture se fait sur le téléphone (Google ML Kit, hors ligne). Aucune image n'est enregistrée ni envoyée.

## Obtenir l'APK

Chaque envoi sur la branche `main` compile l'appli automatiquement (onglet **Actions**).
L'APK est publié dans **Releases** : `BonneCourse.apk`.

## Installer sur le téléphone

1. Ouvre la page Releases du dépôt sur le téléphone et télécharge `BonneCourse.apk`.
2. Ouvre le fichier. Android demande d'autoriser l'installation depuis le navigateur : accepte.
3. Si Play Protect avertit d'une appli inconnue : « Plus de détails » puis « Installer quand même ».

Les mises à jour s'installent par-dessus (même clé de signature à chaque compilation).

## Utiliser

1. Ouvre Bonne Course, renseigne **Mon véhicule** (énergie, conso, prix, charges, objectifs) puis **Enregistrer**.
2. **Autoriser l'affichage par-dessus les applis**.
3. **Lancer la bulle**, puis choisis **Écran entier** quand Android demande l'autorisation de capture.
4. Ouvre Uber. Quand une offre s'affiche, touche la bulle. La tuile apparaît en haut de l'écran
   pendant 15 secondes (touche-la pour la fermer). Le téléphone vibre : 1 fois = accepter,
   2 fois = à voir, 1 longue = refuser.
5. Pour arrêter : notification « Bonne Course est prête » → **Arrêter**.

Android redemande l'autorisation de capture à chaque lancement de la bulle : c'est une règle du système.

**Tester sans course** : fais une capture d'écran d'une offre, puis « Choisir une capture » dans l'appli.
Le texte lu s'affiche sous la tuile, pratique pour vérifier la lecture.

## Kilométrage et frais

Quand la bulle est lancée, le GPS compte tous les km roulés (autorisation « position précise » demandée au lancement).

1. Sur la tuile, touche **J'accepte** : le compteur de la course démarre (anneau orange = approche).
2. Touche la bulle, puis **Client à bord** (anneau vert).
3. Touche la bulle, puis **Course terminée** : la course est enregistrée à la minute et au mètre près.
   Une offre acceptée pendant une course est enchaînée automatiquement.

Dans l'appli, la carte **Kilométrage et frais** donne pour chaque mois :
km professionnels (client à bord, approche, à vide entre courses), nombre de courses, temps,
coût réel de ces km, et le montant au **barème kilométrique fiscal** (barème 2026, revenus 2025,
calculé sur le cumul de l'année car il est dégressif). Bouton **Exporter le relevé du mois** :
fichier tableur (.csv, s'ouvre dans Excel) avec chaque course, les km par jour et la synthèse.
Appui long deux fois sur une course pour la supprimer.

**Appui long sur la bulle** : menu avec
- **Course client privé** : client réservé en direct, hors appli. Même compteur (approche, client à bord, terminée),
  comptée en km pro. Le montant se saisit ensuite dans Bonne Course en touchant la course dans la liste du mois.
- **Trajet perso** : courses, famille, retour à la maison. L'anneau devient gris et les km sont rangés à part,
  jamais comptés dans les indemnités. Appui sur la bulle puis **Reprendre le service** pour revenir en pro.

Tout ce qui est roulé bulle active, hors mode perso, compte comme km pro. Lancer la bulle remet toujours en service.
Le relevé affiche les km perso exclus et la part professionnelle.

**Régime fiscal** (réglage dans la carte Kilométrage) :
- **SASU / SAS : indemnités km** (par défaut). Voiture personnelle à ton nom : ta SASU te rembourse
  chaque mois le montant affiché. Non imposable et sans cotisations pour toi, déductible pour la SASU.
  En échange, la SASU ne paie ni la recharge, ni l'assurance, ni l'entretien de la voiture (le barème les couvre).
  Péages et parkings peuvent s'ajouter sur justificatif. Le barème électrique (voiture 100 % électrique) est appliqué automatiquement.
- **Micro-entreprise** : frais kilométriques non déductibles (abattement forfaitaire de 50 %), montant affiché à titre indicatif.

Chaque course enregistre le lieu d'acceptation, de prise en charge et d'arrivée (rue et ville, avec coordonnées GPS),
pour que l'export serve de justificatif à la note de frais.

## Affichage simple

Chaque carte montre l'essentiel : un gros chiffre et trois ou quatre lignes. Le reste est replié derrière
« Voir le détail », et les réglages derrière « Réglages » / « Ma situation ».
Le net du mois (« Ce que tu gagnes ») utilise la même meilleure option que « Te payer au mieux ».

## Trajets détectés automatiquement

Réglages de la carte Kilométrage → **Détecter mes trajets automatiquement** (autorisations : position
« Toujours autoriser », activité physique, notifications). Ensuite, quand la bulle n'est pas lancée :
- le téléphone détecte qu'on roule en voiture et lance le compteur GPS tout seul ;
- le trajet se termine après 6 minutes à l'arrêt, ou 2 minutes après être sorti de la voiture
  (un feu rouge ou un bouchon ne coupent pas le trajet) ; les trajets de moins de 500 m sont ignorés ;
- une notification demande **Pro** ou **Perso** ; on peut aussi classer depuis l'appli (« trajets à classer »)
  et changer d'avis plus tard. Les km vont dans les km pro ou perso du jour.
Quand la bulle est lancée, elle prend le relais : la détection automatique ne fait rien.

## Ce que tu gagnes vraiment

La carte **Ce que tu gagnes vraiment** part de ce que versent Uber/Bolt et les clients privés, et descend jusqu'à l'argent
dans ta poche, mois par mois (estimation à valider avec le comptable) :
- TVA 10 % sur le prix payé par le client (commission comprise ; la TVA sur la commission Uber est autoliquidée),
  TVA récupérée sur la recharge et l'entretien ;
- voiture : loyer + assurance + recharge + entretien (voiture louée à la société) ou indemnités km (voiture à ton nom) ;
- frais fixes de la société (comptable, banque, téléphone…) ;
- impôt sur les sociétés 15 % jusqu'à 42 500 € de bénéfice annuel, 25 % au-delà (calculé sur le cumul de l'année) ;
- puis deux façons de sortir l'argent, comparées : **dividendes** (flat tax 31,4 %, aucune cotisation URSSAF)
  ou **salaire** (cotisations URSSAF ≈ 79 % du net, impôt selon ta tranche). Le plus avantageux est mis en avant.
- En micro-entreprise : cotisations URSSAF 21,2 % du chiffre d'affaires et impôt estimé.

L'export du mois contient aussi cette synthèse financière.

## Optimisation fiscale

La carte **Optimisation fiscale** calcule, sur une année complète, la façon la plus rentable de se payer, légalement :
- elle teste tous les salaires possibles (par pas de 50 €), le reste du bénéfice partant en dividendes, et garde celui
  qui laisse le plus d'argent dans la poche ;
- pour les dividendes, elle choisit automatiquement entre la flat tax 31,4 % et le barème progressif (case 2OP),
  avec l'abattement de 40 % et la CSG déductible ;
- impôt sur le revenu du foyer : barème 2026, parts fiscales, plafonnement du quotient familial, décote, autres revenus du foyer ;
- option « valider 4 trimestres de retraite » : salaire minimum de 7 212 € brut par an, et ce que ça coûte ;
- comparaison des montages : voiture louée à la SASU, SASU + indemnités km, micro-entreprise (plafond 83 600 € HT) ;
- liste des leviers à activer (ACRE, TVA, charges déductibles, réserve dans la société, PER…).

Calcul sur la projection des courses de l'année, ou sur une prévision (versements par mois, km pro par mois).

## Rapprochement Uber / Bolt

Exporte le relevé de gains en CSV depuis le site chauffeur de la plateforme et importe-le dans la carte
**Rapprochement**. Les colonnes date, montant et identifiant de course sont reconnues automatiquement
(fichiers français ou anglais, séparateur « ; » ou « , »). Résultat :
- courses identiques ;
- montants différents (pourboire, majoration) → bouton pour corriger avec le montant réel ;
- courses payées mais pas suivies par la bulle → bouton pour les ajouter au chiffre d'affaires ;
- courses suivies mais absentes du relevé (annulée, autre plateforme) ;
- retenues et ajustements de la plateforme.

Si un fichier n'est pas reconnu, l'appli affiche les colonnes trouvées : envoie-les pour ajouter ce format.

## Comment le verdict est calculé

- Coût par km = carburant (conso × prix) + entretien + part des charges fixes (charges ÷ km par mois).
- Bénéfice net = gain − coût × (km d'approche + km de course).
- €/h réel = bénéfice net ÷ (minutes d'approche + minutes de course).
- Score /10 = 60 % sur le €/h comparé à ton objectif, 40 % sur le €/km brut comparé à ton minimum,
  −1 si plus de 40 % du trajet se fait sans client. 7 et plus = accepter, 5 à 7 = à voir, moins = refuser.
  Une course à perte est toujours « refuser ».

## Fichiers

- `Analyzer.kt` : calcul du verdict
- `Mileage.kt` : barème kilométrique, compteur GPS, suivi de course, relevé mensuel et export
- `OfferParser.kt` : lecture du prix, des minutes et des km dans le texte de l'écran
- `BubbleService.kt` : bulle, capture d'écran, tuile
- `Reader.kt` : reconnaissance du texte (ML Kit)
- `MainActivity.kt` : réglages, test sur capture, historique
