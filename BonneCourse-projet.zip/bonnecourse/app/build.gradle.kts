plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "fr.bonnecourse"
    compileSdk = 34

    defaultConfig {
        applicationId = "fr.bonnecourse"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Même clé à chaque compilation : les mises à jour s'installent par-dessus sans désinstaller.
    signingConfigs {
        create("perso") {
            storeFile = file("bonnecourse.keystore")
            storePassword = "bonnecourse"
            keyAlias = "bonnecourse"
            keyPassword = "bonnecourse"
        }
    }

    buildTypes {
        debug { signingConfig = signingConfigs.getByName("perso") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // Lecture du texte à l'écran, directement sur le téléphone (hors ligne, gratuit)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Détection « en voiture » pour lancer le compteur automatiquement
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
