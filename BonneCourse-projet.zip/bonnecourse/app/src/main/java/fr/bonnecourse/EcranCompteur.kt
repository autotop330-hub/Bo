package fr.bonnecourse

import android.graphics.BitmapFactory
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Journal › Compteur : le véhicule, ses relevés du mois (envoyés par la voiture ou en photo),
 * le bilan compteur / GPS, et le rapport mensuel PDF à présenter en cas de contrôle.
 */
class EcranCompteur(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        col.addView(EcranVehicules.carteActif(a))
        if (store.vehiculeActif.connectee && store.teslaActive) EcranTesla.etat(a)?.let { col.addView(it) }
        else col.addView(relever())
        col.addView(bilan())
        col.addView(rapport())
        col.addView(releves())
    }

    /** Véhicule sans connexion : photo du compteur (ou saisie). */
    private fun relever(): View {
        val c = W.carte(a, "Relever le compteur")
        val d = Compteur.dernier(store)
        c.addView(if (d != null) W.ligne(a, "Dernier relevé", "${Compteur.km(d.odoKm)} · " +
            SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date(d.t)), true) else
            Ui.text(a, "Aucun relevé pour ce véhicule.", 15f, Ui.WARN, true))
        if (store.vehiculeActif.connectee && !store.teslaActive)
            c.addView(W.aide(a, "Connecte la Tesla dans Réglages › Ma Tesla : le compteur sera relevé tout seul."))
        c.addView(W.bouton(a, "📷  Photographier le compteur", true) { Compteur.photographier(a) })
        c.addView(W.bouton(a, "Saisir à la main") { Compteur.saisir(a, null, null, null, null) })
        c.addView(W.aide(a, "Au début et à la fin de chaque service (la bulle te le rappelle). Le kilométrage est lu sur la photo, " +
            "sur le téléphone ; la photo est gardée comme preuve, avec l'heure exacte."))
        return c
    }

    /** Compteur du mois face au GPS : les deux doivent raconter la même histoire. */
    private fun bilan(): View {
        val c = W.carte(a, "Bilan du mois")
        val b = TeslaAuto.bilanMois(store, a.vueAnnee, a.vueMois)
        val pre = String.format("%04d-%02d", a.vueAnnee, a.vueMois)
        val gpsPro = maxOf(store.service().filterKeys { it.startsWith(pre) }.values.sum(),
            store.rides().filter { a.duMois(it.debut) }.sumOf { it.kmTotal })
        if (b == null) {
            c.addView(W.aide(a, "Au moins deux relevés du compteur dans le mois sont nécessaires (début et fin de service)."))
            c.addView(W.ligne(a, "Km pro mesurés au GPS", "${Analyzer.fmt1(gpsPro)} km", true))
            return c
        }
        store.vehicule(b.vehicule)?.let { c.addView(Ui.text(a, it.libelle, 14f, Ui.MUTED)) }
        c.addView(W.ligne(a, "Premier relevé", Compteur.km(b.premier.odoKm)))
        c.addView(W.ligne(a, "Dernier relevé", Compteur.km(b.dernier.odoKm)))
        c.addView(W.ligne(a, "Km au compteur", "${Analyzer.fmt1(b.total)} km", true))
        if (b.service > 0) {
            c.addView(W.ligne(a, "dont en service (début → fin)", "${Analyzer.fmt1(b.service)} km", couleur = Ui.ACCENT))
            c.addView(W.ligne(a, "dont hors service", "${Analyzer.fmt1(b.horsService)} km"))
            c.addView(W.ligne(a, "Km pro mesurés au GPS", "${Analyzer.fmt1(gpsPro)} km"))
            if (gpsPro > 0) {
                val ecart = (gpsPro - b.service) / b.service * 100
                c.addView(Ui.text(a, (if (abs(ecart) <= 3) "✓ " else "⚠ ") + "Écart GPS / compteur : ${String.format(Locale.FRANCE, "%+.1f", ecart)} %" +
                    if (abs(ecart) <= 3) " · cohérent" else " · vérifie les relevés manquants", 14f, if (abs(ecart) <= 3) Ui.GO else Ui.WARN, true))
            }
        } else c.addView(W.aide(a, "Relève aussi le compteur en début et en fin de service pour séparer les km pro des km perso."))
        TeslaAuto.consommation(store, System.currentTimeMillis() - 30L * 24 * 3600_000)?.let { (conso, k) ->
            c.addView(W.ligne(a, "Conso réelle (30 jours)", String.format(Locale.FRANCE, "%.1f kWh/100 km", conso), couleur = Ui.ACCENT))
            c.addView(W.aide(a, "Mesurée sur ${k.roundToInt()} km de service" + if (store.consoAuto) " · utilisée pour juger les offres" else ""))
        }
        return c
    }

    private fun rapport(): View {
        val c = W.carteVedette(a, "Rapport mensuel")
        c.addView(Ui.text(a, "Le dossier à présenter en cas de contrôle", 17f, Ui.FG, true))
        c.addView(W.aide(a, "Société et véhicule, compteur et GPS, km pro et perso, carnet jour par jour, chaque course, " +
            "trajets hors service, relevés du compteur, frais et attestation à signer. En PDF, prêt à envoyer."))
        c.addView(W.bouton(a, "Créer le rapport de ${W.nomMois(a.vueAnnee, a.vueMois).lowercase()}", true) {
            RapportMensuel.lancer(a, a.vueAnnee, a.vueMois)
        })
        return c
    }

    /** Relevés du mois, avec leur source (voiture, photo, main) ; toucher = voir la photo ; appui long = supprimer. */
    private fun releves(): View {
        val l = store.releves().filter { a.duMois(it.t) }.sortedByDescending { it.t }
        val c = W.carte(a, "Relevés du mois (${l.size})")
        if (l.isEmpty()) { c.addView(W.aide(a, "Aucun relevé ce mois.")); return c }
        val f = SimpleDateFormat("EEE dd/MM · HH:mm", Locale.FRANCE)
        l.take(120).forEach { r ->
            val ligne = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = Ui.box(a, Ui.RAISE, Ui.RAISE, 0, 14)
                val p = Ui.dp(a, 10); setPadding(p, p, p, p)
            }
            if (r.photo.isNotBlank()) {
                val bmp = try { BitmapFactory.decodeFile(r.photo, BitmapFactory.Options().apply { inSampleSize = 8 }) } catch (_: Exception) { null }
                if (bmp != null) ligne.addView(ImageView(a).apply {
                    setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
                    background = Ui.box(a, Ui.SURFACE, Ui.LINE, 1, 10); clipToOutline = true
                }, LinearLayout.LayoutParams(Ui.dp(a, 52), Ui.dp(a, 52)).apply { marginEnd = Ui.dp(a, 12) })
            }
            val t = Ui.vertical(a, 2)
            t.addView(Ui.text(a, "${f.format(Date(r.t))} · ${r.libelle}", 14f, Ui.FG, true))
            t.addView(Ui.text(a, listOfNotNull(r.source, if (r.batterie >= 0) "batterie ${r.batterie.roundToInt()} %" else null,
                r.note.takeIf { it.isNotBlank() && it != "photo du tableau de bord" && it != "saisi à la main" },
                store.vehicule(r.vehicule)?.court?.takeIf { r.vehicule != store.vehiculeActif.id }).joinToString(" · "), 12f, Ui.MUTED))
            ligne.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(Ui.text(a, Compteur.km(r.odoKm), 15f, Ui.ACCENT, true))
            if (r.photo.isNotBlank()) ligne.setOnClickListener { a.voirPhoto(r.photo) }
            ligne.setOnLongClickListener {
                W.confirmer(a, "Supprimer ce relevé ?", "${r.libelle} · ${Compteur.km(r.odoKm)}" + if (r.photo.isNotBlank()) " (et sa photo)" else "", "Supprimer") {
                    store.supprimerReleve(r.t); a.afficher()
                }; true
            }
            c.addView(ligne)
        }
        c.addView(W.aide(a, "Toucher : voir la photo · appui long : supprimer."))
        return c
    }
}

/** Les véhicules : carte du véhicule actif, changement en un geste, ajout (Tesla Model Y, Mercedes EQV…), modification. */
object EcranVehicules {

    fun carteActif(a: MainActivity): View {
        val v = a.store.vehiculeActif
        val c = W.carteVedette(a, "Véhicule")
        c.addView(Ui.text(a, v.modele, 19f, Ui.FG, true))
        c.addView(W.aide(a, listOf(v.immat.ifBlank { "immatriculation à renseigner" }, "${v.places} places", "${W.n(v.batterieKwh)} kWh",
            "${W.n(v.conso)} kWh/100 km").joinToString(" · ")))
        c.addView(W.pastille(a, if (v.connectee) Ui.GO else Ui.ACCENT,
            if (v.connectee) "Compteur envoyé par la voiture" else "Compteur relevé en photo", 13f))
        if (a.store.vehicules().size > 1) c.addView(W.bouton(a, "Changer de véhicule") { choisir(a) })
        return c
    }

    fun choisir(a: MainActivity) {
        val l = a.store.vehicules()
        val actif = a.store.vehiculeActif.id
        AlertDialog.Builder(a).setTitle("Je roule avec…")
            .setItems(l.map { (if (it.id == actif) "✓ " else "") + it.libelle as CharSequence }.toTypedArray()) { _, i ->
                a.store.choisirVehicule(l[i].id)
                a.toast("${l[i].court} : consommation ${W.n(l[i].conso)} kWh/100 km pour juger les offres")
                a.afficher()
            }.setNegativeButton("Annuler", null).show()
    }

    /** Carte des Réglages. */
    fun reglages(a: MainActivity): LinearLayout {
        val store = a.store
        val c = W.carte(a, "Mes véhicules")
        val actif = store.vehiculeActif
        store.vehicules().forEach { v ->
            c.addView(Ui.vertical(a, 2).apply {
                background = Ui.box(a, Ui.RAISE, if (v.id == actif.id) Ui.ACCENT else Ui.RAISE, 1, 16)
                val p = Ui.dp(a, 14); setPadding(p, p, p, p)
                addView(W.ligne(a, v.modele, if (v.id == actif.id) "actif" else "", true, Ui.ACCENT))
                addView(W.aide(a, listOf(v.immat.ifBlank { "sans immatriculation" }, "${W.n(v.conso)} kWh/100 km",
                    if (v.connectee) "relevé par la voiture" else "relevé en photo").joinToString(" · ")))
                setOnClickListener { modifier(a, v) }
            })
        }
        c.addView(W.bouton(a, "Ajouter un véhicule", true) { ajouter(a) })
        c.addView(W.aide(a, "Toucher un véhicule : le modifier ou l'utiliser. Le véhicule actif fixe la consommation des calculs, " +
            "le relevé du compteur et figure sur les factures et le rapport mensuel."))
        return c
    }

    private fun ajouter(a: MainActivity) {
        val m = Modeles.LISTE
        AlertDialog.Builder(a).setTitle("Quel véhicule ?")
            .setItems(m.map { "${it.nom}\n${it.note}" as CharSequence }.toTypedArray()) { _, i ->
                val v = Modeles.creer(m[i])
                a.store.saveVehicule(v)
                modifier(a, v, nouveau = true)
            }.setNegativeButton("Annuler", null).show()
    }

    private fun modifier(a: MainActivity, v: Vehicule, nouveau: Boolean = false) {
        val store = a.store
        val col = Ui.vertical(a, 8).apply { val p = Ui.dp(a, 20); setPadding(p, p, p, p); setBackgroundColor(Ui.BG) }
        col.addView(Ui.text(a, if (nouveau) "Nouveau véhicule" else "Véhicule", 20f, Ui.FG, true))
        val eMod = W.champ(a, col, "Modèle", v.modele, W.NOM)
        val eImm = W.champ(a, col, "Immatriculation", v.immat, android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS, "AB-123-CD")
        val eBat = W.champ(a, col, "Batterie utile (kWh)", W.n(v.batterieKwh), W.NOMBRE)
        val eCon = W.champ(a, col, "Consommation en VTC (kWh/100 km)", W.n(v.conso), W.NOMBRE)
        col.addView(W.aide(a, "Mercedes EQV : 28,1 kWh/100 km en cycle WLTP ; en ville avec la clim, compte 26 à 30. " +
            "L'appli mesure ensuite ta vraie consommation avec la batterie relevée."))
        val ePl = W.champ(a, col, "Places passagers + chauffeur", v.places.toString(), android.text.InputType.TYPE_CLASS_NUMBER)
        val eCv = W.champ(a, col, "Puissance fiscale (CV, case P.6 de la carte grise)", v.cv.toString(), android.text.InputType.TYPE_CLASS_NUMBER)
        val eSt = W.champ(a, col, "Situation", v.statut, indice = "ex. Loué à la SASU (contrat du 01/09/2026)")
        col.addView(Ui.text(a, "Relevé du compteur", 13f, Ui.MUTED))
        val sp = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, listOf("Envoyé par la voiture (Tesla · Teslemetry)", "Photo du tableau de bord"))
            setSelection(if (v.connectee) 0 else 1)
        }
        col.addView(sp)
        val d = AlertDialog.Builder(a).setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton(if (v.id == store.vehiculeActif.id) "Enregistrer" else "Enregistrer et l'utiliser") { _, _ ->
                val n = v.copy(modele = W.txt(eMod).ifBlank { v.modele }, immat = W.txt(eImm).uppercase(),
                    batterieKwh = W.nombre(eBat)?.takeIf { it in 10.0..250.0 } ?: v.batterieKwh,
                    conso = W.nombre(eCon)?.takeIf { it in 5.0..60.0 } ?: v.conso,
                    places = W.txt(ePl).toIntOrNull()?.coerceIn(2, 9) ?: v.places,
                    cv = W.txt(eCv).toIntOrNull()?.coerceIn(1, 60) ?: v.cv,
                    statut = W.txt(eSt).ifBlank { v.statut },
                    connexion = if (sp.selectedItemPosition == 0) Vehicule.TESLA else Vehicule.PHOTO)
                store.saveVehicule(n)
                store.choisirVehicule(n.id)
                a.toast("${n.court} enregistré et utilisé"); a.afficher()
            }
            .setNegativeButton("Annuler") { _, _ -> a.afficher() }
        if (!nouveau && store.vehicules().size > 1) d.setNeutralButton("Supprimer") { _, _ ->
            W.confirmer(a, "Supprimer ${v.court} ?", "Ses courses et relevés sont gardés.", "Supprimer") { store.supprimerVehicule(v.id); a.afficher() }
        }
        d.show()
    }
}
