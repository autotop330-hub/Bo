package fr.bonnecourse

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Lecture du texte d'une capture d'écran, sur le téléphone (aucun envoi sur internet). */
object Reader {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** Renvoie le texte trié de haut en bas, une ligne par ligne d'écran. */
    fun read(bmp: Bitmap, onDone: (text: String?, error: String?) -> Unit) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val lines = res.textBlocks.flatMap { it.lines }
                    .sortedWith(compareBy({ it.boundingBox?.top ?: 0 }, { it.boundingBox?.left ?: 0 }))
                onDone(lines.joinToString("\n") { it.text }, null)
            }
            .addOnFailureListener { onDone(null, it.message ?: "Lecture impossible") }
    }

    /** onDone(résultat, erreur, texte lu, identifiant dans l'historique) */
    fun analyse(bmp: Bitmap, store: Store, onDone: (Result?, String?, String, Long) -> Unit) {
        read(bmp) { text, err ->
            if (text == null) { onDone(null, err, "", 0L); return@read }
            val parsed = OfferParser.parse(text)
            if (parsed.offer == null) { onDone(null, parsed.erreur, text, 0L); return@read }
            val r = Analyzer.analyse(parsed.offer, store.profile)
            val id = store.add(r)
            onDone(r, null, text, id)
        }
    }
}
