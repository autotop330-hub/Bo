package fr.bonnecourse

import java.util.Calendar

/**
 * Tout ce que contient le rapport mensuel, calculé une fois (aucune dépendance à Android : testable tel quel).
 * Les km « service » viennent de la bulle (GPS, au mètre) ; le compteur vient des relevés (voiture ou photo).
 */
data class RapportDonnees(
    val annee: Int,
    val mois: Int,
    val edition: Long,
    val entreprise: Entreprise,
    val vehicules: List<Vehicule>,               // véhicules utilisés dans le mois
    val compteur: Compteur?,                     // bilan au compteur (null : moins de 2 relevés)
    val kmService: Double,                       // km pro au GPS (bulle lancée + trajets classés pro)
    val kmPerso: Double,
    val kmApproche: Double,
    val kmClient: Double,
    val kmDomicile: Double,
    val jours: List<Jour>,
    val courses: List<Ride>,
    val trajets: List<Trajet>,                   // trajets hors bulle (détectés ou ajoutés)
    val releves: List<Releve>,
    val frais: List<Poste>,
    val recharges: List<Frais>,
    val minutesService: Double,
    val tva: Boolean
) {
    data class Compteur(val vehicule: String, val premier: Releve, val dernier: Releve, val total: Double, val service: Double, val nb: Int) {
        val horsService get() = (total - service).coerceAtLeast(0.0)
    }

    /** Une ligne du carnet journalier. */
    data class Jour(
        val date: Long, val debut: Long?, val fin: Long?, val odoDebut: Double?, val odoFin: Double?,
        val kmService: Double, val kmDomicile: Double, val kmApproche: Double, val kmClient: Double, val kmPerso: Double,
        val courses: Int, val encaisse: Double
    ) {
        val travaille get() = kmService > 0 || courses > 0
        val kmVide get() = (kmService - kmDomicile - kmApproche - kmClient).coerceAtLeast(0.0)
    }

    data class Poste(val nom: String, val ttc: Double, val tva: Double, val nb: Int, val justifies: Int) { val ht get() = ttc - tva }

    val kmVide get() = (kmService - kmDomicile - kmApproche - kmClient).coerceAtLeast(0.0)
    val partPro get() = if (kmService + kmPerso > 0) kmService / (kmService + kmPerso) else 0.0
    val encaisse get() = courses.sumOf { it.prix }
    val joursTravailles get() = jours.count { it.travaille }
    val parSource get() = courses.groupBy { it.source }.map { (s, l) -> Triple(s, l.size, l.sumOf { it.prix }) }
        .sortedBy { listOf("Uber", "Bolt", "Heetch", "FreeNow", "Privé").indexOf(it.first).let { i -> if (i < 0) 9 else i } }
    val connecte get() = vehicules.any { it.connectee }

    companion object {
        private fun cle(t: Long): String = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.FRANCE).format(java.util.Date(t))

        /**
         * Assemble le rapport à partir des données brutes (toutes les listes peuvent contenir d'autres mois : elles sont filtrées ici).
         */
        fun assembler(
            annee: Int, mois: Int, edition: Long, entreprise: Entreprise, tousVehicules: List<Vehicule>, actif: Vehicule,
            rides: List<Ride>, service: Map<String, Double>, perso: Map<String, Double>, segments: List<Segment>,
            trajets: List<Trajet>, releves: List<Releve>, frais: List<Frais>, minutesService: Map<String, Double>, tva: Boolean
        ): RapportDonnees {
            val cal = Calendar.getInstance()
            fun duMois(t: Long): Boolean { cal.timeInMillis = t; return cal.get(Calendar.YEAR) == annee && cal.get(Calendar.MONTH) + 1 == mois }
            val pre = String.format("%04d-%02d", annee, mois)
            val rs = rides.filter { duMois(it.debut) }.sortedBy { it.debut }
            val sg = segments.filter { duMois(it.debut) }
            val tj = trajets.filter { duMois(it.debut) }.sortedBy { it.debut }
            val rl = releves.filter { duMois(it.t) && it.odoKm > 0 }.sortedBy { it.t }
            val svc = service.filterKeys { it.startsWith(pre) }
            val prs = perso.filterKeys { it.startsWith(pre) }

            // Véhicules du mois (courses, relevés, trajets), sinon le véhicule actif
            val ids = (rs.map { it.vehicule } + rl.map { it.vehicule } + tj.map { it.vehicule }).filter { it.isNotBlank() }
            val vehs = ids.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.mapNotNull { e -> tousVehicules.find { it.id == e.key } }
                .ifEmpty { listOf(actif) }

            // Compteur : relevés du véhicule le plus relevé ; km de service = somme des (fin − début) de chaque service
            val vC = rl.groupingBy { it.vehicule }.eachCount().maxByOrNull { it.value }?.key
            val rv = rl.filter { it.vehicule == vC }
            val compteur = if (rv.size >= 2) {
                var s = 0.0; var d: Releve? = null
                rv.forEach { x ->
                    if (x.type == "debut_service") d = x
                    if (x.type == "fin_service") { d?.let { if (x.odoKm >= it.odoKm) s += x.odoKm - it.odoKm }; d = null }
                }
                Compteur(vC ?: "", rv.first(), rv.last(), (rv.last().odoKm - rv.first().odoKm).coerceAtLeast(0.0), s, rv.size)
            } else null

            // Carnet jour par jour (tous les jours du mois, repos compris)
            cal.set(annee, mois - 1, 1, 0, 0, 0); cal.set(Calendar.MILLISECOND, 0)
            val nbJours = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val jours = (1..nbJours).map { j ->
                cal.set(annee, mois - 1, j, 0, 0, 0)
                val d0 = cal.timeInMillis
                val k = cle(d0)
                val rj = rs.filter { cle(it.debut) == k }
                val sj = sg.filter { cle(it.debut) == k }
                val lj = rv.filter { cle(it.t) == k }
                val debuts = lj.filter { it.type == "debut_service" }; val fins = lj.filter { it.type == "fin_service" }
                val heures = (rj.flatMap { listOf(it.debut, it.fin) } + sj.flatMap { listOf(it.debut, it.fin) } +
                    debuts.map { it.t } + fins.map { it.t })
                Jour(d0, heures.minOrNull(), heures.maxOrNull(),
                    (debuts.firstOrNull() ?: lj.firstOrNull())?.odoKm, (fins.lastOrNull() ?: lj.lastOrNull().takeIf { lj.size > 1 })?.odoKm,
                    maxOf(svc[k] ?: 0.0, rj.sumOf { it.kmTotal } + sj.sumOf { it.km }), sj.sumOf { it.km },
                    rj.sumOf { it.kmApproche }, rj.sumOf { it.kmCourse }, prs[k] ?: 0.0, rj.size, rj.sumOf { it.prix })
            }

            val fm = frais.filter { it.dansMois(annee, mois) }
            val postes = fm.groupBy { it.categorie }.map { (c, l) ->
                Poste(c.nom, l.sumOf { it.ttc }, l.sumOf { it.tva() }, l.size, l.count { it.photo.isNotBlank() || it.note.startsWith("Auto Tesla") })
            }.sortedByDescending { it.ttc }

            return RapportDonnees(
                annee, mois, edition, entreprise, vehs, compteur,
                kmService = jours.sumOf { it.kmService }, kmPerso = prs.values.sum(),
                kmApproche = rs.sumOf { it.kmApproche }, kmClient = rs.sumOf { it.kmCourse }, kmDomicile = sg.sumOf { it.km },
                jours = jours, courses = rs, trajets = tj, releves = rl, frais = postes,
                recharges = fm.filter { it.categorie == Categorie.RECHARGE && !it.mensuel }.sortedBy { it.date },
                minutesService = minutesService.filterKeys { it.startsWith(pre) }.values.sum(), tva = tva)
        }
    }
}
