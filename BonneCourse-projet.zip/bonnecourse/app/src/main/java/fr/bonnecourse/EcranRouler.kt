package fr.bonnecourse

import android.view.View
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Onglet « Rouler » : la bulle, la journée en cours, les courses privées. */
class EcranRouler(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Bonne Course"))
        col.addView(W.aide(a, "Tesla Model Y Propulsion · SASU · tout est enregistré sur le téléphone"))
        col.addView(aujourdhui())
        col.addView(bulle())
        col.addView(privee())
        aSigner()?.let { col.addView(it) }
        trajets()?.let { col.addView(it) }
    }

    private fun aujourdhui(): View {
        val c = W.carte(a, "Aujourd'hui")
        val debutJour = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val rs = store.rides().filter { it.debut >= debutJour }
        val total = rs.sumOf { it.prix }
        c.addView(W.hero(a, W.eur2(total), "encaissé aujourd'hui", if (total > 0) Ui.GO else Ui.FG))
        val jour = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(Date())
        val km = maxOf(store.service()[jour] ?: 0.0, rs.sumOf { it.kmTotal })
        val minutes = rs.sumOf { it.minTotal }
        c.addView(W.ligne(a, "Courses", "${rs.size}"))
        c.addView(W.ligne(a, "Km pro", "${Analyzer.fmt1(km)} km"))
        if (minutes > 0) {
            c.addView(W.ligne(a, "Temps en course", "${(minutes / 60).toInt()} h ${String.format("%02d", (minutes % 60).roundToInt())}"))
            c.addView(W.ligne(a, "Par heure en course", "${(total / minutes * 60).roundToInt()} €"))
        }
        val parSource = rs.groupBy { it.source }.mapValues { (_, l) -> l.sumOf { it.prix } }.filterValues { it > 0 }
        if (parSource.size > 1) {
            val ligne = Ui.vertical(a, 4)
            parSource.entries.sortedByDescending { it.value }.forEach { (s, v) -> ligne.addView(W.pastille(a, W.couleurSource(s), "$s  ${W.eur2(v)}", 14f)) }
            c.addView(ligne)
        }
        return c
    }

    private fun bulle(): View {
        val c = W.carte(a, "La bulle")
        val ok = a.peutAfficherBulle()
        c.addView(Ui.text(a, when {
            BubbleService.running -> "Bulle active. Quand une course sonne, touche la bulle : vert = bonne course, orange = moyenne, rouge = à refuser."
            !ok -> "Étape 1 : autorise Bonne Course à s'afficher par-dessus les autres applis."
            else -> "Lance la bulle avant d'ouvrir Uber ou Bolt."
        }, 15f))
        if (!ok) c.addView(W.bouton(a, "1. Autoriser l'affichage par-dessus les applis") { a.autoriserBulle() })
        if (BubbleService.running) c.addView(W.bouton(a, "Arrêter la bulle") { a.arreterBulle() })
        else c.addView(W.bouton(a, if (ok) "Lancer la bulle" else "2. Lancer la bulle", true) { a.lancerBulle() })
        c.addView(W.aide(a, "Android demande d'autoriser l'enregistrement de l'écran : choisis « Écran entier ». " +
            "Rien n'est envoyé : l'image est lue sur le téléphone puis jetée."))
        c.addView(W.aide(a, "Appui long sur la bulle : course client privé ou trajet perso."))
        return c
    }

    private fun privee(): View {
        val c = W.carte(a, "Course privée (client en direct)")
        c.addView(W.bouton(a, "Démarrer une course privée", true, Ui.GO) { a.demarrerPrivee() })
        c.addView(W.aide(a, "Le GPS enregistre l'approche et le trajet. À l'arrivée, le client signe sur le téléphone et reçoit sa facture par mail."))
        c.addView(W.bouton(a, "Saisir une course à la main") { a.ouvrirFacture(null) })
        return c
    }

    /** Courses privées pas encore signées. */
    private fun aSigner(): View? {
        val l = store.rides().filter { it.prive && it.facture.isBlank() }.sortedByDescending { it.debut }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Factures à finir (${l.size})")
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        l.take(15).forEach { r ->
            c.addView(Ui.vertical(a, 2).apply {
                addView(Ui.text(a, "${f.format(Date(r.priseEnCharge))} · ${Analyzer.fmt1(r.kmCourse)} km" + (if (r.prix > 0) " · ${W.eur2(r.prix)}" else ""), 15f, Ui.FG, true))
                if (r.lieuArrivee.isNotBlank()) addView(W.aide(a, "${r.lieuPrise.substringBefore(" (")} → ${r.lieuArrivee.substringBefore(" (")}"))
                addView(Ui.text(a, if (store.dejaSignee(r.debut)) "✓ Signée · toucher pour finir la facture" else "Toucher pour faire signer et facturer",
                    13f, if (store.dejaSignee(r.debut)) Ui.GO else Ui.WARN))
                setOnClickListener { a.ouvrirFacture(r) }
            })
        }
        return c
    }

    /** Trajets détectés automatiquement qui attendent « pro » ou « perso ». */
    private fun trajets(): View? {
        val l = store.trajets().filter { it.statut == Trajet.A_CLASSER }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Trajets à classer (${l.size})")
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        val ville = { x: String -> x.substringBefore(" (").let { it.substringAfter(", ", it) } }
        l.take(10).forEach { t ->
            c.addView(Ui.vertical(a, 6).apply {
                addView(Ui.text(a, "${fmt.format(Date(t.debut))} · ${Analyzer.fmt1(t.km)} km · ${t.minutes.roundToInt()} min", 15f, Ui.FG, true))
                val lieux = listOf(ville(t.depart), ville(t.arrivee)).filter { it.isNotBlank() }.joinToString(" → ")
                if (lieux.isNotBlank()) addView(W.aide(a, lieux))
                addView(Ui.buttonRow(a,
                    Ui.button(a, "Pro", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PRO); a.afficher() },
                    Ui.button(a, "Perso", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PERSO); a.afficher() }))
            })
        }
        return c
    }
}
