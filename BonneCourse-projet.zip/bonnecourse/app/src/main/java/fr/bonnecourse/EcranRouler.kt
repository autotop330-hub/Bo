package fr.bonnecourse

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Onglet « Rouler » : la bulle, la journée en cours, les courses privées. */
class EcranRouler(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        col.addView(W.logo(a))
        col.addView(W.salutation(a, store.entreprise.chauffeur.trim().substringBefore(" ")))
        if (store.cleTomTom.isBlank()) col.addView(TraficDirect.carte(a))
        col.addView(aujourdhui())
        EcranTesla.etat(a)?.let { col.addView(it) }
        col.addView(bulle())
        col.addView(privee())
        aSigner()?.let { col.addView(it) }
        trajets()?.let { col.addView(it) }
    }

    private fun hm(min: Double) = "${(min / 60).toInt()} h ${String.format("%02d", (min % 60).roundToInt())}"

    /** La journée : encaissé, objectif, net estimé, temps de service et taux d'occupation, km. */
    private fun aujourdhui(): View {
        val c = W.carteVedette(a, "Aujourd'hui")
        val debutJour = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val p = store.profile
        val rs = store.rides().filter { it.debut >= debutJour }
        val total = rs.sumOf { it.prix }
        val obj = store.objectifJour
        c.addView(W.hero(a, W.eur2(total), "encaissé · ${rs.size} course${if (rs.size > 1) "s" else ""}", Ui.FG))
        c.addView(W.progression(a, if (obj > 0) total / obj else 0.0, if (total >= obj) Ui.GO else Ui.ACCENT))
        c.addView(W.ligne(a, "Objectif du jour", if (total >= obj) "✓ atteint (${W.eur(obj)})" else "encore ${W.eur(obj - total)} sur ${W.eur(obj)}",
            couleur = if (total >= obj) Ui.GO else Ui.FG).apply {
            setOnClickListener { objectif() }
        })

        // Net réel estimé de la journée (TVA, recharge, usure, loyer et assurance au km déduits)
        val net = rs.sumOf { Stats.net(it, p) }
        val jour = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(Date())
        val minCourse = rs.sumOf { it.minTotal }
        val enCours = store.serviceDebut.takeIf { it > 0 }?.let { (System.currentTimeMillis() - maxOf(it, debutJour)) / 60000.0 } ?: 0.0
        val minService = (store.minutesService()[jour] ?: 0.0) + enCours
        val occupation = if (minService > 1) (minCourse / minService).coerceAtMost(1.0) else 0.0
        c.addView(Ui.buttonRow(a,
            stat("Net estimé", W.eur(net), Ui.GO),
            stat("€/h de service", if (minService > 5) W.eur(total / minService * 60) else "—", Ui.ACCENT),
            stat("Occupation", if (minService > 5) "${(occupation * 100).roundToInt()} %" else "—", Ui.FG)))
        if (minService > 1) c.addView(W.aide(a, "Service ${hm(minService)} · en course ${hm(minCourse)}" +
            if (minService > 5 && occupation < 0.5) " · plus de la moitié du temps à vide : vise les zones et créneaux de « Mon mois »" else ""))

        val km = maxOf(store.service()[jour] ?: 0.0, rs.sumOf { it.kmTotal })
        val sj = store.segments().filter { it.debut >= debutJour }
        c.addView(Ui.buttonRow(a,
            W.chiffreKm(a, "Approche", rs.sumOf { it.kmApproche }, Ui.WARN),
            W.chiffreKm(a, "Client", rs.sumOf { it.kmCourse }, Ui.GO),
            W.chiffreKm(a, "Domicile", sj.sumOf { it.km }, Ui.ACCENT)))
        c.addView(W.ligne(a, "Km pro de la journée", String.format(Locale.FRANCE, "%.3f km", km), true))
        val parSource = rs.groupBy { it.source }.mapValues { (_, l) -> l.sumOf { it.prix } }.filterValues { it > 0 }
        if (parSource.size > 1) {
            val ligne = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            parSource.entries.sortedByDescending { it.value }.forEach { (s, v) ->
                ligne.addView(W.pastille(a, W.couleurSource(s), "$s ${W.eur(v)}", 13f),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(a, 14) })
            }
            c.addView(ligne)
        }
        return c
    }

    private fun stat(lab: String, v: String, couleur: Int): View = Ui.vertical(a, 2).apply {
        background = Ui.box(a, android.graphics.Color.parseColor("#26FFFFFF"), android.graphics.Color.TRANSPARENT, 0, 14)
        val pd = Ui.dp(a, 10); setPadding(pd, pd, pd, pd)
        addView(Ui.text(a, lab, 11f, Ui.MUTED, true).apply { maxLines = 1 })
        addView(Ui.text(a, v, 18f, couleur, true).apply { maxLines = 1 })
    }

    private fun objectif() {
        val e = android.widget.EditText(a).apply {
            inputType = W.NOMBRE; setText(W.n(store.objectifJour)); setTextColor(Ui.FG)
        }
        androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Objectif d'encaissement par jour (€)").setView(e)
            .setPositiveButton("Enregistrer") { _, _ -> W.nombre(e)?.takeIf { it > 0 }?.let { store.objectifJour = it; a.afficher() } }
            .setNegativeButton("Annuler", null).show()
    }

    private fun bulle(): View {
        val c = W.carte(a, "La bulle")
        val ok = a.peutAfficherBulle()
        c.addView(Ui.text(a, when {
            BubbleService.running -> "Bulle active. Quand une course sonne, touche la bulle : vert = bonne course, orange = moyenne, rouge = à refuser."
            !ok -> "Étape 1 : autorise Bonne Course à s'afficher par-dessus les autres applis."
            else -> "Lance la bulle avant d'ouvrir Uber ou Bolt."
        }, 15f))
        if (!ok) c.addView(W.bouton(a, "1. Autoriser l'affichage par-dessus les applis") { a.autoriserBulle() })
        if (BubbleService.running) c.addView(W.bouton(a, "Arrêter la bulle") { a.arreterBulle() })
        else c.addView(W.bouton(a, if (ok) "Lancer la bulle" else "2. Lancer la bulle", true) { a.lancerBulle() })
        c.addView(W.aide(a, "Android demande d'autoriser l'enregistrement de l'écran : choisis « Écran entier ». " +
            "Rien n'est envoyé : l'image est lue sur le téléphone puis jetée."))
        c.addView(W.aide(a, "Appui long sur la bulle : course client privé ou trajet perso."))
        return c
    }

    private fun privee(): View {
        val c = W.carte(a, "Course privée (client en direct)")
        c.addView(W.bouton(a, "Démarrer une course privée", true, Ui.GO) { a.demarrerPrivee() })
        c.addView(W.aide(a, "Le GPS enregistre l'approche et le trajet. À l'arrivée, le client signe sur le téléphone et reçoit sa facture par mail."))
        c.addView(W.bouton(a, "Saisir une course à la main") { a.ouvrirFacture(null) })
        return c
    }

    /** Courses privées pas encore signées. */
    private fun aSigner(): View? {
        val l = store.rides().filter { it.prive && it.facture.isBlank() }.sortedByDescending { it.debut }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Factures à finir (${l.size})")
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        l.take(15).forEach { r ->
            c.addView(Ui.vertical(a, 2).apply {
                addView(Ui.text(a, "${f.format(Date(r.priseEnCharge))} · ${Analyzer.fmt1(r.kmCourse)} km" + (if (r.prix > 0) " · ${W.eur2(r.prix)}" else ""), 15f, Ui.FG, true))
                if (r.lieuArrivee.isNotBlank()) addView(W.aide(a, "${r.lieuPrise.substringBefore(" (")} → ${r.lieuArrivee.substringBefore(" (")}"))
                addView(Ui.text(a, if (store.dejaSignee(r.debut)) "✓ Signée · toucher pour finir la facture" else "Toucher pour faire signer et facturer",
                    13f, if (store.dejaSignee(r.debut)) Ui.GO else Ui.WARN))
                setOnClickListener { a.ouvrirFacture(r) }
                setOnLongClickListener { Suppression.course(a, store, r) { a.afficher() }; true }
            })
        }
        return c
    }

    /** Trajets détectés automatiquement qui attendent « pro » ou « perso ». */
    private fun trajets(): View? {
        val l = store.trajets().filter { it.statut == Trajet.A_CLASSER }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Trajets à classer (${l.size})")
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        val ville = { x: String -> x.substringBefore(" (").let { it.substringAfter(", ", it) } }
        l.take(10).forEach { t ->
            c.addView(Ui.vertical(a, 6).apply {
                addView(Ui.text(a, "${fmt.format(Date(t.debut))} · ${Analyzer.fmt1(t.km)} km · ${t.minutes.roundToInt()} min", 15f, Ui.FG, true))
                val lieux = listOf(ville(t.depart), ville(t.arrivee)).filter { it.isNotBlank() }.joinToString(" → ")
                if (lieux.isNotBlank()) addView(W.aide(a, lieux))
                addView(Ui.buttonRow(a,
                    Ui.button(a, "Pro", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PRO); a.afficher() },
                    Ui.button(a, "Perso", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PERSO); a.afficher() }))
            })
        }
        return c
    }
}
