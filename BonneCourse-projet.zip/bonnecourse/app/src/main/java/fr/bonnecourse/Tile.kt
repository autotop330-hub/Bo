package fr.bonnecourse

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Petits outils d'interface partagés (pas de XML : tout est construit ici). */
object Ui {
    // Noir et or, comme le logo La Bonne Course
    val BG = Color.parseColor("#0F1218")
    val SURFACE = Color.parseColor("#171B23")
    val RAISE = Color.parseColor("#20252F")
    val LINE = Color.parseColor("#2B313D")
    val FG = Color.parseColor("#F5F6F8")
    val MUTED = Color.parseColor("#9AA3B2")
    val ACCENT = Color.parseColor("#E8B65A")
    val OR_SOMBRE = Color.parseColor("#3A2E18")
    val GO = Color.parseColor("#3DDC97")
    val WARN = Color.parseColor("#FFB547")
    val STOP = Color.parseColor("#FF6B6B")
    val CONDENSED: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val MEDIUM: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val LEGER: Typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).roundToInt()

    fun color(v: Verdict) = when (v) {
        Verdict.ACCEPTER -> GO; Verdict.A_VOIR -> WARN; Verdict.REFUSER -> STOP
    }

    fun box(ctx: Context, fill: Int, stroke: Int = LINE, strokeDp: Int = 1, radiusDp: Int = 16) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(ctx, radiusDp).toFloat(); setStroke(dp(ctx, strokeDp), stroke)
        }

    fun text(ctx: Context, s: String, sp: Float = 15f, color: Int = FG, bold: Boolean = false) =
        TextView(ctx).apply {
            text = s; textSize = sp; setTextColor(color)
            if (bold) typeface = MEDIUM
        }

    /** Gros bouton tactile, utilisable aussi dans les fenêtres par-dessus les autres applis. */
    fun button(ctx: Context, s: String, fill: Int, textColor: Int, stroke: Int = fill, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = s; textSize = 18f; setTextColor(textColor); typeface = CONDENSED
            gravity = Gravity.CENTER; isAllCaps = true; letterSpacing = 0.04f
            val p = dp(ctx, 12); setPadding(p, p, p, p)
            background = box(ctx, fill, stroke, 2, 12)
            setOnClickListener { onClick() }
        }

    /** Section repliable : un titre cliquable qui montre ou cache le contenu. */
    fun details(ctx: Context, titre: String, contenu: View, ouvert: Boolean = false): View {
        val col = vertical(ctx, 8)
        val tete = text(ctx, (if (ouvert) "⌃  " else "⌄  ") + titre, 15f, ACCENT, true).apply {
            val p = dp(ctx, 6); setPadding(0, p, 0, p)
        }
        contenu.visibility = if (ouvert) View.VISIBLE else View.GONE
        tete.setOnClickListener {
            val o = contenu.visibility != View.VISIBLE
            contenu.visibility = if (o) View.VISIBLE else View.GONE
            tete.text = (if (o) "⌃  " else "⌄  ") + titre
        }
        col.addView(tete); col.addView(contenu)
        return col
    }

    /** Rangée de boutons de même largeur. */
    fun buttonRow(ctx: Context, vararg buttons: View) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        buttons.forEachIndexed { i, b ->
            addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(ctx, 8)
            })
        }
    }

    fun vertical(ctx: Context, gapDp: Int = 0) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        if (gapDp > 0) {
            showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
            dividerDrawable = GradientDrawable().apply { setSize(1, dp(ctx, gapDp)); setColor(Color.TRANSPARENT) }
        }
    }
}

/** La tuile de verdict : affichée par-dessus Uber, ou dans l'appli en mode test. */
object Tile {

    fun build(ctx: Context, r: Result, p: Profile, onClose: (() -> Unit)?,
              onAccept: (() -> Unit)? = null, onRefuse: (() -> Unit)? = null, traficEnCours: Boolean = false,
              batterie: Pair<String, Int>? = null): View {
        val c = Ui.color(r.verdict)
        val d = p.devise
        val root = Ui.vertical(ctx, 8).apply {
            background = Ui.box(ctx, Ui.SURFACE, c, 2, 18)
            val pad = Ui.dp(ctx, 14); setPadding(pad, pad, pad, pad)
            elevation = Ui.dp(ctx, 8).toFloat()
        }

        // Ligne 1 : verdict + score
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = Ui.text(ctx, r.verdict.signe, 24f, Ui.BG).apply {
            typeface = Ui.CONDENSED; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
        }
        head.addView(mark, LinearLayout.LayoutParams(Ui.dp(ctx, 40), Ui.dp(ctx, 40)).apply { marginEnd = Ui.dp(ctx, 12) })
        val word = Ui.text(ctx, r.verdict.mot, 30f, c).apply { typeface = Ui.CONDENSED }
        head.addView(word, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val score = Ui.text(ctx, "${Analyzer.fmt1(r.score)}/10", 26f, c).apply { typeface = Ui.CONDENSED }
        head.addView(score)
        if (onClose != null) {
            val x = Ui.text(ctx, "  ×", 26f, Ui.MUTED).apply { setOnClickListener { onClose() } }
            head.addView(x)
        }
        root.addView(head)

        // Ligne 2 : les trois chiffres clés
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun metric(v: String, lab: String) = Ui.vertical(ctx).apply {
            background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 10)
            val pd = Ui.dp(ctx, 7); setPadding(pd, pd, pd, pd)
            addView(Ui.text(ctx, v, 20f).apply { typeface = Ui.CONDENSED; maxLines = 1 })
            addView(Ui.text(ctx, lab, 11f, Ui.MUTED))
        }
        listOf(
            "${r.net.roundToInt()} $d" to "net",
            "${(r.marge * 100).roundToInt()} %" to "rentabilité",
            "${r.parHeure.roundToInt()} $d" to "par heure",
            Analyzer.fmt2(r.brutKm) to "$d / km"
        ).forEachIndexed { i, (v, l) ->
            row.addView(metric(v, l), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = Ui.dp(ctx, 6)
            })
        }
        root.addView(row)

        // Ce qui a été lu, pour repérer une erreur de lecture d'un coup d'œil
        val o = r.offer
        val lu = buildString {
            append("Lu : ${Analyzer.fmt2(o.prix)} $d")
            if (o.approcheLue) append(" · approche ${o.approcheMin.roundToInt()} min ${Analyzer.fmt1(o.approcheKm)} km")
            append(" · course ${if (o.dureeEstimee) "≈" else ""}${o.courseMin.roundToInt()} min ${Analyzer.fmt1(o.courseKm)} km")
        }
        root.addView(Ui.text(ctx, lu, 13f, Ui.MUTED))
        // D'où viennent les minutes : trafic réel (TomTom), trafic habituel à cette heure, ou plateforme
        val tr = if (traficEnCours) "🚦 Trafic en direct : calcul…" else if (r.trafic.isNotBlank()) "🚦 ${r.trafic}" else ""
        if (tr.isNotBlank()) root.addView(Ui.text(ctx, tr, 13f, when {
            traficEnCours || r.trafic.startsWith("Trafic en direct") -> Ui.ACCENT
            r.trafic.startsWith("⚠") -> Ui.WARN
            else -> Ui.MUTED
        }, true))

        // Autonomie de la Tesla comparée à la course (Teslemetry)
        if (batterie != null) root.addView(Ui.text(ctx, batterie.first, 13f,
            when (batterie.second) { 2 -> Ui.STOP; 1 -> Ui.WARN; else -> Ui.MUTED }, batterie.second > 0))

        // Raisons (3 max pour rester lisible en conduisant)
        r.raisons.take(3).forEach { rs ->
            val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val dot = View(ctx).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.color(rs.niveau)) } }
            line.addView(dot, LinearLayout.LayoutParams(Ui.dp(ctx, 9), Ui.dp(ctx, 9)).apply { marginEnd = Ui.dp(ctx, 10) })
            line.addView(Ui.text(ctx, rs.texte, 14f), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            root.addView(line)
        }

        // J'accepte → lance le compteur kilométrique de la course
        if (onAccept != null && onRefuse != null) {
            root.addView(Ui.buttonRow(ctx,
                Ui.button(ctx, "J'accepte", Ui.GO, Ui.BG) { onAccept() },
                Ui.button(ctx, "Je refuse", Ui.SURFACE, Ui.STOP, Ui.STOP) { onRefuse() }
            ))
        }
        return root
    }

    /** Panneau de la course en cours, ouvert en touchant la bulle pendant une course. */
    /** Renvoie le panneau et une fonction qui met à jour le chrono et les km sans reconstruire les boutons. */
    fun ride(ctx: Context, phase: Phase, gps: Boolean, prive: Boolean,
             onNext: () -> Unit, onAnalyse: () -> Unit, onCancel: () -> Unit, onClose: () -> Unit
    ): Pair<View, (Double, Double) -> Unit> {
        val c = if (phase == Phase.APPROCHE) Ui.WARN else Ui.GO
        val root = Ui.vertical(ctx, 10).apply {
            background = Ui.box(ctx, Ui.SURFACE, c, 2, 18)
            val pad = Ui.dp(ctx, 14); setPadding(pad, pad, pad, pad)
            elevation = Ui.dp(ctx, 8).toFloat()
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.text(ctx, (if (phase == Phase.APPROCHE) "APPROCHE" else "CLIENT À BORD") + (if (prive) " · PRIVÉ" else ""), 26f, c).apply { typeface = Ui.CONDENSED },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.text(ctx, "  ×", 26f, Ui.MUTED).apply { setOnClickListener { onClose() } })
        root.addView(head)

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val tMin = Ui.text(ctx, "0:00", 30f).apply { typeface = Ui.CONDENSED }
        val tKm = Ui.text(ctx, if (gps) "0,00" else "–", 30f).apply { typeface = Ui.CONDENSED }
        fun big(v: TextView, lab: String) = Ui.vertical(ctx).apply {
            background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 10)
            val pd = Ui.dp(ctx, 10); setPadding(pd, pd, pd, pd)
            addView(v)
            addView(Ui.text(ctx, lab, 12f, Ui.MUTED))
        }
        row.addView(big(tMin, "minutes"), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(big(tKm, if (gps) "km GPS" else "GPS désactivé"),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = Ui.dp(ctx, 8) })
        root.addView(row)
        val update: (Double, Double) -> Unit = { minutes, km ->
            val mm = minutes.toInt(); val ss = ((minutes - mm) * 60).toInt()
            tMin.text = String.format("%d:%02d", mm, ss)
            if (gps) tKm.text = Analyzer.fmt2(km)
        }

        root.addView(Ui.button(ctx, if (phase == Phase.APPROCHE) "Client à bord" else "Course terminée", c, Ui.BG) { onNext() })
        root.addView(Ui.buttonRow(ctx,
            Ui.button(ctx, "Analyser une offre", Ui.RAISE, Ui.FG, Ui.LINE) { onAnalyse() },
            Ui.button(ctx, "Annuler", Ui.RAISE, Ui.MUTED, Ui.LINE) { onCancel() }
        ))
        return root to update
    }

    /** Menu de l'appui long sur la bulle. */
    fun menu(ctx: Context, perso: Boolean, courseEnCours: Boolean, trajetDomicile: String?,
             onDomicile: () -> Unit, onDepart: () -> Unit,
             onPrive: () -> Unit, onPerso: () -> Unit, onService: () -> Unit, onClose: () -> Unit): View {
        val root = Ui.vertical(ctx, 10).apply {
            background = Ui.box(ctx, Ui.SURFACE, if (perso) Ui.MUTED else Ui.ACCENT, 2, 22)
            val pad = Ui.dp(ctx, 16); setPadding(pad, pad, pad, pad)
            elevation = Ui.dp(ctx, 8).toFloat()
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titre = when {
            perso -> "TRAJET PERSO EN COURS"
            trajetDomicile == Segment.DEPART -> "DÉPART DU DOMICILE"
            trajetDomicile == Segment.RETOUR -> "RETOUR AU DOMICILE"
            else -> "EN SERVICE"
        }
        head.addView(Ui.text(ctx, titre, 22f, if (perso) Ui.MUTED else Ui.ACCENT).apply { typeface = Ui.CONDENSED },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Ui.text(ctx, "  ×", 26f, Ui.MUTED).apply { setOnClickListener { onClose() } })
        root.addView(head)
        if (perso) {
            root.addView(Ui.text(ctx, "Les km roulés maintenant sont exclus des km professionnels.", 14f))
            root.addView(Ui.button(ctx, "Reprendre le service", Ui.ACCENT, Ui.BG) { onService() })
            return root
        }
        if (!courseEnCours) {
            root.addView(Ui.button(ctx, "Course client privé", Ui.GO, Ui.BG) { onPrive() })
            root.addView(Ui.text(ctx, "Client réservé en direct. Tracé GPS enregistré ; à l'arrivée, il signe et reçoit sa facture.", 13f, Ui.MUTED))
            when (trajetDomicile) {
                Segment.RETOUR -> {
                    root.addView(Ui.button(ctx, "Je suis arrivé au domicile", Ui.FG, Ui.BG) { onDomicile() })
                    root.addView(Ui.text(ctx, "Le retour se termine tout seul en arrivant devant chez toi.", 13f, Ui.MUTED))
                }
                Segment.DEPART -> root.addView(Ui.text(ctx, "Départ du domicile en cours : il se termine à la 1re course acceptée.", 13f, Ui.MUTED))
                else -> {
                    root.addView(Ui.button(ctx, "Rentrer au domicile (fin de service)", Ui.RAISE, Ui.FG, Ui.LINE) { onDomicile() })
                    root.addView(Ui.text(ctx, "Km du retour enregistrés à part dans le carnet kilométrique, avec le tracé.", 13f, Ui.MUTED))
                    root.addView(Ui.button(ctx, "Je pars du domicile", Ui.RAISE, Ui.FG, Ui.LINE) { onDepart() })
                }
            }
        }
        root.addView(Ui.button(ctx, "Trajet perso", Ui.RAISE, Ui.MUTED, Ui.LINE) { onPerso() })
        root.addView(Ui.text(ctx, "Courses, famille, détour privé : km exclus des km professionnels.", 13f, Ui.MUTED))
        return root
    }

    /** Petite confirmation après une course enregistrée. */
    fun saved(ctx: Context, r: Ride): View = Ui.vertical(ctx, 4).apply {
        background = Ui.box(ctx, Ui.SURFACE, Ui.ACCENT, 2, 18)
        val pad = Ui.dp(ctx, 14); setPadding(pad, pad, pad, pad)
        addView(Ui.text(ctx, "COURSE ENREGISTRÉE", 22f, Ui.ACCENT).apply { typeface = Ui.CONDENSED })
        addView(Ui.text(ctx,
            "${r.minTotal.roundToInt()} min · ${Analyzer.fmt2(r.kmTotal)} km " +
            "(approche ${r.minApproche.roundToInt()} min ${Analyzer.fmt1(r.kmApproche)} km, " +
            "course ${r.minCourse.roundToInt()} min ${Analyzer.fmt1(r.kmCourse)} km)", 14f))
    }

    fun error(ctx: Context, msg: String, onClose: (() -> Unit)?): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.box(ctx, Ui.SURFACE, Ui.MUTED, 2, 18)
            val pad = Ui.dp(ctx, 14); setPadding(pad, pad, pad, pad)
        }
        val col = Ui.vertical(ctx, 2).apply {
            addView(Ui.text(ctx, "PAS D'OFFRE LUE", 22f, Ui.MUTED).apply { typeface = Ui.CONDENSED })
            addView(Ui.text(ctx, if (msg.endsWith(".")) msg else "$msg. Touche la bulle quand l'offre est affichée en entier.", 14f))
        }
        root.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (onClose != null) root.addView(Ui.text(ctx, "  ×", 26f, Ui.MUTED).apply { setOnClickListener { onClose() } })
        return root
    }
}
