package fr.bonnecourse

/**
 * Trouve le kilométrage total dans le texte lu sur une photo du tableau de bord.
 *
 * Sur un compteur, plusieurs nombres se côtoient : le total (« 12 345 km », sans décimale),
 * le trajet partiel (« 123,4 km », avec une décimale), l'autonomie (« 287 km »), l'heure, la température…
 * Chaque nombre reçoit des points :
 *  +3 suivi de « km »        +2 sans décimale (le total n'en a pas)     +2 cinq chiffres ou plus
 *  +5 juste au-dessus du dernier relevé du véhicule (le compteur ne fait qu'avancer)
 *  −6 en dessous du dernier relevé (impossible)                         −3 précédé de « trip », « partiel », « autonomie »…
 */
object LectureCompteur {
    data class Candidat(val km: Double, val points: Int, val brut: String)

    private val NOMBRE = Regex("""(?<![\d.,])(\d{1,3}(?:[ .  ']\d{3})+|\d{2,7})(?:[.,](\d))?(?![\d])\s*(km|KM|Km|kM)?""")
    private val PARTIEL = Regex("""(?i)(trip|partiel|journalier|reset|depuis|autonomie|range|reste|moy|ø|kwh|%|°|/100)""")

    fun candidats(texte: String, dernier: Double? = null): List<Candidat> {
        // Erreurs de lecture courantes sur les afficheurs : O → 0, l → 1 au milieu des chiffres
        val t = texte.replace(Regex("(?<=\\d)[Oo](?=\\d|\\s*km)"), "0").replace(Regex("(?<=\\d)[lI](?=\\d)"), "1")
        val res = mutableListOf<Candidat>()
        for (ligne in t.lines()) {
            for (m in NOMBRE.findAll(ligne)) {
                val entier = m.groupValues[1]
                val decimale = m.groupValues[2]
                val km = m.groupValues[3].isNotEmpty()
                val chiffres = entier.filter { it.isDigit() }
                // « 12.345 » avec séparateur de milliers (3 chiffres après) ; « 12:30 » n'est jamais capté (2 chiffres)
                val v = (chiffres + if (decimale.isNotEmpty()) ".$decimale" else "").toDoubleOrNull() ?: continue
                if (v < 10 || v > 999_999) continue
                val apres = ligne.substring(m.range.last + 1).trimStart()
                if (apres.startsWith("%") || apres.startsWith("°") || apres.startsWith("kWh", true) || apres.startsWith("h ") || apres == "h") continue
                var p = 0
                if (km) p += 3
                if (decimale.isEmpty()) p += 2
                if (chiffres.length >= 5) p += 2 else if (chiffres.length <= 2) p -= 2
                if (dernier != null && dernier > 0) {
                    if (v >= dernier - 0.5 && v <= dernier + 3000) p += 5
                    else if (v < dernier - 0.5) p -= 6
                }
                val avant = ligne.substring(0, m.range.first)
                if (PARTIEL.containsMatchIn(avant) || PARTIEL.containsMatchIn(apres.take(8))) p -= 3
                res += Candidat(v, p, m.value.trim())
            }
        }
        return res.sortedWith(compareByDescending<Candidat> { it.points }.thenByDescending { it.km })
    }

    /** Le kilométrage le plus probable, ou null si rien de crédible. */
    fun extraire(texte: String, dernier: Double? = null): Double? =
        candidats(texte, dernier).firstOrNull()?.takeIf { it.points >= 2 }?.km
}
