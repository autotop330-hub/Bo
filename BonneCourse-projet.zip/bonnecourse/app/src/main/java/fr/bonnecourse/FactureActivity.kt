package fr.bonnecourse

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Course privée : vérification de la course, coordonnées du client, signature obligatoire,
 * puis facture PDF et envoi par Outlook.
 *
 * Ouverte automatiquement à la fin d'une course privée suivie au GPS (EXTRA_COURSE),
 * ou sans extra pour saisir une course à la main.
 */
class FactureActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_COURSE = "course"
        val PAIEMENTS = listOf("Carte bancaire", "Espèces", "Virement", "Chèque", "Autre")
    }

    private lateinit var store: Store
    private lateinit var ride: Ride
    private var nouvelle = false
    private var facture: Facture? = null
    private lateinit var racine: LinearLayout

    // Course
    private val cal = Calendar.getInstance()
    private var prise = 0L
    private var depose = 0L
    private var reservation = 0L
    private lateinit var bJour: TextView
    private lateinit var bPrise: TextView
    private lateinit var bDepose: TextView
    private lateinit var bResa: TextView
    private lateinit var eLieuPrise: EditText
    private lateinit var eLieuDepose: EditText
    private lateinit var eKm: EditText
    private lateinit var ePrix: EditText
    private lateinit var sPaiement: Spinner

    // Client
    private lateinit var eNom: EditText
    private lateinit var eSociete: EditText
    private lateinit var eSiren: EditText
    private lateinit var eAdresse: EditText
    private lateinit var eEmail: EditText
    private lateinit var eTel: EditText

    private var pad: SignaturePad? = null
    private var brouillon: JSONObject? = null       // saisie en cours, signature du client comprise
    private var refaireSignature = false

    private val jour = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE)
    private val heure = SimpleDateFormat("HH:mm", Locale.FRANCE)

    private val enregistrerPdf = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val f = facture ?: return@registerForActivityResult
        uri ?: return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { out -> FacturePdf.fichier(this, f.numero).inputStream().use { it.copyTo(out) } }
            Toast.makeText(this, "Facture enregistrée", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Enregistrement impossible : ${e.message}", Toast.LENGTH_LONG).show() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        val id = intent.getLongExtra(EXTRA_COURSE, 0L)
        val r = if (id > 0) store.ride(id) else null
        if (r == null) {
            nouvelle = true
            val maintenant = System.currentTimeMillis()
            ride = Ride(maintenant - 30 * 60000, maintenant - 30 * 60000, maintenant, 0.0, 0.0, 0.0, type = "prive", manuelle = true)
        } else ride = r
        facture = store.facture(ride.debut)
        prise = ride.priseEnCharge; depose = ride.fin
        reservation = facture?.reservation ?: if (nouvelle) prise - 60 * 60000 else ride.debut
        if (facture == null && !nouvelle) brouillon = store.brouillon(ride.debut)
        brouillon?.let { b ->
            prise = b.optLong("prise", prise); depose = b.optLong("depose", depose); reservation = b.optLong("reservation", reservation)
        }
        racine = Ui.vertical(this, 14).apply { val p = Ui.dp(this@FactureActivity, 16); setPadding(p, p, p, p * 3) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(racine) })
        construire()
    }

    private fun construire() {
        racine.removeAllViews()
        val f = facture
        racine.addView(W.titreEcran(this, if (f == null) "Course privée" else "Facture ${f.numero}"))
        if (f == null) {
            racine.addView(W.aide(this, "1. Vérifie la course  ·  2. Coordonnées du client  ·  3. Le client signe  ·  4. Envoi de la facture"))
            racine.addView(carteCourse())
            racine.addView(carteClient(false))
            racine.addView(carteSignature())
            racine.addView(W.bouton(this, "Valider la course et créer la facture", true, Ui.GO) { valider() })
            racine.addView(W.bouton(this, "Enregistrer et finir plus tard") {
                if (sauverBrouillon()) Toast.makeText(this, "Enregistré. Tu retrouves la course dans « À faire signer ».", Toast.LENGTH_LONG).show()
                finish()
            })
        } else {
            racine.addView(carteEnvoi(f))
            racine.addView(carteResume(f))
            racine.addView(carteClient(true))
        }
    }

    // ------------------------------------------------------------------ 1. La course

    private fun carteCourse(): View {
        val c = W.carte(this, "La course")
        if (!nouvelle && !ride.manuelle) c.addView(W.aide(this, "Heures et lieux relevés par le GPS. Corrige si besoin."))
        bJour = choix(c, "Date") { choisirDate() }
        bPrise = choix(c, "Prise en charge") { choisirHeure(true) }
        bDepose = choix(c, "Dépose") { choisirHeure(false) }
        val b = brouillon
        eLieuPrise = W.champ(this, c, "Lieu de prise en charge", b?.optString("lieuPrise") ?: ride.lieuPrise.substringBefore(" ("), indice = "Adresse, ville")
        eLieuDepose = W.champ(this, c, "Lieu de dépose", b?.optString("lieuDepose") ?: ride.lieuArrivee.substringBefore(" ("), indice = "Adresse, ville")
        eKm = W.champ(this, c, "Distance avec le client (km)", b?.optString("km") ?: if (ride.kmCourse > 0) Analyzer.fmt1(ride.kmCourse) else "", W.NOMBRE)
        ePrix = W.champ(this, c, "Prix payé par le client (TTC, €)", b?.optString("prix") ?: if (ride.prix > 0) W.n(ride.prix) else "", W.NOMBRE, "ex. 45")
        c.addView(Ui.text(this, "Paiement", 13f, Ui.MUTED))
        sPaiement = Spinner(this).apply {
            adapter = ArrayAdapter(this@FactureActivity, android.R.layout.simple_spinner_dropdown_item, PAIEMENTS)
            setSelection(PAIEMENTS.indexOf(b?.optString("paiement")).coerceAtLeast(0))
        }
        c.addView(sPaiement)
        bResa = choix(c, "Réservée le (réservation préalable obligatoire en VTC)") { choisirReservation() }
        majHeures()
        return c
    }

    private fun choix(parent: LinearLayout, label: String, onClick: () -> Unit): TextView {
        parent.addView(Ui.text(this, label, 13f, Ui.MUTED))
        val t = Ui.text(this, "", 18f, Ui.ACCENT, true).apply {
            val p = Ui.dp(this@FactureActivity, 8); setPadding(0, p, 0, p)
            setOnClickListener { onClick() }
        }
        parent.addView(t)
        return t
    }

    private fun majHeures() {
        bJour.text = jour.format(Date(prise)).replaceFirstChar { it.uppercase() } + "  ✎"
        bPrise.text = heure.format(Date(prise)) + "  ✎"
        bDepose.text = heure.format(Date(depose)) + " (" + ((depose - prise) / 60000) + " min)  ✎"
        bResa.text = SimpleDateFormat("d MMM yyyy 'à' HH:mm", Locale.FRANCE).format(Date(reservation)) + "  ✎"
    }

    private fun choisirDate() {
        cal.timeInMillis = prise
        DatePickerDialog(this, { _, a, m, j ->
            val duree = depose - prise
            cal.timeInMillis = prise; cal.set(a, m, j)
            val ecart = cal.timeInMillis - prise
            prise = cal.timeInMillis; depose = prise + duree
            reservation += ecart
            majHeures()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun choisirHeure(debut: Boolean) {
        cal.timeInMillis = if (debut) prise else depose
        TimePickerDialog(this, { _, h, mi ->
            cal.timeInMillis = prise
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi); cal.set(Calendar.SECOND, 0)
            if (debut) {
                val duree = depose - prise
                prise = cal.timeInMillis; depose = prise + maxOf(duree, 60000)
            } else {
                var t = cal.timeInMillis
                if (t <= prise) t += 24 * 3600_000L   // dépose après minuit
                depose = t
            }
            majHeures()
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }

    private fun choisirReservation() {
        cal.timeInMillis = reservation
        DatePickerDialog(this, { _, a, m, j ->
            cal.timeInMillis = reservation; cal.set(a, m, j)
            TimePickerDialog(this, { _, h, mi ->
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, mi)
                reservation = cal.timeInMillis; majHeures()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ------------------------------------------------------------------ 2. Le client

    private fun carteClient(apresValidation: Boolean): View {
        val c = W.carte(this, if (apresValidation) "Coordonnées du client" else "Le client")
        val cl = facture?.client ?: brouillon?.let { b ->
            Client(b.optString("nom"), b.optString("societe"), b.optString("siren"), b.optString("adresse"), b.optString("email"), b.optString("tel"))
        } ?: Client()
        val habitues = store.clients()
        if (!apresValidation && habitues.isNotEmpty()) c.addView(W.bouton(this, "Choisir un client habituel (${habitues.size})") { choisirHabitue(habitues) })
        eNom = W.champ(this, c, "Nom et prénom *", cl.nom, W.NOM)
        eEmail = W.champ(this, c, "E-mail (pour envoyer la facture)", cl.email, W.EMAIL)
        eTel = W.champ(this, c, "Téléphone", cl.tel, W.TEL)
        eAdresse = W.champ(this, c, "Adresse de facturation", cl.adresse, lignes = 2)
        val pro = Ui.vertical(this, 8)
        eSociete = W.champ(this, pro, "Société", cl.societe, W.NOM)
        eSiren = W.champ(this, pro, "SIREN de la société", cl.siren, W.NOMBRE)
        c.addView(Ui.details(this, "Client professionnel (société)", pro, cl.pro))
        if (apresValidation) c.addView(W.bouton(this, "Mettre à jour la facture", true) { majClient() })
        return c
    }

    private fun lireClient() = Client(W.txt(eNom), W.txt(eSociete), W.txt(eSiren).replace(" ", ""), W.txt(eAdresse), W.txt(eEmail), W.txt(eTel))

    private fun choisirHabitue(l: List<Client>) {
        AlertDialog.Builder(this).setTitle("Client habituel")
            .setItems(l.map { (it.nom + if (it.societe.isNotBlank()) " · ${it.societe}" else "") as CharSequence }.toTypedArray()) { _, i ->
                val c = l[i]
                eNom.setText(c.nom); eSociete.setText(c.societe); eSiren.setText(c.siren)
                eAdresse.setText(c.adresse); eEmail.setText(c.email); eTel.setText(c.tel)
            }.setNegativeButton("Annuler", null).show()
    }

    // ------------------------------------------------------------------ 3. La signature

    /** Signature déjà prise (enregistrée en attendant la facture), si elle existe. */
    private fun signatureEnAttente(): File? =
        brouillon?.optString("signature")?.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }

    private fun carteSignature(): View {
        val c = W.carte(this, "Signature du client")
        val attente = signatureEnAttente()
        if (attente != null && !refaireSignature) {
            pad = null
            val le = brouillon?.optLong("signeLe", 0L) ?: 0L
            c.addView(Ui.text(this, "✓ Le client a signé" + (if (le > 0) " le " + SimpleDateFormat("dd/MM 'à' HH:mm", Locale.FRANCE).format(Date(le)) else ""), 16f, Ui.GO, true))
            BitmapFactory.decodeFile(attente.absolutePath)?.let { bmp ->
                c.addView(ImageView(this).apply {
                    setImageBitmap(bmp); adjustViewBounds = true
                    background = Ui.box(this@FactureActivity, android.graphics.Color.WHITE, Ui.LINE, 1, 12)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 120)))
            }
            c.addView(W.bouton(this, "Refaire signer") { sauverBrouillon(); refaireSignature = true; construire() })
            return c
        }
        c.addView(W.aide(this, "Obligatoire pour valider la course. Tends le téléphone au client. " +
            "S'il est pressé : il signe, puis « Enregistrer et finir plus tard »."))
        val p = SignaturePad(this)
        pad = p
        c.addView(p, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 200)))
        c.addView(W.bouton(this, "Effacer la signature") { p.effacer() })
        return c
    }

    // ------------------------------------------------------------------ Validation

    private fun valider() {
        val prix = W.nombre(ePrix)
        val client = lireClient()
        val manque = when {
            prix == null || prix <= 0 -> "Indique le prix payé par le client."
            client.nom.isBlank() && client.societe.isBlank() -> "Indique le nom du client."
            (pad == null || pad!!.vide) && signatureEnAttente() == null -> "La signature du client est obligatoire."
            reservation > prise -> "La réservation doit être faite avant la prise en charge."
            else -> null
        }
        if (manque != null) { Toast.makeText(this, manque, Toast.LENGTH_LONG).show(); return }
        if (!store.entreprise.complete) {
            FormSociete.dialogue(this, store) { valider() }
            return
        }
        val km = W.nombre(eKm) ?: ride.kmCourse
        // Une course saisie à la main prend l'heure de prise en charge comme identifiant
        var debut = if (nouvelle) prise else ride.debut
        if (nouvelle) while (store.ride(debut) != null) debut++
        val avecCoord = { saisi: String, gps: String -> if (saisi == gps.substringBefore(" (")) gps else saisi }
        val r = ride.copy(
            debut = debut,
            priseEnCharge = if (nouvelle) debut else prise,
            fin = depose,
            kmCourse = km, prix = prix!!,
            lieuPrise = avecCoord(W.txt(eLieuPrise), ride.lieuPrise),
            lieuArrivee = avecCoord(W.txt(eLieuDepose), ride.lieuArrivee),
            lieuDepart = if (nouvelle) W.txt(eLieuPrise) else ride.lieuDepart
        )
        val maintenant = System.currentTimeMillis()
        val numero = store.nouveauNumero(Calendar.getInstance().get(Calendar.YEAR))
        val sig = File(filesDir, "signatures/$numero.png").apply { parentFile?.mkdirs() }
        val dessin = pad?.takeIf { !it.vide }
        val attente = signatureEnAttente()
        var signeLe = maintenant
        if (dessin != null) sig.outputStream().use { dessin.image().compress(Bitmap.CompressFormat.PNG, 100, it) }
        else if (attente != null) { attente.copyTo(sig, true); signeLe = brouillon?.optLong("signeLe", maintenant) ?: maintenant }
        val f = Facture(numero, r.debut, maintenant, client, sPaiement.selectedItem.toString(), reservation, sig.absolutePath, signeLe)
        store.saveFacture(f)
        store.addRide(r.copy(facture = numero))
        store.supprimerBrouillon(r.debut)
        brouillon = null
        ride = r.copy(facture = numero)
        nouvelle = false
        facture = f
        try { FacturePdf.creer(this, store.entreprise, store.profile, ride, f) }
        catch (e: Exception) { Toast.makeText(this, "PDF impossible : ${e.message}", Toast.LENGTH_LONG).show() }
        construire()
        Toast.makeText(this, "Course validée · facture $numero créée", Toast.LENGTH_LONG).show()
        // Directement dans Outlook, PDF joint, si le client a donné son e-mail
        if (client.email.isNotBlank()) racine.postDelayed({
            try { FacturePdf.envoyer(this, FacturePdf.fichier(this, numero), store.entreprise, ride, f) } catch (_: Exception) {}
        }, 600)
    }

    // ------------------------------------------------------------------ Finir plus tard

    override fun onPause() {
        super.onPause()
        // Rien ne se perd : appel entrant, écran éteint, retour arrière…
        if (facture == null && ::eNom.isInitialized && !isChangingConfigurations) sauverBrouillon()
    }

    /**
     * Garde la saisie et la signature du client sans créer la facture.
     * Une course saisie à la main est ajoutée à la boîte noire dès maintenant.
     * Renvoie false s'il n'y avait rien à garder.
     */
    private fun sauverBrouillon(): Boolean {
        if (facture != null) return false
        val dessin = pad?.takeIf { !it.vide }
        val prix = W.nombre(ePrix)
        val client = lireClient()
        if (nouvelle && dessin == null && prix == null && client.nom.isBlank() && W.txt(eLieuPrise).isBlank()) return false
        if (nouvelle) {
            var debut = prise
            while (store.ride(debut) != null) debut++
            ride = ride.copy(debut = debut, priseEnCharge = debut)
            nouvelle = false
        }
        // La course compte tout de suite dans le chiffre d'affaires (prix, heures, lieux modifiables jusqu'à la facture)
        val avecCoord = { saisi: String, gps: String -> if (saisi == gps.substringBefore(" (")) gps else saisi }
        ride = ride.copy(
            priseEnCharge = prise, fin = depose,
            prix = prix ?: ride.prix, kmCourse = W.nombre(eKm) ?: ride.kmCourse,
            lieuPrise = avecCoord(W.txt(eLieuPrise), ride.lieuPrise), lieuArrivee = avecCoord(W.txt(eLieuDepose), ride.lieuArrivee),
            lieuDepart = if (ride.manuelle) W.txt(eLieuPrise) else ride.lieuDepart)
        store.addRide(ride)
        val b = brouillon ?: JSONObject()
        if (dessin != null) {
            val f = File(filesDir, "signatures/attente-${ride.debut}.png").apply { parentFile?.mkdirs() }
            f.outputStream().use { dessin.image().compress(Bitmap.CompressFormat.PNG, 100, it) }
            b.put("signature", f.absolutePath).put("signeLe", System.currentTimeMillis())
            refaireSignature = false
        }
        b.put("prise", ride.priseEnCharge).put("depose", depose).put("reservation", reservation)
            .put("lieuPrise", W.txt(eLieuPrise)).put("lieuDepose", W.txt(eLieuDepose))
            .put("km", W.txt(eKm)).put("prix", W.txt(ePrix)).put("paiement", sPaiement.selectedItem?.toString() ?: "")
            .put("nom", client.nom).put("societe", client.societe).put("siren", client.siren)
            .put("adresse", client.adresse).put("email", client.email).put("tel", client.tel)
        store.saveBrouillon(ride.debut, b)
        brouillon = b
        return true
    }

    // ------------------------------------------------------------------ 4. Envoi

    private fun carteEnvoi(f: Facture): View {
        val c = W.carte(this, "Envoyer la facture")
        c.addView(Ui.text(this, "✓ Course signée et enregistrée", 16f, Ui.GO, true))
        val pdf = FacturePdf.fichier(this, f.numero)
        if (!pdf.exists()) try { FacturePdf.creer(this, store.entreprise, store.profile, ride, f) } catch (_: Exception) {}
        c.addView(W.bouton(this, "Envoyer par Outlook", true) {
            if (f.client.email.isBlank()) Toast.makeText(this, "Pas d'e-mail client : ajoute-le dans Outlook.", Toast.LENGTH_LONG).show()
            FacturePdf.envoyer(this, FacturePdf.fichier(this, f.numero), store.entreprise, ride, f)
        })
        if (!FacturePdf.outlookInstalle(this))
            c.addView(W.aide(this, "Outlook n'est pas installé : le téléphone te proposera une autre appli de mail."))
        c.addView(Ui.buttonRow(this,
            W.bouton(this, "Voir la facture") { FacturePdf.ouvrir(this, FacturePdf.fichier(this, f.numero)) },
            W.bouton(this, "Télécharger") { enregistrerPdf.launch("Facture-${f.numero}.pdf") }))
        c.addView(Ui.details(this, "Message envoyé avec la facture", Ui.text(this, FacturePdf.message(store.entreprise, ride, f), 14f)))
        return c
    }

    private fun carteResume(f: Facture): View {
        val c = W.carte(this, "La course")
        val (ht, tva, ttc) = FacturePdf.montants(ride.prix, store.profile.tva)
        c.addView(W.ligne(this, "Prise en charge", SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ride.priseEnCharge))))
        c.addView(W.ligne(this, "Dépose", heure.format(Date(ride.fin))))
        c.addView(Ui.text(this, "${ride.lieuPrise.substringBefore(" (")} → ${ride.lieuArrivee.substringBefore(" (")}", 14f))
        c.addView(W.ligne(this, "Total HT", W.eur2(ht)))
        if (store.profile.tva) c.addView(W.ligne(this, "TVA 10 %", W.eur2(tva)))
        c.addView(W.ligne(this, "Total TTC", W.eur2(ttc), true))
        c.addView(W.ligne(this, "Paiement", f.paiement))
        BitmapFactory.decodeFile(f.signature)?.let { b ->
            c.addView(W.aide(this, "Signature du client"))
            c.addView(ImageView(this).apply {
                setImageBitmap(b); adjustViewBounds = true
                background = Ui.box(this@FactureActivity, android.graphics.Color.WHITE, Ui.LINE, 1, 12)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 120)))
        }
        c.addView(W.aide(this, "La course signée ne se modifie plus. Seules les coordonnées du client peuvent être corrigées."))
        return c
    }

    private fun majClient() {
        val f = facture ?: return
        val cl = lireClient()
        if (cl.nom.isBlank() && cl.societe.isBlank()) { Toast.makeText(this, "Indique le nom du client.", Toast.LENGTH_LONG).show(); return }
        val nf = f.copy(client = cl)
        store.saveFacture(nf)
        facture = nf
        try { FacturePdf.creer(this, store.entreprise, store.profile, ride, nf) } catch (_: Exception) {}
        construire()
        Toast.makeText(this, "Facture mise à jour", Toast.LENGTH_SHORT).show()
    }
}

/** Coordonnées de la société (imprimées sur les factures) : dans les Réglages, ou demandées avant la 1re facture. */
object FormSociete {
    /** Ajoute les champs au conteneur et renvoie la fonction qui lit les valeurs saisies. */
    fun champs(a: android.content.Context, c: LinearLayout, e: Entreprise): () -> Entreprise {
        val raison = W.champ(a, c, "Nom de la société *", e.raisonSociale, W.NOM)
        val forme = W.champ(a, c, "Forme", e.forme)
        val capital = W.champ(a, c, "Capital (€)", e.capital, W.NOMBRE)
        val adresse = W.champ(a, c, "Adresse du siège *", e.adresse, lignes = 2)
        val siret = W.champ(a, c, "SIRET *", e.siret, W.NOMBRE)
        val rcs = W.champ(a, c, "RCS (ville)", e.rcs, W.NOM, "ex. Montpellier")
        val tva = W.champ(a, c, "N° de TVA intracommunautaire", e.tvaIntra, indice = "FR…")
        val evtc = W.champ(a, c, "N° d'inscription au registre VTC *", e.evtc, indice = "EVTC…")
        val chauffeur = W.champ(a, c, "Ton nom (signature des e-mails)", e.chauffeur, W.NOM)
        val tel = W.champ(a, c, "Téléphone", e.tel, W.TEL)
        val email = W.champ(a, c, "E-mail professionnel", e.email, W.EMAIL)
        val msg = W.champ(a, c, "Message envoyé avec la facture", e.message, lignes = 6)
        c.addView(W.aide(a, "Dans le message : {client}, {numero}, {date}, {depart}, {arrivee}, {chauffeur}, {societe}, {telephone} sont remplacés automatiquement."))
        return {
            Entreprise(W.txt(raison), W.txt(forme).ifBlank { "SASU" }, W.txt(capital), W.txt(adresse), W.txt(siret).replace(" ", ""),
                W.txt(rcs), W.txt(tva).replace(" ", ""), W.txt(evtc), W.txt(chauffeur), W.txt(tel), W.txt(email),
                msg.text.toString().ifBlank { Entreprise.MESSAGE_DEFAUT })
        }
    }

    fun dialogue(a: AppCompatActivity, store: Store, ensuite: () -> Unit) {
        val c = Ui.vertical(a, 6).apply { val p = Ui.dp(a, 18); setPadding(p, p, p, p) }
        c.addView(W.aide(a, "Une seule fois : ces informations sont obligatoires sur la facture."))
        val lire = champs(a, c, store.entreprise)
        AlertDialog.Builder(a).setTitle("Ta société")
            .setView(ScrollView(a).apply { addView(c) })
            .setPositiveButton("Enregistrer") { _, _ ->
                val e = lire()
                store.entreprise = e
                if (e.complete) ensuite()
                else Toast.makeText(a, "Il manque le nom, l'adresse, le SIRET ou le n° VTC.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Annuler", null).show()
    }
}
