package fr.bonnecourse

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Profil et historique, enregistrés sur le téléphone. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("bonnecourse", Context.MODE_PRIVATE)

    companion object {
        private val VERROU = Any()
        @Volatile private var cacheCourses: List<Ride>? = null
        @Volatile private var cacheFrais: List<Frais>? = null
    }

    init { adapterModelY() }

    /**
     * Situation du chauffeur : SASU, Tesla Model Y Grande Autonomie Propulsion au nom d'un proche,
     * louée à la société. Appliqué une fois ; les valeurs déjà changées à la main sont gardées.
     */
    private fun adapterModelY() {
        if (sp.getBoolean("modelY_v2", false)) return
        val e = sp.edit().putString("energy", "electrique").putString("regime", "location").putInt("cv", 7)
        if (sp.getFloat("prixEnergie", 0.25f) == 0.25f) e.putFloat("prixEnergie", 0.30f)
        if (sp.getFloat("usure", 0.06f) == 0.06f) e.putFloat("usure", 0.05f)
        if (sp.getFloat("kmMois", 4000f) == 4000f) e.putFloat("kmMois", 5000f)
        e.putBoolean("modelY_v2", true).apply()
    }

    var profile: Profile
        get() {
            val d = Profile()
            return Profile(
                energy = sp.getString("energy", d.energy)!!,
                conso = sp.getFloat("conso", d.conso.toFloat()).toDouble(),
                prixEnergie = sp.getFloat("prixEnergie", d.prixEnergie.toFloat()).toDouble(),
                usure = sp.getFloat("usure", d.usure.toFloat()).toDouble(),
                commission = sp.getFloat("commission", d.commission.toFloat()).toDouble(),
                fixesMois = sp.getFloat("fixesMois", d.fixesMois.toFloat()).toDouble(),
                kmMois = sp.getFloat("kmMois", d.kmMois.toFloat()).toDouble(),
                inclureFixes = sp.getBoolean("inclureFixes", d.inclureFixes),
                objectifHeure = sp.getFloat("objectifHeure", d.objectifHeure.toFloat()).toDouble(),
                minimumKm = sp.getFloat("minimumKm", d.minimumKm.toFloat()).toDouble(),
                devise = sp.getString("devise", d.devise)!!,
                cv = sp.getInt("cv", d.cv),
                regime = "location",   // voiture au nom d'un proche : toujours louée à la SASU
                tva = sp.getBoolean("tva", d.tva),
                commissionPlateforme = sp.getFloat("commPlat", d.commissionPlateforme.toFloat()).toDouble(),
                autresFrais = sp.getFloat("autresFrais", d.autresFrais.toFloat()).toDouble(),
                tmi = sp.getFloat("tmi", d.tmi.toFloat()).toDouble(),
                tauxMicro = sp.getFloat("tauxMicro", d.tauxMicro.toFloat()).toDouble()
            )
        }
        set(p) {
            sp.edit()
                .putString("energy", p.energy)
                .putFloat("conso", p.conso.toFloat())
                .putFloat("prixEnergie", p.prixEnergie.toFloat())
                .putFloat("usure", p.usure.toFloat())
                .putFloat("commission", p.commission.toFloat())
                .putFloat("fixesMois", p.fixesMois.toFloat())
                .putFloat("kmMois", p.kmMois.toFloat())
                .putBoolean("inclureFixes", p.inclureFixes)
                .putFloat("objectifHeure", p.objectifHeure.toFloat())
                .putFloat("minimumKm", p.minimumKm.toFloat())
                .putString("devise", p.devise)
                .putInt("cv", p.cv)
                .putString("regime", p.regime)
                .putBoolean("tva", p.tva)
                .putFloat("commPlat", p.commissionPlateforme.toFloat())
                .putFloat("autresFrais", p.autresFrais.toFloat())
                .putFloat("tmi", p.tmi.toFloat())
                .putFloat("tauxMicro", p.tauxMicro.toFloat())
                .apply()
        }

    data class Entry(val t: Long, val prix: Double, val km: Double, val min: Double, val net: Double,
                     val parHeure: Double, val score: Double, val verdict: String, var decision: String)

    fun history(): List<Entry> {
        val arr = JSONArray(sp.getString("history", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getLong("t"), o.getDouble("prix"), o.getDouble("km"), o.getDouble("min"), o.getDouble("net"),
                o.getDouble("parHeure"), o.getDouble("score"), o.getString("verdict"), o.optString("decision", ""))
        }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.take(300).forEach {
            arr.put(JSONObject().put("t", it.t).put("prix", it.prix).put("km", it.km).put("min", it.min)
                .put("net", it.net).put("parHeure", it.parHeure).put("score", it.score)
                .put("verdict", it.verdict).put("decision", it.decision))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** Ajoute une analyse en tête et renvoie son horodatage (sert d'identifiant). */
    fun add(r: Result): Long {
        val e = Entry(System.currentTimeMillis(), r.offer.prix, r.kmTotal, r.minTotal, r.net, r.parHeure, r.score, r.verdict.name, "")
        save(listOf(e) + history())
        return e.t
    }

    fun decide(t: Long, decision: String) {
        val h = history()
        h.find { it.t == t }?.decision = decision
        save(h)
    }

    fun clear() = sp.edit().putString("history", "[]").apply()

    // ------------------------------------------------ Boîte noire : courses (fichier rides.json)

    private val dir = ctx.applicationContext.filesDir
    private val fichierCourses = java.io.File(dir, "rides.json")

    private fun rideJson(r: Ride) = JSONObject().put("debut", r.debut).put("prise", r.priseEnCharge).put("fin", r.fin)
        .put("kmA", r.kmApproche).put("kmC", r.kmCourse).put("prix", r.prix)
        .put("lD", r.lieuDepart).put("lP", r.lieuPrise).put("lA", r.lieuArrivee).put("type", r.type)
        .put("plat", r.plateforme).put("verdict", r.verdict).put("score", r.score)
        .put("oKm", r.offreKm).put("oMin", r.offreMin).put("manuelle", r.manuelle).put("facture", r.facture)
        .put("oD", r.odoDebut).put("oP", r.odoPrise).put("oF", r.odoFin).put("veh", r.vehicule)

    private fun rideDe(o: JSONObject) = Ride(o.getLong("debut"), o.getLong("prise"), o.getLong("fin"),
        o.getDouble("kmA"), o.getDouble("kmC"), o.optDouble("prix", 0.0),
        o.optString("lD", ""), o.optString("lP", ""), o.optString("lA", ""), o.optString("type", "plateforme"),
        o.optString("plat", ""), o.optString("verdict", ""), o.optDouble("score", -1.0),
        o.optDouble("oKm", 0.0), o.optDouble("oMin", 0.0), o.optBoolean("manuelle", false), o.optString("facture", ""),
        o.optDouble("oD", -1.0), o.optDouble("oP", -1.0), o.optDouble("oF", -1.0), o.optString("veh", "").ifBlank { "tesla" })

    fun rides(): List<Ride> = synchronized(VERROU) {
        cacheCourses?.let { return it }
        // Ancien stockage (préférences) : repris une seule fois
        if (!fichierCourses.exists()) {
            val ancien = sp.getString("rides", null)
            if (ancien != null) { fichierCourses.writeText(ancien); sp.edit().remove("rides").apply() }
        }
        val arr = try { JSONArray(if (fichierCourses.exists()) fichierCourses.readText() else "[]") } catch (_: Exception) { JSONArray() }
        val l = (0 until arr.length()).mapNotNull { try { rideDe(arr.getJSONObject(it)) } catch (_: Exception) { null } }
        cacheCourses = l
        l
    }

    private fun saveRides(list: List<Ride>) = synchronized(VERROU) {
        val arr = JSONArray()
        list.sortedBy { it.debut }.forEach { arr.put(rideJson(it)) }
        ecrire(fichierCourses, arr.toString())
        cacheCourses = list.sortedBy { it.debut }
    }

    fun ride(debut: Long) = rides().find { it.debut == debut }

    /** Ajoute ou remplace (même heure de début) une course. */
    fun addRide(r: Ride) = synchronized(VERROU) {
        val v = if (r.vehicule.isBlank()) r.copy(vehicule = vehiculeActif.id) else r
        saveRides(rides().filter { it.debut != r.debut } + v)
    }

    fun updateRide(r: Ride) = addRide(r)

    fun deleteRide(debut: Long) = synchronized(VERROU) {
        saveRides(rides().filter { it.debut != debut })
        java.io.File(dir, "traces/$debut.json").delete()
    }

    /** Modifie une course déjà enregistrée, sans écraser ce qu'un autre fil a ajouté entre-temps. */
    fun modifierRide(debut: Long, f: (Ride) -> Ride) = synchronized(VERROU) {
        val l = rides()
        if (l.none { it.debut == debut }) return@synchronized
        saveRides(l.map { if (it.debut == debut) f(it) else it })
    }

    /** Montant d'une course, saisi ou corrigé après coup. */
    fun setRidePrice(debut: Long, prix: Double) = synchronized(VERROU) {
        saveRides(rides().map { if (it.debut == debut) it.copy(prix = prix) else it })
    }

    /** Écriture sûre : fichier temporaire puis renommage (pas de fichier à moitié écrit si le téléphone s'éteint). */
    private fun ecrire(f: java.io.File, texte: String) {
        f.parentFile?.mkdirs()
        val tmp = java.io.File(f.parentFile, f.name + ".tmp")
        tmp.writeText(texte)
        if (!tmp.renameTo(f)) { f.writeText(texte); tmp.delete() }
    }

    // Tracé GPS de chaque course
    fun saveTrace(debut: Long, points: List<Point>) {
        if (points.isEmpty()) return
        val arr = JSONArray()
        points.forEach { arr.put(JSONArray().put(it.lat).put(it.lon).put(it.t).put(it.phase)) }
        ecrire(java.io.File(dir, "traces/$debut.json"), arr.toString())
    }

    fun trace(debut: Long): List<Point> {
        val f = java.io.File(dir, "traces/$debut.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { val a = arr.getJSONArray(it); Point(a.getDouble(0), a.getDouble(1), a.getLong(2), a.getInt(3)) }
        } catch (_: Exception) { emptyList() }
    }

    // ------------------------------------------------ Carnet kilométrique : domicile et trajets domicile ↔ service

    /** Domicile (latitude, longitude) et son adresse ; null tant qu'il n'est pas enregistré. */
    var domicile: Pair<Double, Double>?
        get() {
            val la = sp.getString("domLat", null)?.toDoubleOrNull() ?: return null
            val lo = sp.getString("domLon", null)?.toDoubleOrNull() ?: return null
            return la to lo
        }
        set(v) {
            if (v == null) sp.edit().remove("domLat").remove("domLon").apply()
            else sp.edit().putString("domLat", v.first.toString()).putString("domLon", v.second.toString()).apply()
        }

    var adresseDomicile: String
        get() = sp.getString("domAdresse", "")!!
        set(v) = sp.edit().putString("domAdresse", v).apply()

    private val fichierSegments = java.io.File(dir, "segments.json")

    fun segments(): List<Segment> = synchronized(VERROU) {
        val arr = try { JSONArray(if (fichierSegments.exists()) fichierSegments.readText() else "[]") } catch (_: Exception) { JSONArray() }
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Segment(o.getLong("debut"), o.getLong("fin"), o.getString("type"), o.getDouble("km"), o.optString("lD"), o.optString("lA"))
        }
    }

    fun addSegment(sg: Segment) = synchronized(VERROU) {
        val arr = JSONArray()
        (segments().filter { it.debut != sg.debut } + sg).sortedBy { it.debut }.forEach {
            arr.put(JSONObject().put("debut", it.debut).put("fin", it.fin).put("type", it.type).put("km", it.km)
                .put("lD", it.lieuDepart).put("lA", it.lieuArrivee))
        }
        ecrire(fichierSegments, arr.toString())
    }

    fun deleteSegment(debut: Long) = synchronized(VERROU) {
        val arr = JSONArray()
        segments().filter { it.debut != debut }.forEach {
            arr.put(JSONObject().put("debut", it.debut).put("fin", it.fin).put("type", it.type).put("km", it.km)
                .put("lD", it.lieuDepart).put("lA", it.lieuArrivee))
        }
        ecrire(fichierSegments, arr.toString())
        java.io.File(dir, "traces/s$debut.json").delete()
    }

    fun saveTraceSegment(debut: Long, points: List<Point>) {
        if (points.isEmpty()) return
        val arr = JSONArray()
        points.forEach { arr.put(JSONArray().put(it.lat).put(it.lon).put(it.t).put(it.phase)) }
        ecrire(java.io.File(dir, "traces/s$debut.json"), arr.toString())
    }

    fun traceSegment(debut: Long): List<Point> {
        val f = java.io.File(dir, "traces/s$debut.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { val a = arr.getJSONArray(it); Point(a.getDouble(0), a.getDouble(1), a.getLong(2), a.getInt(3)) }
        } catch (_: Exception) { emptyList() }
    }

    // ------------------------------------------------ Temps de service (bulle lancée) et objectif du jour

    /** Début du service en cours (bulle lancée), 0 si arrêté. */
    var serviceDebut: Long
        get() = sp.getLong("serviceDebut", 0L)
        set(v) = sp.edit().putLong("serviceDebut", v).apply()

    /** Minutes de service par jour (« 2026-11-07 » → minutes). */
    fun minutesService(): Map<String, Double> = mapJson("serviceMin")

    fun ajouterService(debut: Long, fin: Long) {
        if (debut <= 0 || fin <= debut) return
        val j = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.FRANCE).format(java.util.Date(debut))
        val m = minutesService().toMutableMap()
        m[j] = (m[j] ?: 0.0) + (fin - debut) / 60000.0
        sp.edit().putString("serviceMin", JSONObject(m as Map<*, *>).toString()).apply()
    }

    private fun mapJson(cle: String): Map<String, Double> = try {
        val o = JSONObject(sp.getString(cle, "{}")!!)
        o.keys().asSequence().associateWith { o.getDouble(it) }
    } catch (_: Exception) { emptyMap() }

    /** Objectif d'encaissement par jour (€). */
    var objectifJour: Double
        get() = sp.getFloat("objectifJour", 200f).toDouble()
        set(v) = sp.edit().putFloat("objectifJour", v.toFloat()).apply()

    // ------------------------------------------------ Tesla (Teslemetry)

    var teslaJeton: String
        get() = sp.getString("teslaJeton", "")!!
        set(v) = sp.edit().putString("teslaJeton", v.trim()).apply()
    var teslaVin: String
        get() = sp.getString("teslaVin", "")!!
        set(v) = sp.edit().putString("teslaVin", v).apply()
    var teslaNom: String
        get() = sp.getString("teslaNom", "")!!
        set(v) = sp.edit().putString("teslaNom", v).apply()
    /** Tesla connectée ET véhicule actif = Tesla (avec un autre véhicule, rien n'est lu chez Teslemetry). */
    val teslaActive get() = teslaJeton.isNotBlank() && teslaVin.isNotBlank() && vehiculeActif.connectee
    val teslaConnectee get() = teslaJeton.isNotBlank() && teslaVin.isNotBlank()

    /** Dernier état lu (affichage, alerte d'autonomie). */
    var derniereTesla: Tesla.Etat?
        get() = Tesla.Etat.de(sp.getString("teslaEtat", null))
        set(v) = sp.edit().putString("teslaEtat", v?.json()).apply()

    /** État de référence pour détecter les recharges (dernier état hors charge). */
    var teslaReference: Tesla.Etat?
        get() = Tesla.Etat.de(sp.getString("teslaRef", null))
        set(v) = sp.edit().putString("teslaRef", v?.json()).apply()

    /** Prix du kWh : à domicile (prise ou wallbox) et sur borne / Superchargeur. */
    var prixKwhDomicile: Double
        get() = sp.getFloat("prixKwhDom", 0.20f).toDouble()
        set(v) = sp.edit().putFloat("prixKwhDom", v.toFloat()).apply()
    var prixKwhBorne: Double
        get() = sp.getFloat("prixKwhBorne", 0.45f).toDouble()
        set(v) = sp.edit().putFloat("prixKwhBorne", v.toFloat()).apply()

    /** Recharges ajoutées toutes seules aux frais, et consommation réelle utilisée pour juger les offres. */
    var rechargesAuto: Boolean
        get() = sp.getBoolean("rechargesAuto", true)
        set(v) = sp.edit().putBoolean("rechargesAuto", v).apply()
    var consoAuto: Boolean
        get() = sp.getBoolean("consoAuto", true)
        set(v) = sp.edit().putBoolean("consoAuto", v).apply()

    private val fichierReleves = java.io.File(dir, "releves.json")

    fun releves(): List<Releve> = synchronized(VERROU) {
        val arr = try { JSONArray(if (fichierReleves.exists()) fichierReleves.readText() else "[]") } catch (_: Exception) { JSONArray() }
        (0 until arr.length()).mapNotNull {
            val o = arr.optJSONObject(it) ?: return@mapNotNull null
            Releve(o.getLong("t"), o.optString("type"), o.getDouble("odo"), o.optDouble("bat", -1.0), o.optDouble("aut", -1.0),
                o.optDouble("lat", 0.0), o.optDouble("lon", 0.0), o.optLong("maj", 0L), o.optString("note", ""),
                o.optString("photo", ""), o.optString("veh", "").ifBlank { "tesla" })
        }
    }

    fun addReleve(r: Releve) = synchronized(VERROU) {
        val v = if (r.vehicule.isBlank()) r.copy(vehicule = vehiculeActif.id) else r
        saveReleves(releves().filter { it.t != v.t } + v)
    }

    private fun saveReleves(l: List<Releve>) = synchronized(VERROU) {
        val arr = JSONArray()
        l.sortedBy { it.t }.forEach {
            arr.put(JSONObject().put("t", it.t).put("type", it.type).put("odo", it.odoKm).put("bat", it.batterie).put("aut", it.autonomieKm)
                .put("lat", it.lat).put("lon", it.lon).put("maj", it.majVoiture).put("note", it.note)
                .put("photo", it.photo).put("veh", it.vehicule))
        }
        ecrire(fichierReleves, arr.toString())
    }

    fun supprimerReleve(t: Long) = synchronized(VERROU) {
        releves().find { it.t == t }?.photo?.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
        saveReleves(releves().filter { it.t != t })
    }

    /** Clé TomTom (trafic réel et tracés recalés sur les routes) ; vide = trafic habituel selon l'heure. */
    var cleTomTom: String
        get() = sp.getString("cleTomTom", "")!!
        set(v) = sp.edit().putString("cleTomTom", v.trim()).apply()

    /** Tracé recalé sur les routes, gardé en cache (pas de nouvelle demande à chaque ouverture). */
    fun routeRecalee(cle: String): String? = java.io.File(dir, "traces/route-$cle.json").takeIf { it.exists() }?.readText()
    fun saveRouteRecalee(cle: String, json: String) = ecrire(java.io.File(dir, "traces/route-$cle.json"), json)

    /** Dernière plateforme reconnue (sert quand l'offre lue ne la nomme pas). */
    var dernierePlateforme: String
        get() = sp.getString("dernierePlateforme", "Uber")!!
        set(v) = sp.edit().putString("dernierePlateforme", v).apply()

    // ------------------------------------------------ Frais

    private val fichierFrais = java.io.File(dir, "frais.json")

    fun frais(): List<Frais> = synchronized(VERROU) {
        cacheFrais?.let { return it }
        val arr = try { JSONArray(if (fichierFrais.exists()) fichierFrais.readText() else "[]") } catch (_: Exception) { JSONArray() }
        val l = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Frais(o.getLong("id"), o.getLong("date"), Categorie.de(o.optString("cat")), o.getDouble("ttc"), o.optDouble("tva", 20.0),
                o.optString("note", ""), o.optString("photo", ""), o.optBoolean("mensuel", false), o.optLong("fin", 0L))
        }
        cacheFrais = l
        l
    }

    private fun saveFrais(l: List<Frais>) = synchronized(VERROU) {
        val arr = JSONArray()
        l.sortedBy { it.date }.forEach {
            arr.put(JSONObject().put("id", it.id).put("date", it.date).put("cat", it.categorie.name).put("ttc", it.ttc)
                .put("tva", it.tauxTva).put("note", it.note).put("photo", it.photo).put("mensuel", it.mensuel).put("fin", it.finMensuel))
        }
        ecrire(fichierFrais, arr.toString())
        cacheFrais = l.sortedBy { it.date }
    }

    fun addFrais(f: Frais) = synchronized(VERROU) { saveFrais(frais().filter { it.id != f.id } + f) }

    fun deleteFrais(id: Long) = synchronized(VERROU) {
        frais().find { it.id == id }?.photo?.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
        saveFrais(frais().filter { it.id != id })
    }

    fun fraisDuMois(annee: Int, mois: Int) = frais().filter { it.dansMois(annee, mois) }

    // ------------------------------------------------ Factures et clients

    private val fichierFactures = java.io.File(dir, "factures.json")

    private fun clientJson(c: Client) = JSONObject().put("nom", c.nom).put("societe", c.societe).put("siren", c.siren)
        .put("adresse", c.adresse).put("email", c.email).put("tel", c.tel)

    private fun clientDe(o: JSONObject) = Client(o.optString("nom"), o.optString("societe"), o.optString("siren"),
        o.optString("adresse"), o.optString("email"), o.optString("tel"))

    fun factures(): List<Facture> = synchronized(VERROU) {
        val arr = try { JSONArray(if (fichierFactures.exists()) fichierFactures.readText() else "[]") } catch (_: Exception) { JSONArray() }
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Facture(o.getString("numero"), o.getLong("course"), o.getLong("emission"), clientDe(o.getJSONObject("client")),
                o.optString("paiement", ""), o.optLong("reservation", 0L), o.optString("signature", ""), o.optLong("signeLe", 0L))
        }
    }

    fun facture(course: Long) = factures().find { it.course == course }

    fun saveFacture(f: Facture) = synchronized(VERROU) {
        val arr = JSONArray()
        (factures().filter { it.numero != f.numero } + f).sortedBy { it.numero }.forEach {
            arr.put(JSONObject().put("numero", it.numero).put("course", it.course).put("emission", it.emission)
                .put("client", clientJson(it.client)).put("paiement", it.paiement).put("reservation", it.reservation)
                .put("signature", it.signature).put("signeLe", it.signeLe))
        }
        ecrire(fichierFactures, arr.toString())
        // Carnet de clients pour les habitués
        if (f.client.nom.isNotBlank()) {
            val cl = clients().filter { !it.nom.equals(f.client.nom, true) } + f.client
            val ca = JSONArray(); cl.sortedBy { it.nom.lowercase() }.forEach { ca.put(clientJson(it)) }
            ecrire(java.io.File(dir, "clients.json"), ca.toString())
        }
    }

    fun clients(): List<Client> {
        val f = java.io.File(dir, "clients.json")
        val arr = try { JSONArray(if (f.exists()) f.readText() else "[]") } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { clientDe(arr.getJSONObject(it)) }
    }

    // Brouillon d'une course privée pas encore validée : signature du client déjà prise, facture à finir plus tard
    private fun fichierBrouillon(debut: Long) = java.io.File(dir, "brouillons/$debut.json")

    fun brouillon(debut: Long): JSONObject? = try {
        fichierBrouillon(debut).takeIf { it.exists() }?.let { JSONObject(it.readText()) }
    } catch (_: Exception) { null }

    fun saveBrouillon(debut: Long, o: JSONObject) = ecrire(fichierBrouillon(debut), o.toString())

    fun supprimerBrouillon(debut: Long) {
        brouillon(debut)?.optString("signature")?.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
        fichierBrouillon(debut).delete()
    }

    /** Le client a-t-il déjà signé cette course (facture pas encore finie) ? */
    fun dejaSignee(debut: Long) = brouillon(debut)?.optString("signature")?.let { it.isNotBlank() && java.io.File(it).exists() } ?: false

    /**
     * Supprime la facture d'une course (essai, erreur) avec sa signature.
     * Si c'était le dernier numéro émis de l'année, il est rendu : la numérotation reste sans trou.
     */
    fun supprimerFacture(course: Long) = synchronized(VERROU) {
        val f = facture(course) ?: return@synchronized
        f.signature.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
        val arr = JSONArray()
        factures().filter { it.numero != f.numero }.sortedBy { it.numero }.forEach {
            arr.put(JSONObject().put("numero", it.numero).put("course", it.course).put("emission", it.emission)
                .put("client", clientJson(it.client)).put("paiement", it.paiement).put("reservation", it.reservation)
                .put("signature", it.signature).put("signeLe", it.signeLe))
        }
        ecrire(fichierFactures, arr.toString())
        val m = Regex("F-(\\d{4})-(\\d{4})").matchEntire(f.numero) ?: return@synchronized
        val cle = "numFacture_${m.groupValues[1]}"
        if (sp.getInt(cle, 0) == m.groupValues[2].toInt()) sp.edit().putInt(cle, sp.getInt(cle, 0) - 1).commit()
    }

    /** Prochain numéro de facture, sans trou : F-2026-0001, F-2026-0002… (réservé dès l'appel). */
    fun nouveauNumero(annee: Int): String = synchronized(VERROU) {
        val cle = "numFacture_$annee"
        val n = sp.getInt(cle, 0) + 1
        sp.edit().putInt(cle, n).commit()
        String.format("F-%04d-%04d", annee, n)
    }

    var entreprise: Entreprise
        get() = Entreprise(
            sp.getString("e_raison", "")!!, sp.getString("e_forme", "SASU")!!, sp.getString("e_capital", "")!!,
            sp.getString("e_adresse", "")!!, sp.getString("e_siret", "")!!, sp.getString("e_rcs", "")!!,
            sp.getString("e_tva", "")!!, sp.getString("e_evtc", "")!!, sp.getString("e_chauffeur", "")!!,
            sp.getString("e_tel", "")!!, sp.getString("e_email", "")!!, sp.getString("e_message", Entreprise.MESSAGE_DEFAUT)!!)
        set(e) = sp.edit().putString("e_raison", e.raisonSociale).putString("e_forme", e.forme).putString("e_capital", e.capital)
            .putString("e_adresse", e.adresse).putString("e_siret", e.siret).putString("e_rcs", e.rcs).putString("e_tva", e.tvaIntra)
            .putString("e_evtc", e.evtc).putString("e_chauffeur", e.chauffeur).putString("e_tel", e.tel).putString("e_email", e.email)
            .putString("e_message", e.message).apply()

    /** Km roulés bulle active, par jour ("aaaa-mm-jj"). */
    fun service(): Map<String, Double> {
        val o = JSONObject(sp.getString("service", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addService(jour: String, km: Double) = addKm("service", jour, km)

    /** Km roulés en mode perso : gardés à part, jamais comptés dans les indemnités. */
    fun perso(): Map<String, Double> {
        val o = JSONObject(sp.getString("perso", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addPerso(jour: String, km: Double) = addKm("perso", jour, km)

    private fun addKm(cle: String, jour: String, km: Double) {
        if (km == 0.0) return
        val o = JSONObject(sp.getString(cle, "{}"))
        o.put(jour, maxOf(0.0, o.optDouble(jour, 0.0) + km))   // km négatifs = annulation d'un classement
        sp.edit().putString(cle, o.toString()).apply()
    }

    /** Situation du foyer pour l'optimisation fiscale. */
    var situation: Optimiseur.Situation
        get() = Optimiseur.Situation(
            parts = sp.getFloat("optParts", 1f).toDouble(),
            couple = sp.getBoolean("optCouple", false),
            autresRevenus = sp.getFloat("optAutres", 0f).toDouble(),
            retraite = sp.getBoolean("optRetraite", true))
        set(s) = sp.edit().putFloat("optParts", s.parts.toFloat()).putBoolean("optCouple", s.couple)
            .putFloat("optAutres", s.autresRevenus.toFloat()).putBoolean("optRetraite", s.retraite).apply()

    /** Prévision (versements par mois, km pro par mois) ; 0 = utiliser les vraies courses. */
    var prevision: Pair<Double, Double>
        get() = sp.getFloat("prevGains", 0f).toDouble() to sp.getFloat("prevKm", 4000f).toDouble()
        set(v) = sp.edit().putFloat("prevGains", v.first.toFloat()).putFloat("prevKm", v.second.toFloat()).apply()

    // ------------------------------------------------ Trajets détectés automatiquement

    var autoTrajets: Boolean
        get() = sp.getBoolean("autoTrajets", false)
        set(v) = sp.edit().putBoolean("autoTrajets", v).apply()

    @Synchronized
    fun trajets(): List<Trajet> {
        val arr = JSONArray(sp.getString("trajets", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Trajet(o.getLong("debut"), o.getLong("fin"), o.getDouble("km"), o.optString("de", ""), o.optString("a", ""),
                o.optString("statut", Trajet.A_CLASSER), o.optString("raison", ""), o.optString("veh", "").ifBlank { "tesla" }, o.optBoolean("manuel", false))
        }
    }

    @Synchronized
    private fun saveTrajets(list: List<Trajet>) {
        val arr = JSONArray()
        list.sortedByDescending { it.debut }.take(1000).forEach {
            arr.put(JSONObject().put("debut", it.debut).put("fin", it.fin).put("km", it.km)
                .put("de", it.depart).put("a", it.arrivee).put("statut", it.statut).put("raison", it.raison)
                .put("veh", it.vehicule).put("manuel", it.manuel))
        }
        sp.edit().putString("trajets", arr.toString()).commit()
    }

    /** Ajoute un trajet « à classer » (le classement passe ensuite par [classer], qui compte ses km). */
    @Synchronized
    fun addTrajet(t: Trajet) {
        val old = trajets().find { it.debut == t.debut }
        if (old != null) classer(old.debut, Trajet.A_CLASSER)
        saveTrajets(trajets().filter { it.debut != t.debut } + t.copy(statut = Trajet.A_CLASSER,
            vehicule = t.vehicule.ifBlank { vehiculeActif.id }))
        if (t.statut != Trajet.A_CLASSER) classer(t.debut, t.statut, t.raison)
    }

    /**
     * Classe un trajet : ses km vont dans les km pro ou perso du jour (et quittent l'ancien classement).
     * [raison] non vide = classé automatiquement (affiché « auto · raison », modifiable d'un geste).
     */
    @Synchronized
    fun classer(debut: Long, statut: String, raison: String = "") {
        val list = trajets()
        val t = list.find { it.debut == debut } ?: return
        if (t.statut == statut && t.raison == raison) return
        val jour = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.FRANCE).format(java.util.Date(t.debut))
        if (t.statut != statut) {
            when (t.statut) { Trajet.PRO -> addService(jour, -t.km); Trajet.PERSO -> addPerso(jour, -t.km) }
            when (statut) { Trajet.PRO -> addService(jour, t.km); Trajet.PERSO -> addPerso(jour, t.km) }
        }
        saveTrajets(list.map { if (it.debut == debut) it.copy(statut = statut, raison = raison) else it })
    }

    fun supprimerTrajet(debut: Long) {
        classer(debut, Trajet.A_CLASSER)
        saveTrajets(trajets().filter { it.debut != debut })
    }

    var modePerso: Boolean
        get() = sp.getBoolean("modePerso", false)
        set(v) = sp.edit().putBoolean("modePerso", v).apply()

    // ------------------------------------------------ Véhicules

    /** Véhicules enregistrés ; au premier lancement : la Tesla Model Y d'origine. */
    fun vehicules(): List<Vehicule> {
        val l = Vehicule.liste(sp.getString("vehicules", null))
        if (l.isNotEmpty()) return l
        val p = profile
        val m = Modeles.LISTE[0]
        val t = Vehicule("tesla", m.nom, "", m.batterie, p.conso, m.places, p.cv, Vehicule.TESLA)
        sp.edit().putString("vehicules", Vehicule.texte(listOf(t))).putString("vehiculeActif", t.id).apply()
        return listOf(t)
    }

    fun vehicule(id: String) = vehicules().find { it.id == id }

    val vehiculeActif: Vehicule
        get() { val l = vehicules(); val id = sp.getString("vehiculeActif", "") ?: ""; return l.find { it.id == id } ?: l.first() }

    /** Ajoute ou modifie un véhicule. */
    fun saveVehicule(v: Vehicule) {
        val l = vehicules()
        sp.edit().putString("vehicules", Vehicule.texte(if (l.any { it.id == v.id }) l.map { if (it.id == v.id) v else it } else l + v)).apply()
        if (v.id == vehiculeActif.id) appliquerVehicule(v)
    }

    fun supprimerVehicule(id: String) {
        val l = vehicules().filter { it.id != id }
        if (l.isEmpty()) return
        sp.edit().putString("vehicules", Vehicule.texte(l)).apply()
        if (sp.getString("vehiculeActif", "") == id) choisirVehicule(l.first().id)
    }

    /** Change de véhicule : consommation et puissance fiscale du calcul des offres suivent. */
    fun choisirVehicule(id: String) {
        val v = vehicule(id) ?: return
        sp.edit().putString("vehiculeActif", v.id).apply()
        appliquerVehicule(v)
    }

    private fun appliquerVehicule(v: Vehicule) {
        val p = profile
        profile = p.copy(conso = v.conso, cv = v.cv, energy = "electrique")
    }

    // ------------------------------------------------ Lieux favoris et classement automatique des trajets

    fun favoris(): List<Favori> = Favori.liste(sp.getString("favoris", null))

    fun saveFavori(f: Favori) {
        val l = favoris().filter { it.id != f.id } + f
        sp.edit().putString("favoris", Favori.texte(l.sortedBy { it.nom.lowercase() })).apply()
    }

    /** Favoris + le domicile (lieu perso), pour nommer et classer les trajets. */
    fun favorisEtDomicile(): List<Favori> = favoris() + listOfNotNull(domicile?.let { Favori("domicile", "Domicile", it.first, it.second, Favori.PERSO) })

    fun supprimerFavori(id: String) = sp.edit().putString("favoris", Favori.texte(favoris().filter { it.id != id })).apply()

    /** Applique le classement automatique à un trajet tout juste enregistré ; renvoie la raison (null = à classer). */
    fun classerAuto(t: Trajet): String? {
        if (!classementAuto) return null
        val (statut, raison) = Classement.proposer(t, favoris(), trajets(), heuresTravail, domicile) ?: return null
        classer(t.debut, statut, raison)
        return raison
    }

    /** Classer tout seul les trajets détectés (heures de travail, lieux, habitudes). */
    var classementAuto: Boolean
        get() = sp.getBoolean("classementAuto", true)
        set(v) = sp.edit().putBoolean("classementAuto", v).apply()

    /** Heures de travail : jours (1 = lundi … 7 = dimanche) et plage horaire en minutes depuis minuit. */
    var heuresTravail: HeuresTravail
        get() = HeuresTravail(sp.getBoolean("htActif", false),
            (sp.getString("htJours", "1,2,3,4,5,6") ?: "").split(",").mapNotNull { it.trim().toIntOrNull() }.toSet(),
            sp.getInt("htDebut", 7 * 60), sp.getInt("htFin", 21 * 60))
        set(h) = sp.edit().putBoolean("htActif", h.actif).putString("htJours", h.jours.sorted().joinToString(","))
            .putInt("htDebut", h.debut).putInt("htFin", h.fin).apply()
}
