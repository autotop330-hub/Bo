package fr.bonnecourse

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Profil et historique, enregistrés sur le téléphone. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("bonnecourse", Context.MODE_PRIVATE)

    var profile: Profile
        get() {
            val d = Profile()
            return Profile(
                energy = sp.getString("energy", d.energy)!!,
                conso = sp.getFloat("conso", d.conso.toFloat()).toDouble(),
                prixEnergie = sp.getFloat("prixEnergie", d.prixEnergie.toFloat()).toDouble(),
                usure = sp.getFloat("usure", d.usure.toFloat()).toDouble(),
                commission = sp.getFloat("commission", d.commission.toFloat()).toDouble(),
                fixesMois = sp.getFloat("fixesMois", d.fixesMois.toFloat()).toDouble(),
                kmMois = sp.getFloat("kmMois", d.kmMois.toFloat()).toDouble(),
                inclureFixes = sp.getBoolean("inclureFixes", d.inclureFixes),
                objectifHeure = sp.getFloat("objectifHeure", d.objectifHeure.toFloat()).toDouble(),
                minimumKm = sp.getFloat("minimumKm", d.minimumKm.toFloat()).toDouble(),
                devise = sp.getString("devise", d.devise)!!,
                cv = sp.getInt("cv", d.cv),
                regime = sp.getString("regime", d.regime)!!,
                tva = sp.getBoolean("tva", d.tva),
                commissionPlateforme = sp.getFloat("commPlat", d.commissionPlateforme.toFloat()).toDouble(),
                autresFrais = sp.getFloat("autresFrais", d.autresFrais.toFloat()).toDouble(),
                tmi = sp.getFloat("tmi", d.tmi.toFloat()).toDouble(),
                tauxMicro = sp.getFloat("tauxMicro", d.tauxMicro.toFloat()).toDouble()
            )
        }
        set(p) {
            sp.edit()
                .putString("energy", p.energy)
                .putFloat("conso", p.conso.toFloat())
                .putFloat("prixEnergie", p.prixEnergie.toFloat())
                .putFloat("usure", p.usure.toFloat())
                .putFloat("commission", p.commission.toFloat())
                .putFloat("fixesMois", p.fixesMois.toFloat())
                .putFloat("kmMois", p.kmMois.toFloat())
                .putBoolean("inclureFixes", p.inclureFixes)
                .putFloat("objectifHeure", p.objectifHeure.toFloat())
                .putFloat("minimumKm", p.minimumKm.toFloat())
                .putString("devise", p.devise)
                .putInt("cv", p.cv)
                .putString("regime", p.regime)
                .putBoolean("tva", p.tva)
                .putFloat("commPlat", p.commissionPlateforme.toFloat())
                .putFloat("autresFrais", p.autresFrais.toFloat())
                .putFloat("tmi", p.tmi.toFloat())
                .putFloat("tauxMicro", p.tauxMicro.toFloat())
                .apply()
        }

    data class Entry(val t: Long, val prix: Double, val km: Double, val min: Double, val net: Double,
                     val parHeure: Double, val score: Double, val verdict: String, var decision: String)

    fun history(): List<Entry> {
        val arr = JSONArray(sp.getString("history", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getLong("t"), o.getDouble("prix"), o.getDouble("km"), o.getDouble("min"), o.getDouble("net"),
                o.getDouble("parHeure"), o.getDouble("score"), o.getString("verdict"), o.optString("decision", ""))
        }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.take(300).forEach {
            arr.put(JSONObject().put("t", it.t).put("prix", it.prix).put("km", it.km).put("min", it.min)
                .put("net", it.net).put("parHeure", it.parHeure).put("score", it.score)
                .put("verdict", it.verdict).put("decision", it.decision))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** Ajoute une analyse en tête et renvoie son horodatage (sert d'identifiant). */
    fun add(r: Result): Long {
        val e = Entry(System.currentTimeMillis(), r.offer.prix, r.kmTotal, r.minTotal, r.net, r.parHeure, r.score, r.verdict.name, "")
        save(listOf(e) + history())
        return e.t
    }

    fun decide(t: Long, decision: String) {
        val h = history()
        h.find { it.t == t }?.decision = decision
        save(h)
    }

    fun clear() = sp.edit().putString("history", "[]").apply()

    // ------------------------------------------------ Kilométrage

    fun rides(): List<Ride> {
        val arr = JSONArray(sp.getString("rides", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Ride(o.getLong("debut"), o.getLong("prise"), o.getLong("fin"),
                o.getDouble("kmA"), o.getDouble("kmC"), o.optDouble("prix", 0.0),
                o.optString("lD", ""), o.optString("lP", ""), o.optString("lA", ""), o.optString("type", "plateforme"))
        }
    }

    fun addRide(r: Ride) {
        val arr = JSONArray(sp.getString("rides", "[]"))
        arr.put(JSONObject().put("debut", r.debut).put("prise", r.priseEnCharge).put("fin", r.fin)
            .put("kmA", r.kmApproche).put("kmC", r.kmCourse).put("prix", r.prix)
            .put("lD", r.lieuDepart).put("lP", r.lieuPrise).put("lA", r.lieuArrivee).put("type", r.type))
        sp.edit().putString("rides", arr.toString()).apply()
    }

    private fun saveRides(list: List<Ride>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("debut", it.debut).put("prise", it.priseEnCharge).put("fin", it.fin)
                .put("kmA", it.kmApproche).put("kmC", it.kmCourse).put("prix", it.prix)
                .put("lD", it.lieuDepart).put("lP", it.lieuPrise).put("lA", it.lieuArrivee).put("type", it.type))
        }
        sp.edit().putString("rides", arr.toString()).apply()
    }

    fun deleteRide(debut: Long) = saveRides(rides().filter { it.debut != debut })

    /** Montant d'une course client privé, saisi après coup. */
    fun setRidePrice(debut: Long, prix: Double) = saveRides(rides().map { if (it.debut == debut) it.copy(prix = prix) else it })

    /** Km roulés bulle active, par jour ("aaaa-mm-jj"). */
    fun service(): Map<String, Double> {
        val o = JSONObject(sp.getString("service", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addService(jour: String, km: Double) = addKm("service", jour, km)

    /** Km roulés en mode perso : gardés à part, jamais comptés dans les indemnités. */
    fun perso(): Map<String, Double> {
        val o = JSONObject(sp.getString("perso", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addPerso(jour: String, km: Double) = addKm("perso", jour, km)

    private fun addKm(cle: String, jour: String, km: Double) {
        if (km == 0.0) return
        val o = JSONObject(sp.getString(cle, "{}"))
        o.put(jour, maxOf(0.0, o.optDouble(jour, 0.0) + km))   // km négatifs = annulation d'un classement
        sp.edit().putString(cle, o.toString()).apply()
    }

    /** Situation du foyer pour l'optimisation fiscale. */
    var situation: Optimiseur.Situation
        get() = Optimiseur.Situation(
            parts = sp.getFloat("optParts", 1f).toDouble(),
            couple = sp.getBoolean("optCouple", false),
            autresRevenus = sp.getFloat("optAutres", 0f).toDouble(),
            retraite = sp.getBoolean("optRetraite", true))
        set(s) = sp.edit().putFloat("optParts", s.parts.toFloat()).putBoolean("optCouple", s.couple)
            .putFloat("optAutres", s.autresRevenus.toFloat()).putBoolean("optRetraite", s.retraite).apply()

    /** Prévision (versements par mois, km pro par mois) ; 0 = utiliser les vraies courses. */
    var prevision: Pair<Double, Double>
        get() = sp.getFloat("prevGains", 0f).toDouble() to sp.getFloat("prevKm", 4000f).toDouble()
        set(v) = sp.edit().putFloat("prevGains", v.first.toFloat()).putFloat("prevKm", v.second.toFloat()).apply()

    // ------------------------------------------------ Trajets détectés automatiquement

    var autoTrajets: Boolean
        get() = sp.getBoolean("autoTrajets", false)
        set(v) = sp.edit().putBoolean("autoTrajets", v).apply()

    @Synchronized
    fun trajets(): List<Trajet> {
        val arr = JSONArray(sp.getString("trajets", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Trajet(o.getLong("debut"), o.getLong("fin"), o.getDouble("km"), o.optString("de", ""), o.optString("a", ""),
                o.optString("statut", Trajet.A_CLASSER))
        }
    }

    @Synchronized
    private fun saveTrajets(list: List<Trajet>) {
        val arr = JSONArray()
        list.sortedByDescending { it.debut }.take(1000).forEach {
            arr.put(JSONObject().put("debut", it.debut).put("fin", it.fin).put("km", it.km)
                .put("de", it.depart).put("a", it.arrivee).put("statut", it.statut))
        }
        sp.edit().putString("trajets", arr.toString()).commit()
    }

    @Synchronized
    fun addTrajet(t: Trajet) = saveTrajets(trajets().filter { it.debut != t.debut } + t)

    /** Classe un trajet : ses km vont dans les km pro ou perso du jour (et quittent l'ancien classement). */
    @Synchronized
    fun classer(debut: Long, statut: String) {
        val list = trajets()
        val t = list.find { it.debut == debut } ?: return
        if (t.statut == statut) return
        val jour = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.FRANCE).format(java.util.Date(t.debut))
        when (t.statut) { Trajet.PRO -> addService(jour, -t.km); Trajet.PERSO -> addPerso(jour, -t.km) }
        when (statut) { Trajet.PRO -> addService(jour, t.km); Trajet.PERSO -> addPerso(jour, t.km) }
        saveTrajets(list.map { if (it.debut == debut) it.copy(statut = statut) else it })
    }

    fun supprimerTrajet(debut: Long) {
        classer(debut, Trajet.A_CLASSER)
        saveTrajets(trajets().filter { it.debut != debut })
    }

    var modePerso: Boolean
        get() = sp.getBoolean("modePerso", false)
        set(v) = sp.edit().putBoolean("modePerso", v).apply()
}
