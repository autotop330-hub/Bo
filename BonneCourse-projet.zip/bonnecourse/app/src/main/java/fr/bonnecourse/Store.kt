package fr.bonnecourse

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Profil et historique, enregistrés sur le téléphone. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("bonnecourse", Context.MODE_PRIVATE)

    companion object {
        private val VERROU = Any()
        @Volatile private var cacheCourses: List<Ride>? = null
        @Volatile private var cacheFrais: List<Frais>? = null
    }

    init { adapterModelY() }

    /**
     * Situation du chauffeur : SASU, Tesla Model Y Grande Autonomie Propulsion au nom d'un proche,
     * louée à la société. Appliqué une fois ; les valeurs déjà changées à la main sont gardées.
     */
    private fun adapterModelY() {
        if (sp.getBoolean("modelY_v2", false)) return
        val e = sp.edit().putString("energy", "electrique").putString("regime", "location").putInt("cv", 7)
        if (sp.getFloat("prixEnergie", 0.25f) == 0.25f) e.putFloat("prixEnergie", 0.30f)
        if (sp.getFloat("usure", 0.06f) == 0.06f) e.putFloat("usure", 0.05f)
        if (sp.getFloat("kmMois", 4000f) == 4000f) e.putFloat("kmMois", 5000f)
        e.putBoolean("modelY_v2", true).apply()
    }

    var profile: Profile
        get() {
            val d = Profile()
            return Profile(
                energy = sp.getString("energy", d.energy)!!,
                conso = sp.getFloat("conso", d.conso.toFloat()).toDouble(),
                prixEnergie = sp.getFloat("prixEnergie", d.prixEnergie.toFloat()).toDouble(),
                usure = sp.getFloat("usure", d.usure.toFloat()).toDouble(),
                commission = sp.getFloat("commission", d.commission.toFloat()).toDouble(),
                fixesMois = sp.getFloat("fixesMois", d.fixesMois.toFloat()).toDouble(),
                kmMois = sp.getFloat("kmMois", d.kmMois.toFloat()).toDouble(),
                inclureFixes = sp.getBoolean("inclureFixes", d.inclureFixes),
                objectifHeure = sp.getFloat("objectifHeure", d.objectifHeure.toFloat()).toDouble(),
                minimumKm = sp.getFloat("minimumKm", d.minimumKm.toFloat()).toDouble(),
                devise = sp.getString("devise", d.devise)!!,
                cv = sp.getInt("cv", d.cv),
                regime = "location",   // voiture au nom d'un proche : toujours louée à la SASU
                tva = sp.getBoolean("tva", d.tva),
                commissionPlateforme = sp.getFloat("commPlat", d.commissionPlateforme.toFloat()).toDouble(),
                autresFrais = sp.getFloat("autresFrais", d.autresFrais.toFloat()).toDouble(),
                tmi = sp.getFloat("tmi", d.tmi.toFloat()).toDouble(),
                tauxMicro = sp.getFloat("tauxMicro", d.tauxMicro.toFloat()).toDouble()
            )
        }
        set(p) {
            sp.edit()
                .putString("energy", p.energy)
                .putFloat("conso", p.conso.toFloat())
                .putFloat("prixEnergie", p.prixEnergie.toFloat())
                .putFloat("usure", p.usure.toFloat())
                .putFloat("commission", p.commission.toFloat())
                .putFloat("fixesMois", p.fixesMois.toFloat())
                .putFloat("kmMois", p.kmMois.toFloat())
                .putBoolean("inclureFixes", p.inclureFixes)
                .putFloat("objectifHeure", p.objectifHeure.toFloat())
                .putFloat("minimumKm", p.minimumKm.toFloat())
                .putString("devise", p.devise)
                .putInt("cv", p.cv)
                .putString("regime", p.regime)
                .putBoolean("tva", p.tva)
                .putFloat("commPlat", p.commissionPlateforme.toFloat())
                .putFloat("autresFrais", p.autresFrais.toFloat())
                .putFloat("tmi", p.tmi.toFloat())
                .putFloat("tauxMicro", p.tauxMicro.toFloat())
                .apply()
        }

    data class Entry(val t: Long, val prix: Double, val km: Double, val min: Double, val net: Double,
                     val parHeure: Double, val score: Double, val verdict: String, var decision: String)

    fun history(): List<Entry> {
        val arr = JSONArray(sp.getString("history", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getLong("t"), o.getDouble("prix"), o.getDouble("km"), o.getDouble("min"), o.getDouble("net"),
                o.getDouble("parHeure"), o.getDouble("score"), o.getString("verdict"), o.optString("decision", ""))
        }
    }

    private fun save(list: List<Entry>) {
        val arr = JSONArray()
        list.take(300).forEach {
            arr.put(JSONObject().put("t", it.t).put("prix", it.prix).put("km", it.km).put("min", it.min)
                .put("net", it.net).put("parHeure", it.parHeure).put("score", it.score)
                .put("verdict", it.verdict).put("decision", it.decision))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    /** Ajoute une analyse en tête et renvoie son horodatage (sert d'identifiant). */
    fun add(r: Result): Long {
        val e = Entry(System.currentTimeMillis(), r.offer.prix, r.kmTotal, r.minTotal, r.net, r.parHeure, r.score, r.verdict.name, "")
        save(listOf(e) + history())
        return e.t
    }

    fun decide(t: Long, decision: String) {
        val h = history()
        h.find { it.t == t }?.decision = decision
        save(h)
    }

    fun clear() = sp.edit().putString("history", "[]").apply()

    // ------------------------------------------------ Boîte noire : courses (fichier rides.json)

    private val dir = ctx.applicationContext.filesDir
    private val fichierCourses = java.io.File(dir, "rides.json")

    private fun rideJson(r: Ride) = JSONObject().put("debut", r.debut).put("prise", r.priseEnCharge).put("fin", r.fin)
        .put("kmA", r.kmApproche).put("kmC", r.kmCourse).put("prix", r.prix)
        .put("lD", r.lieuDepart).put("lP", r.lieuPrise).put("lA", r.lieuArrivee).put("type", r.type)
        .put("plat", r.plateforme).put("verdict", r.verdict).put("score", r.score)
        .put("oKm", r.offreKm).put("oMin", r.offreMin).put("manuelle", r.manuelle).put("facture", r.facture)

    private fun rideDe(o: JSONObject) = Ride(o.getLong("debut"), o.getLong("prise"), o.getLong("fin"),
        o.getDouble("kmA"), o.getDouble("kmC"), o.optDouble("prix", 0.0),
        o.optString("lD", ""), o.optString("lP", ""), o.optString("lA", ""), o.optString("type", "plateforme"),
        o.optString("plat", ""), o.optString("verdict", ""), o.optDouble("score", -1.0),
        o.optDouble("oKm", 0.0), o.optDouble("oMin", 0.0), o.optBoolean("manuelle", false), o.optString("facture", ""))

    fun rides(): List<Ride> = synchronized(VERROU) {
        cacheCourses?.let { return it }
        // Ancien stockage (préférences) : repris une seule fois
        if (!fichierCourses.exists()) {
            val ancien = sp.getString("rides", null)
            if (ancien != null) { fichierCourses.writeText(ancien); sp.edit().remove("rides").apply() }
        }
        val arr = try { JSONArray(if (fichierCourses.exists()) fichierCourses.readText() else "[]") } catch (_: Exception) { JSONArray() }
        val l = (0 until arr.length()).mapNotNull { try { rideDe(arr.getJSONObject(it)) } catch (_: Exception) { null } }
        cacheCourses = l
        l
    }

    private fun saveRides(list: List<Ride>) = synchronized(VERROU) {
        val arr = JSONArray()
        list.sortedBy { it.debut }.forEach { arr.put(rideJson(it)) }
        ecrire(fichierCourses, arr.toString())
        cacheCourses = list.sortedBy { it.debut }
    }

    fun ride(debut: Long) = rides().find { it.debut == debut }

    /** Ajoute ou remplace (même heure de début) une course. */
    fun addRide(r: Ride) = synchronized(VERROU) { saveRides(rides().filter { it.debut != r.debut } + r) }

    fun updateRide(r: Ride) = addRide(r)

    fun deleteRide(debut: Long) = synchronized(VERROU) {
        saveRides(rides().filter { it.debut != debut })
        java.io.File(dir, "traces/$debut.json").delete()
    }

    /** Montant d'une course, saisi ou corrigé après coup. */
    fun setRidePrice(debut: Long, prix: Double) = synchronized(VERROU) {
        saveRides(rides().map { if (it.debut == debut) it.copy(prix = prix) else it })
    }

    /** Écriture sûre : fichier temporaire puis renommage (pas de fichier à moitié écrit si le téléphone s'éteint). */
    private fun ecrire(f: java.io.File, texte: String) {
        f.parentFile?.mkdirs()
        val tmp = java.io.File(f.parentFile, f.name + ".tmp")
        tmp.writeText(texte)
        if (!tmp.renameTo(f)) { f.writeText(texte); tmp.delete() }
    }

    // Tracé GPS de chaque course
    fun saveTrace(debut: Long, points: List<Point>) {
        if (points.isEmpty()) return
        val arr = JSONArray()
        points.forEach { arr.put(JSONArray().put(it.lat).put(it.lon).put(it.t).put(it.phase)) }
        ecrire(java.io.File(dir, "traces/$debut.json"), arr.toString())
    }

    fun trace(debut: Long): List<Point> {
        val f = java.io.File(dir, "traces/$debut.json")
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { val a = arr.getJSONArray(it); Point(a.getDouble(0), a.getDouble(1), a.getLong(2), a.getInt(3)) }
        } catch (_: Exception) { emptyList() }
    }

    /** Dernière plateforme reconnue (sert quand l'offre lue ne la nomme pas). */
    var dernierePlateforme: String
        get() = sp.getString("dernierePlateforme", "Uber")!!
        set(v) = sp.edit().putString("dernierePlateforme", v).apply()

    // ------------------------------------------------ Frais

    private val fichierFrais = java.io.File(dir, "frais.json")

    fun frais(): List<Frais> = synchronized(VERROU) {
        cacheFrais?.let { return it }
        val arr = try { JSONArray(if (fichierFrais.exists()) fichierFrais.readText() else "[]") } catch (_: Exception) { JSONArray() }
        val l = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Frais(o.getLong("id"), o.getLong("date"), Categorie.de(o.optString("cat")), o.getDouble("ttc"), o.optDouble("tva", 20.0),
                o.optString("note", ""), o.optString("photo", ""), o.optBoolean("mensuel", false), o.optLong("fin", 0L))
        }
        cacheFrais = l
        l
    }

    private fun saveFrais(l: List<Frais>) = synchronized(VERROU) {
        val arr = JSONArray()
        l.sortedBy { it.date }.forEach {
            arr.put(JSONObject().put("id", it.id).put("date", it.date).put("cat", it.categorie.name).put("ttc", it.ttc)
                .put("tva", it.tauxTva).put("note", it.note).put("photo", it.photo).put("mensuel", it.mensuel).put("fin", it.finMensuel))
        }
        ecrire(fichierFrais, arr.toString())
        cacheFrais = l.sortedBy { it.date }
    }

    fun addFrais(f: Frais) = synchronized(VERROU) { saveFrais(frais().filter { it.id != f.id } + f) }

    fun deleteFrais(id: Long) = synchronized(VERROU) {
        frais().find { it.id == id }?.photo?.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
        saveFrais(frais().filter { it.id != id })
    }

    fun fraisDuMois(annee: Int, mois: Int) = frais().filter { it.dansMois(annee, mois) }

    // ------------------------------------------------ Factures et clients

    private val fichierFactures = java.io.File(dir, "factures.json")

    private fun clientJson(c: Client) = JSONObject().put("nom", c.nom).put("societe", c.societe).put("siren", c.siren)
        .put("adresse", c.adresse).put("email", c.email).put("tel", c.tel)

    private fun clientDe(o: JSONObject) = Client(o.optString("nom"), o.optString("societe"), o.optString("siren"),
        o.optString("adresse"), o.optString("email"), o.optString("tel"))

    fun factures(): List<Facture> = synchronized(VERROU) {
        val arr = try { JSONArray(if (fichierFactures.exists()) fichierFactures.readText() else "[]") } catch (_: Exception) { JSONArray() }
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Facture(o.getString("numero"), o.getLong("course"), o.getLong("emission"), clientDe(o.getJSONObject("client")),
                o.optString("paiement", ""), o.optLong("reservation", 0L), o.optString("signature", ""), o.optLong("signeLe", 0L))
        }
    }

    fun facture(course: Long) = factures().find { it.course == course }

    fun saveFacture(f: Facture) = synchronized(VERROU) {
        val arr = JSONArray()
        (factures().filter { it.numero != f.numero } + f).sortedBy { it.numero }.forEach {
            arr.put(JSONObject().put("numero", it.numero).put("course", it.course).put("emission", it.emission)
                .put("client", clientJson(it.client)).put("paiement", it.paiement).put("reservation", it.reservation)
                .put("signature", it.signature).put("signeLe", it.signeLe))
        }
        ecrire(fichierFactures, arr.toString())
        // Carnet de clients pour les habitués
        if (f.client.nom.isNotBlank()) {
            val cl = clients().filter { !it.nom.equals(f.client.nom, true) } + f.client
            val ca = JSONArray(); cl.sortedBy { it.nom.lowercase() }.forEach { ca.put(clientJson(it)) }
            ecrire(java.io.File(dir, "clients.json"), ca.toString())
        }
    }

    fun clients(): List<Client> {
        val f = java.io.File(dir, "clients.json")
        val arr = try { JSONArray(if (f.exists()) f.readText() else "[]") } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { clientDe(arr.getJSONObject(it)) }
    }

    /** Prochain numéro de facture, sans trou : F-2026-0001, F-2026-0002… (réservé dès l'appel). */
    fun nouveauNumero(annee: Int): String = synchronized(VERROU) {
        val cle = "numFacture_$annee"
        val n = sp.getInt(cle, 0) + 1
        sp.edit().putInt(cle, n).commit()
        String.format("F-%04d-%04d", annee, n)
    }

    var entreprise: Entreprise
        get() = Entreprise(
            sp.getString("e_raison", "")!!, sp.getString("e_forme", "SASU")!!, sp.getString("e_capital", "")!!,
            sp.getString("e_adresse", "")!!, sp.getString("e_siret", "")!!, sp.getString("e_rcs", "")!!,
            sp.getString("e_tva", "")!!, sp.getString("e_evtc", "")!!, sp.getString("e_chauffeur", "")!!,
            sp.getString("e_tel", "")!!, sp.getString("e_email", "")!!, sp.getString("e_message", Entreprise.MESSAGE_DEFAUT)!!)
        set(e) = sp.edit().putString("e_raison", e.raisonSociale).putString("e_forme", e.forme).putString("e_capital", e.capital)
            .putString("e_adresse", e.adresse).putString("e_siret", e.siret).putString("e_rcs", e.rcs).putString("e_tva", e.tvaIntra)
            .putString("e_evtc", e.evtc).putString("e_chauffeur", e.chauffeur).putString("e_tel", e.tel).putString("e_email", e.email)
            .putString("e_message", e.message).apply()

    /** Km roulés bulle active, par jour ("aaaa-mm-jj"). */
    fun service(): Map<String, Double> {
        val o = JSONObject(sp.getString("service", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addService(jour: String, km: Double) = addKm("service", jour, km)

    /** Km roulés en mode perso : gardés à part, jamais comptés dans les indemnités. */
    fun perso(): Map<String, Double> {
        val o = JSONObject(sp.getString("perso", "{}"))
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun addPerso(jour: String, km: Double) = addKm("perso", jour, km)

    private fun addKm(cle: String, jour: String, km: Double) {
        if (km == 0.0) return
        val o = JSONObject(sp.getString(cle, "{}"))
        o.put(jour, maxOf(0.0, o.optDouble(jour, 0.0) + km))   // km négatifs = annulation d'un classement
        sp.edit().putString(cle, o.toString()).apply()
    }

    /** Situation du foyer pour l'optimisation fiscale. */
    var situation: Optimiseur.Situation
        get() = Optimiseur.Situation(
            parts = sp.getFloat("optParts", 1f).toDouble(),
            couple = sp.getBoolean("optCouple", false),
            autresRevenus = sp.getFloat("optAutres", 0f).toDouble(),
            retraite = sp.getBoolean("optRetraite", true))
        set(s) = sp.edit().putFloat("optParts", s.parts.toFloat()).putBoolean("optCouple", s.couple)
            .putFloat("optAutres", s.autresRevenus.toFloat()).putBoolean("optRetraite", s.retraite).apply()

    /** Prévision (versements par mois, km pro par mois) ; 0 = utiliser les vraies courses. */
    var prevision: Pair<Double, Double>
        get() = sp.getFloat("prevGains", 0f).toDouble() to sp.getFloat("prevKm", 4000f).toDouble()
        set(v) = sp.edit().putFloat("prevGains", v.first.toFloat()).putFloat("prevKm", v.second.toFloat()).apply()

    // ------------------------------------------------ Trajets détectés automatiquement

    var autoTrajets: Boolean
        get() = sp.getBoolean("autoTrajets", false)
        set(v) = sp.edit().putBoolean("autoTrajets", v).apply()

    @Synchronized
    fun trajets(): List<Trajet> {
        val arr = JSONArray(sp.getString("trajets", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Trajet(o.getLong("debut"), o.getLong("fin"), o.getDouble("km"), o.optString("de", ""), o.optString("a", ""),
                o.optString("statut", Trajet.A_CLASSER))
        }
    }

    @Synchronized
    private fun saveTrajets(list: List<Trajet>) {
        val arr = JSONArray()
        list.sortedByDescending { it.debut }.take(1000).forEach {
            arr.put(JSONObject().put("debut", it.debut).put("fin", it.fin).put("km", it.km)
                .put("de", it.depart).put("a", it.arrivee).put("statut", it.statut))
        }
        sp.edit().putString("trajets", arr.toString()).commit()
    }

    @Synchronized
    fun addTrajet(t: Trajet) = saveTrajets(trajets().filter { it.debut != t.debut } + t)

    /** Classe un trajet : ses km vont dans les km pro ou perso du jour (et quittent l'ancien classement). */
    @Synchronized
    fun classer(debut: Long, statut: String) {
        val list = trajets()
        val t = list.find { it.debut == debut } ?: return
        if (t.statut == statut) return
        val jour = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.FRANCE).format(java.util.Date(t.debut))
        when (t.statut) { Trajet.PRO -> addService(jour, -t.km); Trajet.PERSO -> addPerso(jour, -t.km) }
        when (statut) { Trajet.PRO -> addService(jour, t.km); Trajet.PERSO -> addPerso(jour, t.km) }
        saveTrajets(list.map { if (it.debut == debut) it.copy(statut = statut) else it })
    }

    fun supprimerTrajet(debut: Long) {
        classer(debut, Trajet.A_CLASSER)
        saveTrajets(trajets().filter { it.debut != debut })
    }

    var modePerso: Boolean
        get() = sp.getBoolean("modePerso", false)
        set(v) = sp.edit().putBoolean("modePerso", v).apply()
}
