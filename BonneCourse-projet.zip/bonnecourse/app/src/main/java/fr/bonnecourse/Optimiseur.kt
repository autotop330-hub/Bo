package fr.bonnecourse

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Optimisation fiscale légale du chauffeur, sur une année :
 *  - meilleur dosage salaire / dividendes (le salaire réduit l'impôt sur les sociétés mais coûte des cotisations,
 *    les dividendes n'ont pas de cotisations mais passent par l'IS puis la flat tax) ;
 *  - choix automatique flat tax 31,4 % ou barème progressif pour les dividendes ;
 *  - option « valider 4 trimestres de retraite » (salaire minimum) ;
 *  - comparaison des montages : voiture louée à la SASU, indemnités km, micro-entreprise.
 *
 * Paramètres 2026 : barème de l'impôt sur le revenu (revenus 2025), PFU 31,4 %, IS 15 % / 25 %,
 * 7 212 € brut pour 4 trimestres. Estimation à valider avec un expert-comptable.
 */
object Optimiseur {

    // Barème IR (loi de finances 2026, revenus 2025) : (plafond de la tranche par part, taux)
    private val TRANCHES = listOf(11_600.0 to 0.0, 29_579.0 to 0.11, 84_577.0 to 0.30, 181_917.0 to 0.41, Double.MAX_VALUE to 0.45)
    private const val PLAFOND_DEMI_PART = 1_807.0
    private const val DECOTE_SEUL = 897.0
    private const val DECOTE_COUPLE = 1_483.0
    private const val DECOTE_TAUX = 0.4525

    // Salaire du président de SASU : coût total ≈ 1,387 × brut, net ≈ 0,775 × brut (soit coût ≈ 1,79 × net)
    private const val COUT_SUR_BRUT = 1.387
    private const val NET_SUR_BRUT = 0.775
    private const val CSG_NON_DEDUCTIBLE = 0.0285   // CSG non déductible + CRDS, en % du brut
    const val BRUT_4_TRIMESTRES = 7_212.0
    const val PLAFOND_MICRO_SERVICES = 83_600.0

    private const val PS_DIVIDENDES = 0.186
    private const val IR_PFU = 0.128
    private const val CSG_DEDUCTIBLE_DIV = 0.068

    data class Situation(
        val parts: Double = 1.0,            // parts fiscales du foyer
        val couple: Boolean = false,        // marié ou pacsé (imposition commune)
        val autresRevenus: Double = 0.0,    // autres revenus imposables du foyer par an (après abattements)
        val retraite: Boolean = true        // valider 4 trimestres de retraite par an
    )

    /** Impôt sur le revenu du foyer (quotient familial plafonné, décote). */
    fun impotRevenu(revenu: Double, parts: Double, couple: Boolean): Double {
        if (revenu <= 0) return 0.0
        fun brut(rev: Double, n: Double): Double {
            val q = rev / n
            var impot = 0.0; var bas = 0.0
            for ((haut, taux) in TRANCHES) {
                if (q > bas) impot += (min(q, haut) - bas) * taux
                bas = haut
            }
            return impot * n
        }
        val partsBase = if (couple) 2.0 else 1.0
        val avecParts = brut(revenu, parts)
        val sansParts = brut(revenu, partsBase)
        val demiParts = max(0.0, (parts - partsBase) * 2)
        var ir = max(avecParts, sansParts - demiParts * PLAFOND_DEMI_PART)
        val seuil = if (couple) DECOTE_COUPLE else DECOTE_SEUL
        if (ir < seuil) ir = max(0.0, ir - (seuil - ir * DECOTE_TAUX).coerceAtLeast(0.0))
        return ir
    }

    /** L'activité sur une année : ce que versent les plateformes et les clients, et les km pro. */
    data class Activite(val gainsPlateformes: Double, val gainsPrives: Double, val kmPro: Double) {
        val gains get() = gainsPlateformes + gainsPrives
    }

    /** Projection annuelle à partir des courses réellement enregistrées cette année. */
    fun activiteDepuisDonnees(rides: List<Ride>, service: Map<String, Double>, perso: Map<String, Double>,
                              annee: Int, moisEcoules: Double, p: Profile): Activite? {
        if (moisEcoules < 0.25) return null
        val n = min(12, ceil(moisEcoules).toInt())
        val bases = (1..n).map { Finance.base(rides, service, perso, annee, it, p, moisEcoules) }
        val k = 12.0 / moisEcoules
        val a = Activite(bases.sumOf { it.gainsPlateformes } * k, bases.sumOf { it.gainsPrives } * k, bases.sumOf { it.kmPro } * k)
        return if (a.gains <= 0) null else a
    }

    /** Résultat annuel de la société (avant rémunération du dirigeant) pour un montage donné. */
    data class Annuel(
        val prixClients: Double, val tvaNette: Double, val chargesVoiture: Double, val autresFrais: Double,
        val resultat: Double, val indemnitesKm: Double, val coutVoiturePerso: Double, val caHT: Double
    )

    fun annuel(a: Activite, p: Profile, regime: String): Annuel {
        val c = (p.commissionPlateforme / 100).coerceIn(0.0, 0.9)
        val prix = a.gainsPlateformes / (1 - c) + a.gainsPrives
        val tvaColl = if (p.tva) prix * Finance.TVA_VTC / (1 + Finance.TVA_VTC) else 0.0
        val eu = a.kmPro * (p.conso / 100 * p.prixEnergie + p.usure)
        val fixes = p.fixesMois * 12
        val frais = p.autresFrais * 12
        return when (regime) {
            "ik" -> {
                val ik = Bareme.annuel(a.kmPro, p.cv, p.electrique)
                Annuel(prix, tvaColl, ik, frais, a.gains - tvaColl - ik - frais, ik, fixes + eu, prix - tvaColl)
            }
            "micro" -> Annuel(prix, tvaColl, fixes + eu, frais, a.gains - tvaColl - fixes - eu - frais, 0.0, 0.0, prix - tvaColl)
            else -> {
                val tvaDed = if (p.tva) eu * Finance.TVA_NORMALE / (1 + Finance.TVA_NORMALE) else 0.0
                Annuel(prix, tvaColl - tvaDed, fixes + eu, frais, a.gains - (tvaColl - tvaDed) - fixes - eu - frais, 0.0, 0.0, prix - tvaColl)
            }
        }
    }

    /** Une stratégie de rémunération évaluée sur l'année. */
    data class Plan(
        val nom: String,
        val salaireBrut: Double,
        val salaireNet: Double,
        val coutSalaire: Double,
        val cotisations: Double,
        val impotSocietes: Double,
        val dividendes: Double,
        val dividendesAuBareme: Boolean,
        val prelevementsSociaux: Double,
        val impotRevenu: Double,       // impôt sur le revenu dû à l'activité (salaire + dividendes)
        val bonusIk: Double,           // indemnités km − frais de voiture payés soi-même
        val net: Double                // ce qui reste dans la poche sur l'année
    ) {
        val totalPrelevements get() = cotisations + impotSocietes + prelevementsSociaux + impotRevenu
    }

    /** Évalue un salaire (coût total pour la société) donné ; le reste du bénéfice part en dividendes. */
    fun evaluer(nom: String, resultat: Double, coutSalaire: Double, s: Situation, bonusIk: Double): Plan {
        val cout = coutSalaire.coerceIn(0.0, max(0.0, resultat))
        val brut = cout / COUT_SUR_BRUT
        val net = brut * NET_SUR_BRUT
        val salaireImposable = (net + brut * CSG_NON_DEDUCTIBLE) * 0.9          // abattement 10 % pour frais
        val benefice = resultat - cout
        val isoc = Finance.impotSocietes(benefice)
        val div = max(0.0, benefice - isoc)
        val ps = div * PS_DIVIDENDES
        val irAutres = impotRevenu(s.autresRevenus, s.parts, s.couple)
        val irPfu = impotRevenu(s.autresRevenus + salaireImposable, s.parts, s.couple) + div * IR_PFU
        val irBareme = impotRevenu(s.autresRevenus + salaireImposable + div * (0.6 - CSG_DEDUCTIBLE_DIV), s.parts, s.couple)
        val bareme = div > 0 && irBareme < irPfu
        val ir = (if (bareme) irBareme else irPfu) - irAutres
        val netPoche = net + div - ps - ir + bonusIk + min(0.0, benefice)  // une perte reste à la charge de la société
        return Plan(nom, brut, net, cout, cout - net, isoc, div, bareme, ps, ir, bonusIk, netPoche)
    }

    data class Optimisation(
        val regime: String,
        val annuel: Annuel,
        val toutDividendes: Plan,
        val toutSalaire: Plan,
        val optimal: Plan,
        val optimalRetraite: Plan?,     // meilleur plan qui valide 4 trimestres (si différent)
        val recommande: Plan,
        val eligible: Boolean,
        val raisonNonEligible: String?
    )

    fun optimiser(a: Activite, p: Profile, s: Situation, regime: String): Optimisation {
        val an = annuel(a, p, regime)
        if (regime == "micro") {
            val eligible = an.caHT <= PLAFOND_MICRO_SERVICES
            val cot = an.caHT * p.tauxMicro / 100
            val irAutres = impotRevenu(s.autresRevenus, s.parts, s.couple)
            val ir = impotRevenu(s.autresRevenus + an.caHT * 0.5, s.parts, s.couple) - irAutres
            val net = an.resultat - cot - ir
            val plan = Plan("Micro-entreprise", 0.0, 0.0, 0.0, cot, 0.0, 0.0, false, 0.0, ir, 0.0, net)
            return Optimisation(regime, an, plan, plan, plan, null, plan, eligible,
                if (eligible) null else "chiffre d'affaires au-dessus du plafond micro (83 600 € HT)")
        }
        val bonus = if (regime == "ik") an.indemnitesKm - an.coutVoiturePerso else 0.0
        val r = an.resultat
        val toutDiv = evaluer("Tout en dividendes", r, 0.0, s, bonus)
        val toutSal = evaluer("Tout en salaire", r, r, s, bonus)
        var best = toutDiv
        val pas = 50.0
        var c = 0.0
        while (c <= r) {
            val pl = evaluer("Optimal", r, c, s, bonus)
            if (pl.net > best.net + 0.5) best = pl
            c += pas
        }
        val optimal = best.copy(nom = "Optimal")
        val coutRetraite = BRUT_4_TRIMESTRES * COUT_SUR_BRUT
        val optRetraite = if (optimal.salaireBrut >= BRUT_4_TRIMESTRES - 1 || r < coutRetraite) null else {
            var b = evaluer("Optimal avec retraite", r, coutRetraite, s, bonus)
            var cc = coutRetraite
            while (cc <= r) {
                val pl = evaluer("Optimal avec retraite", r, cc, s, bonus)
                if (pl.net > b.net + 0.5) b = pl
                cc += pas
            }
            b
        }
        val reco = if (s.retraite && optRetraite != null) optRetraite else optimal
        return Optimisation(regime, an, toutDiv, toutSal, optimal, optRetraite, reco, true, null)
    }

    /** Leviers légaux à activer, adaptés à la situation (phrases courtes). */
    fun leviers(o: Optimisation, p: Profile, s: Situation): List<String> {
        val l = mutableListOf<String>()
        val pl = o.recommande
        fun e(x: Double) = String.format(java.util.Locale.FRANCE, "%,.0f €", x)
        if (o.regime != "micro") {
            l += if (pl.salaireBrut < 1) "Pas de salaire : tout en dividendes."
                 else "Se verser ${e(pl.salaireBrut / 12)} brut par mois, le reste en dividendes."
            if (pl.dividendes > 0) l += if (pl.dividendesAuBareme) "Cocher la case 2OP sur ta déclaration d'impôts."
                                        else "Garder la flat tax (ne pas cocher la case 2OP)."
            if (s.retraite && pl.salaireBrut >= BRUT_4_TRIMESTRES - 1) l += "7 212 € brut par an = 4 trimestres de retraite validés."
            l += "Demander l'ACRE si tu y as droit : 25 % de cotisations en moins la 1re année."
            l += "Les bonnes années, laisser une partie du bénéfice dans la société : taxée 15 % seulement."
        }
        if (p.tva) l += "Récupérer la TVA sur la recharge, l'entretien, le lavage et le téléphone."
        l += "Passer en charges : téléphone, lavage, eau pour les clients, comptable, carte VTC, péages."
        if (o.regime == "location") l += "Loyer de la voiture au prix du marché, avec un contrat écrit."
        if (o.regime == "ik") l += "Garder l'export mensuel des km comme justificatif."
        if (s.autresRevenus + pl.salaireNet > 30_000) l += "Verser sur un PER : ça baisse ton impôt."
        return l
    }
}
