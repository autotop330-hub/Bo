package fr.bonnecourse

import android.content.ClipboardManager
import android.content.Context
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** La Tesla dans l'appli : connexion Teslemetry (Réglages) et état de la voiture (accueil). */
object EcranTesla {

    private fun km(x: Double) = String.format(Locale.FRANCE, "%,.1f km", x)

    /** Carte de l'accueil : batterie, autonomie, compteur, dernier relevé. */
    fun etat(a: MainActivity): View? {
        val store = a.store
        if (!store.teslaActive) return null
        val c = W.carte(a, store.teslaNom.ifBlank { "Ma Tesla" })
        val e = store.derniereTesla
        if (e == null) {
            c.addView(W.aide(a, "Lecture de la voiture…"))
        } else {
            val ligne = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            val bat = e.batterie
            ligne.addView(W.hero(a, if (bat != null) "${bat.roundToInt()} %" else "—",
                if (e.enCharge) "⚡ en charge" + if (e.rapide == true) " rapide" else "" else "batterie",
                when { bat == null -> Ui.FG; bat < 15 -> Ui.STOP; bat < 30 -> Ui.WARN; else -> Ui.GO }),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            ligne.addView(Ui.vertical(a, 4).apply {
                addView(W.ligne(a, "Autonomie", e.autonomieKm?.let { "${it.roundToInt()} km" } ?: "—"))
                addView(W.ligne(a, "Compteur", e.odoKm?.let { km(it) } ?: "—"))
                addView(W.ligne(a, "État", when { e.enCharge -> "en charge"; e.roule -> "en route"; e.rapport == "P" -> "garée"; else -> "—" }))
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f))
            c.addView(ligne)
            val min = ((System.currentTimeMillis() - e.maj) / 60000).toInt()
            c.addView(W.aide(a, "Envoyé par la voiture " + when {
                min < 1 -> "à l'instant"; min < 60 -> "il y a $min min"
                else -> "le " + SimpleDateFormat("dd/MM à HH:mm", Locale.FRANCE).format(Date(e.maj))
            } + " · la voiture n'est jamais réveillée"))
        }
        TeslaAuto.consommation(store, System.currentTimeMillis() - 30L * 24 * 3600_000)?.let { (conso, k) ->
            c.addView(W.ligne(a, "Conso réelle (30 jours)", String.format(Locale.FRANCE, "%.1f kWh/100 km", conso), couleur = Ui.ACCENT))
            c.addView(W.aide(a, "Mesurée sur ${k.roundToInt()} km de service" + if (store.consoAuto) " · utilisée pour juger les offres" else ""))
        }
        c.addView(W.bouton(a, "Relever le compteur maintenant") {
            a.toast("Lecture de la Tesla…")
            TeslaAuto.relever(store, "manuel") { r -> a.toast(if (r?.odoKm != null) "Compteur relevé : ${km(r.odoKm)}" else "La voiture ne répond pas (réseau ?)"); a.afficher() }
        })
        return c
    }

    /** Carte des Réglages : connexion, prix du kWh, automatismes. */
    fun reglages(a: MainActivity): LinearLayout {
        val store = a.store
        val c = W.carte(a, "Ma Tesla (Teslemetry)")
        c.addView(Ui.text(a, if (store.teslaActive) "✓ Connectée : ${store.teslaNom} · VIN …${store.teslaVin.takeLast(6)}" else
            "Pas encore connectée", 15f, if (store.teslaActive) Ui.GO else Ui.WARN, true))
        c.addView(W.aide(a, "Avec le même jeton que Fluide, l'appli relève toute seule le compteur et la batterie : début et fin de service, " +
            "chaque course (acceptée, client à bord, déposé), départ et retour au domicile. Les recharges sont ajoutées aux frais, " +
            "et la consommation réelle sert à juger les offres."))
        val form = Ui.vertical(a, 6)
        form.addView(W.aide(a, "Jeton : site Teslemetry → Console → Access Tokens. Copie-le, puis touche « Coller mon jeton »."))
        form.addView(W.bouton(a, "Coller mon jeton et connecter", true) {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val j = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(a)?.toString()?.trim().orEmpty()
            if (j.length < 20 || ' ' in j) a.toast("Copie d'abord ton jeton Teslemetry, puis touche ce bouton.") else connecter(a, j)
        })
        val eJ = W.champ(a, form, "Ou colle-le ici", "", indice = "jeton Teslemetry")
        form.addView(W.bouton(a, "Connecter avec ce jeton") { W.txt(eJ).takeIf { it.isNotBlank() }?.let { connecter(a, it) } })
        c.addView(Ui.details(a, if (store.teslaActive) "Changer de jeton ou de voiture" else "Connecter ma Tesla", form, !store.teslaActive))
        if (store.teslaActive) {
            val opts = Ui.vertical(a, 6)
            val pDom = W.champ(a, opts, "Prix du kWh à domicile (€)", W.n(store.prixKwhDomicile), W.NOMBRE)
            val pBorne = W.champ(a, opts, "Prix du kWh sur borne / Superchargeur (€)", W.n(store.prixKwhBorne), W.NOMBRE)
            val sRech = SwitchCompat(a).apply { text = "Ajouter les recharges aux frais automatiquement"; setTextColor(Ui.FG); isChecked = store.rechargesAuto }
            val sConso = SwitchCompat(a).apply { text = "Juger les offres avec la consommation réelle"; setTextColor(Ui.FG); isChecked = store.consoAuto }
            opts.addView(sRech); opts.addView(sConso)
            opts.addView(W.bouton(a, "Enregistrer", true) {
                W.nombre(pDom)?.takeIf { it in 0.01..2.0 }?.let { store.prixKwhDomicile = it }
                W.nombre(pBorne)?.takeIf { it in 0.01..2.0 }?.let { store.prixKwhBorne = it }
                store.rechargesAuto = sRech.isChecked; store.consoAuto = sConso.isChecked
                if (store.consoAuto) TeslaAuto.appliquerConso(store)
                a.toast("Enregistré"); a.afficher()
            })
            opts.addView(W.boutonDanger(a, "Déconnecter la Tesla") {
                W.confirmer(a, "Déconnecter la Tesla ?", "Les relevés déjà faits sont gardés.", "Déconnecter") {
                    store.teslaJeton = ""; store.teslaVin = ""; store.teslaNom = ""; store.derniereTesla = null; a.afficher()
                }
            })
            c.addView(Ui.details(a, "Recharges et consommation", opts))
        }
        return c
    }

    /** Vérifie le jeton, choisit la voiture, règle les données envoyées, puis fait un premier relevé. */
    private fun connecter(a: MainActivity, jeton: String) {
        a.toast("Connexion à Teslemetry…")
        Thread {
            val v = Tesla.vehicules(jeton)
            a.runOnUiThread {
                when {
                    v == null -> a.toast("Jeton refusé, ou pas de réseau.")
                    v.isEmpty() -> a.toast("Aucune voiture sur ce compte Teslemetry.")
                    v.size == 1 -> finir(a, jeton, v[0])
                    else -> AlertDialog.Builder(a).setTitle("Quelle voiture ?")
                        .setItems(v.map { "${it.second} · …${it.first.takeLast(6)}" as CharSequence }.toTypedArray()) { _, i -> finir(a, jeton, v[i]) }
                        .setNegativeButton("Annuler", null).show()
                }
            }
        }.start()
    }

    private fun finir(a: MainActivity, jeton: String, v: Pair<String, String>) {
        val store = a.store
        store.teslaJeton = jeton; store.teslaVin = v.first; store.teslaNom = v.second
        Thread {
            val err = Tesla.configurer(jeton, v.first)
            a.runOnUiThread {
                a.toast(if (err == null) "${v.second} connectée ✓" else "Connectée, mais réglage des données : $err")
                TeslaAuto.relever(store, "manuel", "Connexion") { a.afficher() }
            }
        }.start()
    }
}
