package fr.bonnecourse

import kotlin.math.abs

/**
 * Transforme le texte lu à l'écran en offre de course.
 *
 * Exemples de textes reconnus :
 *   Uber   : "14,20 €"  "À 7 min (3,1 km)"  "Course de 18 min (8,4 km)"
 *   Bolt   : "14,20 €"  "7 min · 3,1 km"     "18 min · 8,4 km"
 *   Heetch : "3,1 km - 7 min" ... ou n'importe quel ordre km / min
 *
 * La 1re paire (durée, distance) trouvée = l'approche, la 2e = la course.
 */
object OfferParser {

    data class Parsed(val offer: Offer?, val erreur: String?)

    private data class Tok(val pos: Int, val value: Double)

    private val PRIX = Regex("""(\+\s*)?(\d{1,3}(?:[.,]\d{1,2})?)\s*(€|EUR|CHF)|(€|CHF)\s*(\d{1,3}(?:[.,]\d{1,2})?)""")
    private val KM = Regex("""(\d{1,3}(?:[.,]\d{1,2})?)\s*km""", RegexOption.IGNORE_CASE)
    private val METRES = Regex("""\b(\d{2,4})\s?m\b""")
    private val HEURE_MIN = Regex("""\b(\d{1,2})\s*h\s*(\d{1,2})(?:\s*min\w*)?""", RegexOption.IGNORE_CASE)
    private val MIN = Regex("""\b(\d{1,3})\s*min""", RegexOption.IGNORE_CASE)

    private fun num(s: String) = s.replace(',', '.').toDouble()

    fun parse(raw: String): Parsed {
        val t = raw.replace(' ', ' ').replace(' ', ' ')

        // Prix : le plus gros montant, hors suppléments "+2,00 € inclus"
        val prix = PRIX.findAll(t).mapNotNull { m ->
            if (m.groupValues[1].isNotBlank()) null
            else (m.groupValues[2].ifEmpty { m.groupValues[5] }).let { if (it.isEmpty()) null else num(it) }
        }.filter { it in 2.0..999.0 }.maxOrNull()
            ?: return Parsed(null, "Prix non trouvé à l'écran")

        // Distances
        val dist = mutableListOf<Tok>()
        KM.findAll(t).forEach { dist += Tok(it.range.first, num(it.groupValues[1])) }
        METRES.findAll(t).forEach { dist += Tok(it.range.first, it.groupValues[1].toDouble() / 1000.0) }
        dist.sortBy { it.pos }

        // Durées (les "1 h 05" d'abord, pour ne pas les recompter comme "05 min")
        val dur = mutableListOf<Tok>()
        val prises = mutableListOf<IntRange>()
        HEURE_MIN.findAll(t).forEach {
            dur += Tok(it.range.first, it.groupValues[1].toDouble() * 60 + it.groupValues[2].toDouble())
            prises += it.range
        }
        MIN.findAll(t).forEach { m ->
            if (prises.none { m.range.first in it }) dur += Tok(m.range.first, m.groupValues[1].toDouble())
        }

        // Associer chaque distance à la durée la plus proche dans le texte
        val utilisees = mutableSetOf<Int>()
        val paires = mutableListOf<Pair<Double, Double>>() // (min, km)
        for (d in dist) {
            val best = dur.withIndex()
                .filter { it.index !in utilisees && abs(it.value.pos - d.pos) <= 30 }
                .minByOrNull { abs(it.value.pos - d.pos) } ?: continue
            utilisees += best.index
            paires += best.value.value to d.value
        }

        return when {
            paires.size >= 2 -> Parsed(Offer(prix, paires[0].second, paires[0].first, paires[1].second, paires[1].first), null)
            paires.size == 1 -> Parsed(Offer(prix, 0.0, 0.0, paires[0].second, paires[0].first, approcheLue = false), null)
            else -> Parsed(null, "Distances et durées non trouvées à l'écran")
        }
    }
}

/** Reconnaît la plateforme d'après le texte lu sur l'offre. null si rien ne la nomme. */
object Plateforme {
    val TOUTES = listOf("Uber", "Bolt", "Heetch", "FreeNow")

    fun detecter(texte: String): String? {
        val t = texte.lowercase()
        return when {
            "bolt" in t -> "Bolt"
            "heetch" in t -> "Heetch"
            "free now" in t || "freenow" in t -> "FreeNow"
            "uber" in t || Regex("\\b(comfort|green|berline|van)\\b").containsMatchIn(t) -> "Uber"
            else -> null
        }
    }
}
