package fr.bonnecourse

import kotlin.math.max

/**
 * Du chiffre d'affaires à l'argent dans la poche du chauffeur, mois par mois.
 *
 * Règles 2026 utilisées (à faire valider par le comptable) :
 *  - TVA VTC 10 % sur le prix payé par le client (commission comprise). La TVA sur la commission
 *    Uber/Bolt est autoliquidée : sans effet sur la trésorerie.
 *  - Impôt sur les sociétés : 15 % jusqu'à 42 500 € de bénéfice annuel, 25 % au-delà.
 *  - Dividendes : prélèvement forfaitaire unique 31,4 % (12,8 % impôt + 18,6 % prélèvements sociaux),
 *    pas de cotisations URSSAF.
 *  - Salaire de président de SASU : coût total ≈ 1,79 × le net (cotisations patronales et salariales).
 *  - Micro-entreprise : cotisations URSSAF 21,2 % du chiffre d'affaires, impôt sur 50 % du CA.
 */
object Finance {
    const val TVA_VTC = 0.10
    const val TVA_NORMALE = 0.20
    const val PFU = 0.314
    const val IS_REDUIT = 0.15
    const val IS_NORMAL = 0.25
    const val SEUIL_IS = 42_500.0
    const val COUT_SALAIRE_SUR_NET = 1.79
    const val FRANCHISE_TVA = 37_500.0

    /** Impôt sur les sociétés pour un bénéfice annuel. */
    fun impotSocietes(benefice: Double): Double =
        if (benefice <= 0) 0.0
        else if (benefice <= SEUIL_IS) benefice * IS_REDUIT
        else SEUIL_IS * IS_REDUIT + (benefice - SEUIL_IS) * IS_NORMAL

    /** Ce qu'un mois rapporte avant impôt sur les sociétés. */
    data class Base(
        val gainsPlateformes: Double,   // ce que Uber/Bolt te versent
        val gainsPrives: Double,        // clients en direct
        val prixClients: Double,        // prix payés par les clients (commission comprise)
        val tvaCollectee: Double,
        val tvaDeductible: Double,      // TVA récupérée sur la recharge et l'entretien
        val chargesVoiture: Double,     // TTC : location + assurance + recharge + entretien, ou indemnités km
        val autresFrais: Double,
        val indemnitesKm: Double,
        val coutVoiturePerso: Double,   // frais de voiture payés par le chauffeur lui-même (mode indemnités)
        val kmPro: Double,
        val parSource: Map<String, Double> = emptyMap(),   // Uber, Bolt, Heetch, Privé, Plateforme
        val postes: List<Poste> = emptyList()              // frais du mois par poste (réels ou estimés)
    ) {
        val gains get() = gainsPlateformes + gainsPrives
        val tvaNette get() = tvaCollectee - tvaDeductible
        val resultat get() = gains - tvaNette - chargesVoiture - autresFrais
    }

    /** Un poste de frais du mois : montant TTC, et s'il est estimé faute de frais saisis. */
    data class Poste(val nom: String, val ttc: Double, val estime: Boolean)

    data class NetMois(
        val base: Base,
        val resultat: Double,
        val impotSocietes: Double,
        val netDividendes: Double,      // dans la poche via dividendes (après IS et flat tax)
        val netSalaire: Double,         // dans la poche via salaire (après cotisations et impôt)
        val cotisationsSalaire: Double,
        val bonusIk: Double,            // indemnités km − frais de voiture payés soi-même
        val cotisationsMicro: Double,
        val impotMicro: Double,
        val netMicro: Double,
        val prixClientsAnnee: Double,   // projection, pour le seuil de TVA
        val regime: String
    ) {
        val totalDividendes get() = netDividendes + bonusIk
        val totalSalaire get() = netSalaire + bonusIk
        /** Meilleur net possible pour le régime choisi. */
        val meilleur get() = if (regime == "micro") netMicro else max(totalDividendes, totalSalaire)
        val meilleurMode get() = when {
            regime == "micro" -> "micro"
            totalDividendes >= totalSalaire -> "dividendes"
            else -> "salaire"
        }
        val depasseFranchiseTva get() = prixClientsAnnee / (1 + TVA_VTC) > FRANCHISE_TVA
    }

    private fun ridesDuMois(rides: List<Ride>, annee: Int, mois: Int): List<Ride> {
        val cal = java.util.Calendar.getInstance()
        return rides.filter {
            cal.timeInMillis = it.debut
            cal.get(java.util.Calendar.YEAR) == annee && cal.get(java.util.Calendar.MONTH) + 1 == mois
        }
    }

    fun base(rides: List<Ride>, service: Map<String, Double>, perso: Map<String, Double>,
             annee: Int, mois: Int, p: Profile, moisEcoules: Double, frais: List<Frais> = emptyList()): Base {
        val rs = ridesDuMois(rides, annee, mois)
        val r = Reports.mois(rides, service, annee, mois, p.cv, p.electrique, p.coutKm(), moisEcoules, perso)
        val gPlat = rs.filter { !it.prive }.sumOf { it.prix }
        val gPriv = rs.filter { it.prive }.sumOf { it.prix }
        val parSource = rs.groupBy { it.source }.mapValues { (_, l) -> l.sumOf { it.prix } }
        val c = (p.commissionPlateforme / 100).coerceIn(0.0, 0.9)
        val prixClients = gPlat / (1 - c) + gPriv
        val fm = frais.filter { it.dansMois(annee, mois) }
        val actif = rs.isNotEmpty() || r.kmPro > 0 || fm.isNotEmpty()
        val tvaColl = if (p.tva && p.regime != "micro") prixClients * TVA_VTC / (1 + TVA_VTC) else 0.0

        if (p.regime == "location") {
            // Chaque groupe : frais réels s'il y en a dans le mois, sinon estimation
            val postes = mutableListOf<Poste>()
            var ttc = 0.0; var tvaDed = 0.0; var voiture = 0.0
            fun groupe(g: String, estimation: Double, tauxEstim: Double, voit: Boolean) {
                val reels = fm.filter { it.categorie.groupe == g }
                if (reels.isNotEmpty()) {
                    reels.groupBy { it.categorie }.forEach { (cat, l) -> postes += Poste(cat.nom, l.sumOf { it.ttc }, false) }
                    val m = reels.sumOf { it.ttc }
                    ttc += m; if (voit) voiture += m
                    if (p.tva) tvaDed += reels.sumOf { it.tva() }
                } else if (estimation > 0 && actif) {
                    postes += Poste(Categorie.GROUPES[g] ?: g, estimation, true)
                    ttc += estimation; if (voit) voiture += estimation
                    if (p.tva) tvaDed += estimation * tauxEstim / (100 + tauxEstim)
                }
            }
            groupe("energie", r.kmPro * p.conso / 100 * p.prixEnergie, 20.0, true)
            groupe("voiture", p.fixesMois, 0.0, true)
            groupe("entretien", r.kmPro * p.usure, 20.0, true)
            groupe("societe", p.autresFrais, 0.0, false)
            groupe("autre", 0.0, 0.0, false)
            return Base(gPlat, gPriv, prixClients, tvaColl, tvaDed,
                chargesVoiture = voiture, autresFrais = ttc - voiture,
                indemnitesKm = 0.0, coutVoiturePerso = 0.0, kmPro = r.kmPro,
                parSource = parSource, postes = postes.sortedByDescending { it.ttc })
        }

        val energieEtUsure = r.kmPro * (p.conso / 100 * p.prixEnergie + p.usure)
        val fixes = if (actif) p.fixesMois else 0.0
        return when (p.regime) {
            "ik" -> Base(gPlat, gPriv, prixClients, tvaColl, 0.0,
                chargesVoiture = r.bareme, autresFrais = if (actif) p.autresFrais else 0.0,
                indemnitesKm = r.bareme, coutVoiturePerso = fixes + energieEtUsure, kmPro = r.kmPro, parSource = parSource)
            else -> Base(gPlat, gPriv, prixClients, if (p.tva) prixClients * TVA_VTC / (1 + TVA_VTC) else 0.0, 0.0,
                chargesVoiture = fixes + energieEtUsure, autresFrais = if (actif) p.autresFrais else 0.0,
                indemnitesKm = 0.0, coutVoiturePerso = 0.0, kmPro = r.kmPro, parSource = parSource)
        }
    }

    fun mois(rides: List<Ride>, service: Map<String, Double>, perso: Map<String, Double>,
             annee: Int, mois: Int, p: Profile, moisEcoules: Double, frais: List<Frais> = emptyList()): NetMois {
        val bases = (1..mois).map { base(rides, service, perso, annee, it, p, moisEcoules, frais) }
        val b = bases.last()
        val cumulAvant = bases.dropLast(1).sumOf { it.resultat }
        val cumul = cumulAvant + b.resultat
        // IS du mois = IS du cumul de l'année − IS déjà dû avant ce mois (tranche à 15 % puis 25 %)
        val isMois = max(0.0, impotSocietes(cumul) - impotSocietes(cumulAvant))
        val res = b.resultat

        val netDiv = if (res > 0) (res - isMois) * (1 - PFU) else res
        val salaireNet = if (res > 0) res / COUT_SALAIRE_SUR_NET else 0.0
        val impotSalaire = salaireNet * 0.9 * p.tmi / 100      // abattement de 10 % pour frais
        val netSal = if (res > 0) salaireNet - impotSalaire else res
        val bonusIk = if (p.regime == "ik") b.indemnitesKm - b.coutVoiturePerso else 0.0

        // Micro-entreprise : cotisations et impôt sur le chiffre d'affaires HT (prix clients)
        val caMicro = b.prixClients - b.tvaCollectee
        val cotMicro = caMicro * p.tauxMicro / 100
        val impMicro = caMicro * 0.5 * p.tmi / 100
        val netMicro = b.gains - b.tvaNette - cotMicro - impMicro - b.chargesVoiture - b.autresFrais

        // Projection annuelle du chiffre d'affaires (pour le seuil de TVA) : mois écoulés, ou mois affiché s'il est passé
        val diviseur = if (mois < moisEcoules) mois.toDouble() else moisEcoules
        val prixAnnee = bases.sumOf { it.prixClients }.let { if (diviseur >= 1) it / diviseur * 12 else it }
        return NetMois(b, res, isMois, netDiv, netSal, if (res > 0) res - salaireNet else 0.0, bonusIk,
            cotMicro, impMicro, netMicro, prixAnnee, p.regime)
    }
}
