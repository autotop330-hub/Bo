package fr.bonnecourse

/**
 * Trajet détecté automatiquement (voiture en mouvement, bulle non lancée).
 * Il reste « à classer » tant que le chauffeur n'a pas choisi pro ou perso.
 */
data class Trajet(
    val debut: Long,
    val fin: Long,
    val km: Double,
    val depart: String = "",
    val arrivee: String = "",
    val statut: String = A_CLASSER       // a_classer, pro, perso
) {
    val minutes get() = (fin - debut) / 60000.0
    companion object {
        const val A_CLASSER = "a_classer"
        const val PRO = "pro"
        const val PERSO = "perso"
    }
}

/**
 * Enregistre un trajet à partir des positions GPS et décide quand il est terminé :
 *  - la voiture est à l'arrêt depuis [arretMs] (feu rouge et bouchon ne coupent pas le trajet) ;
 *  - ou le téléphone signale qu'on est sorti de la voiture, après [graceSortieMs].
 * Les trajets trop courts (moins de [kmMin]) sont ignorés : déplacement dans un parking, faux départ.
 */
class Enregistreur(
    private val debut: Long,
    private val arretMs: Long = 6 * 60_000L,
    private val graceSortieMs: Long = 2 * 60_000L,
    private val kmMin: Double = 0.5
) {
    private val odo = Odometer()
    private var dernierMouvement = debut
    private var derniereFix = debut
    private var sortie: Long? = null
    var depart: Pair<Double, Double>? = null
        private set
    var arrivee: Pair<Double, Double>? = null
        private set
    val km get() = odo.totalM / 1000.0

    fun position(lat: Double, lon: Double, precision: Float, t: Long, vitesse: Float?) {
        if (depart == null && precision <= 60f) depart = lat to lon
        if (precision <= 60f) arrivee = lat to lon
        if (t - derniereFix > 60_000) odo.reset()
        derniereFix = t
        val d = odo.add(lat, lon, precision, t, vitesse)
        if (d > 0 || (vitesse != null && vitesse >= 2f)) { dernierMouvement = t; sortie = null }
    }

    /** Le téléphone signale qu'on est sorti de la voiture. */
    fun sortieVoiture(t: Long) { if (sortie == null) sortie = t }

    /** Le téléphone signale qu'on est (de nouveau) en voiture. */
    fun enVoiture() { sortie = null }

    fun termine(maintenant: Long): Boolean =
        maintenant - dernierMouvement >= arretMs || (sortie?.let { maintenant - it >= graceSortieMs } ?: false)

    /** Le trajet à enregistrer, ou null s'il est trop court. */
    fun trajet(fin: Long = dernierMouvement): Trajet? {
        if (km < kmMin) return null
        fun c(p: Pair<Double, Double>?) = p?.let { String.format(java.util.Locale.US, "%.5f,%.5f", it.first, it.second) } ?: ""
        return Trajet(debut, maxOf(fin, debut), km, c(depart), c(arrivee))
    }
}
