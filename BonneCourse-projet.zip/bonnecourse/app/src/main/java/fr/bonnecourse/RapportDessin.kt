package fr.bonnecourse

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Mise en page du rapport mensuel (A4 portrait, 595 × 842 points), aux couleurs de la marque : noir, or, ivoire.
 * Seulement du dessin sur Canvas (pas de StaticLayout) : le texte est coupé en lignes à la main.
 */
object RapportDessin {
    private val loc = Locale.FRANCE
    private val NOIR = Color.parseColor("#14161A")
    private val OR = Color.parseColor("#B8892E")
    private val OR_T = Color.parseColor("#8A6418")
    private val IVOIRE = Color.parseColor("#FAF6EC")
    private val IVOIRE2 = Color.parseColor("#F1E7CF")
    private val GRIS = Color.parseColor("#5B616B")
    private val TRAIT = Color.parseColor("#E3DAC4")
    private val ROUGE = Color.parseColor("#B0413E")

    private const val W = 595f
    private const val H = 842f
    private const val M = 40f            // marges gauche/droite
    private const val HAUT = 52f         // début du contenu
    private const val BAS = 790f         // fin du contenu (pied de page dessous)

    /** Espaces fines des milliers (U+202F) remplacées : toutes les polices les ont. */
    private fun sp(s: String) = s.replace('\u202F', ' ').replace('\u00A0', ' ')
    private fun n1(x: Double) = sp(String.format(loc, "%,.1f", x))
    private fun n2(x: Double) = sp(String.format(loc, "%,.2f", x))
    private fun eur(x: Double) = sp(String.format(loc, "%,.2f", x)) + " €"
    private fun km(x: Double) = n1(x) + " km"
    private val jour = SimpleDateFormat("dd/MM/yyyy", loc)
    private val jm = SimpleDateFormat("dd/MM", loc)
    private val hm = SimpleDateFormat("HH:mm", loc)
    private val hms = SimpleDateFormat("HH:mm:ss", loc)
    private val MOIS = listOf("Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre")

    private fun paint(size: Float, gras: Boolean = false, couleur: Int = NOIR) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; color = couleur
        typeface = Typeface.create("sans-serif", if (gras) Typeface.BOLD else Typeface.NORMAL)
    }

    /** Colonne de tableau : titre, part de la largeur, alignée à droite (chiffres). */
    data class Col(val titre: String, val part: Float, val droite: Boolean = false)

    /** Gestion des pages : curseur vertical, saut de page avec en-tête et pied de page. */
    class Mise(private val doc: PdfDocument, private val titre: String, private val pied: String) {
        private var page: PdfDocument.Page? = null
        lateinit var c: Canvas
        var y = HAUT
        var n = 0

        fun nouvellePage() {
            page?.let { doc.finishPage(it) }
            n++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(W.toInt(), H.toInt(), n).create())
            page = p; c = p.canvas; y = HAUT
            c.drawColor(Color.WHITE)
            // En-tête discret
            c.drawText(titre, W - M - paint(7f, couleur = GRIS).measureText(titre), 28f, paint(7f, couleur = GRIS))
            c.drawText("LA BONNE COURSE", M, 28f, paint(7f, true, OR_T).apply { letterSpacing = 0.15f })
            // Pied de page
            c.drawLine(M, 806f, W - M, 806f, Paint().apply { color = OR; strokeWidth = 0.6f })
            c.drawText(pied, M, 818f, paint(6.5f, couleur = GRIS))
            val num = "Page $n"
            c.drawText(num, W - M - paint(6.5f, couleur = GRIS).measureText(num), 818f, paint(6.5f, couleur = GRIS))
        }

        /** Garantit [h] points de place, sinon page suivante. */
        fun place(h: Float) { if (y + h > BAS) nouvellePage() }

        fun finir() { page?.let { doc.finishPage(it) }; page = null }
    }

    /** Coupe [t] en lignes tenant dans [w] (mots entiers, mot trop long coupé). */
    fun lignes(t: String, w: Float, p: Paint): List<String> {
        val res = mutableListOf<String>()
        for (para in t.split("\n")) {
            var cur = ""
            for (mot in para.split(" ")) {
                val essai = if (cur.isEmpty()) mot else "$cur $mot"
                if (p.measureText(essai) <= w) { cur = essai; continue }
                if (cur.isNotEmpty()) res += cur
                var m = mot
                while (p.measureText(m) > w && m.length > 1) {
                    var k = m.length - 1
                    while (k > 1 && p.measureText(m.substring(0, k)) > w) k--
                    res += m.substring(0, k); m = m.substring(k)
                }
                cur = m
            }
            res += cur
        }
        return res
    }

    private fun Mise.texte(t: String, p: Paint, x: Float = M, w: Float = W - 2 * M, interligne: Float = 1.35f): Float {
        val ls = lignes(t, w, p)
        val h = p.textSize * interligne
        ls.forEach { l -> place(h); y += p.textSize; c.drawText(l, x, y, p); y += h - p.textSize }
        return ls.size * h
    }

    /** Titre de section, gardé sur la même page que le début de son contenu ([suite] points). */
    private fun Mise.titre(t: String, suite: Float = 56f) {
        place(34f + suite)
        y += 10f
        val p = paint(8.5f, true, OR_T).apply { letterSpacing = 0.12f }
        y += 9f
        c.drawText(t.uppercase(loc), M, y, p)
        y += 7f
    }

    private fun Mise.rect(x0: Float, y0: Float, x1: Float, y1: Float, fond: Int, rayon: Float = 0f) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fond; style = Paint.Style.FILL }
        if (rayon > 0) c.drawRoundRect(RectF(x0, y0, x1, y1), rayon, rayon, p) else c.drawRect(x0, y0, x1, y1, p)
    }

    /**
     * Tableau : en-tête noir et or (répété en haut de chaque page), lignes zébrées ivoire, texte coupé dans sa cellule.
     * [gras] = indices des lignes en gras ; la dernière ligne est un total si [total].
     */
    private fun Mise.tableau(cols: List<Col>, lignes: List<List<String>>, total: Boolean = false, taille: Float = 7.2f,
                             gras: Set<Int> = emptySet(), grises: Set<Int> = emptySet()) {
        val larg = W - 2 * M
        val somme = cols.sumOf { it.part.toDouble() }.toFloat()
        val ws = cols.map { it.part / somme * larg }
        val pad = 3.5f
        val pH = paint(6.4f, true, OR)
        val pN = paint(taille); val pB = paint(taille, true); val pG = paint(taille, couleur = GRIS)
        fun hauteur(cells: List<String>, p: Paint) = cells.mapIndexed { i, s -> lignes(s, ws[i] - 2 * pad, p).size }.maxOrNull()!! * p.textSize * 1.25f + 2 * pad + 1f
        val h1 = lignes.firstOrNull()?.let { hauteur(it, pN) } ?: 0f
        fun entete() {
            val h = hauteur(cols.map { it.titre }, pH)
            place(h + h1 + 2f)
            rect(M, y, M + larg, y + h, NOIR)
            var x = M
            cols.forEachIndexed { i, col ->
                var yy = y + pad + pH.textSize
                lignes(col.titre, ws[i] - 2 * pad, pH).forEach { l ->
                    val tx = if (col.droite) x + ws[i] - pad - pH.measureText(l) else x + pad
                    c.drawText(l, tx, yy, pH); yy += pH.textSize * 1.25f
                }
                x += ws[i]
            }
            y += h
        }
        entete()
        val trait = Paint().apply { color = TRAIT; strokeWidth = 0.4f }
        lignes.forEachIndexed { r, cells ->
            val dernier = total && r == lignes.lastIndex
            val p = when { dernier || r in gras -> pB; r in grises -> pG; else -> pN }
            val h = hauteur(cells, p)
            if (y + h > BAS) { nouvellePage(); entete() }
            when {
                dernier -> { rect(M, y, M + larg, y + h, IVOIRE2); c.drawLine(M, y, M + larg, y, Paint().apply { color = OR; strokeWidth = 0.8f }) }
                r % 2 == 1 -> rect(M, y, M + larg, y + h, IVOIRE)
            }
            var x = M
            cells.forEachIndexed { i, s ->
                var yy = y + pad + p.textSize
                lignes(s, ws[i] - 2 * pad, p).forEach { l ->
                    val tx = if (cols[i].droite) x + ws[i] - pad - p.measureText(l) else x + pad
                    c.drawText(l, tx, yy, p); yy += p.textSize * 1.25f
                }
                x += ws[i]
            }
            y += h
            c.drawLine(M, y, M + larg, y, trait)
        }
        y += 4f
    }

    /** Carte ivoire à filet or : titre + paires libellé / valeur. */
    private fun Mise.carte(x: Float, w: Float, y0: Float, titre: String, paires: List<Pair<String, String>>): Float {
        val pL = paint(7.4f, couleur = GRIS); val pV = paint(7.6f, true)
        val wl = w * 0.36f; val wv = w - wl - 22f
        val hs = paires.map { (a, b) -> max(lignes(a, wl - 4, pL).size, lignes(b, wv, pV).size) * 9.6f + 2.4f }
        val h = 26f + hs.sum() + 8f
        rect(x, y0, x + w, y0 + h, IVOIRE, 3f)
        rect(x, y0, x + 2.5f, y0 + h, OR)
        c.drawText(titre.uppercase(loc), x + 11f, y0 + 16f, paint(7.4f, true, OR_T).apply { letterSpacing = 0.12f })
        var yy = y0 + 28f
        paires.forEachIndexed { i, (a, b) ->
            var ya = yy + 7.4f
            lignes(a, wl - 4, pL).forEach { c.drawText(it, x + 11f, ya, pL); ya += 9.6f }
            var yb = yy + 7.6f
            lignes(b, wv, pV).forEach { c.drawText(it, x + w - 11f - pV.measureText(it), yb, pV); yb += 9.6f }
            yy += hs[i]
        }
        return h
    }

    // ---------------------------------------------------------------- Le rapport

    fun dessiner(doc: PdfDocument, d: RapportDonnees, logo: Bitmap?) {
        val e = d.entreprise
        val nomMois = "${MOIS[d.mois - 1]} ${d.annee}"
        val societe = e.raisonSociale.ifBlank { "Ma société" }
        val edition = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", loc).format(Date(d.edition))
        val mise = Mise(doc, "Relevé mensuel · $nomMois · $societe",
            "Généré par l'application La Bonne Course le $edition · données brutes : export tableur (CSV) du même mois")
        mise.nouvellePage()
        with(mise) {
            // ---- En-tête
            var xTitre = M
            if (logo != null) {
                val hL = 58f; val wL = hL * logo.width / logo.height.coerceAtLeast(1)
                c.drawBitmap(logo, null, RectF(M, y, M + wL, y + hL), Paint(Paint.FILTER_BITMAP_FLAG))
                xTitre = M + wL + 16f
            }
            c.drawText("Relevé mensuel d'activité", xTitre, y + 22f, paint(19f, true))
            c.drawText("et carnet kilométrique", xTitre, y + 44f, paint(19f, true))
            val fin = java.util.Calendar.getInstance().apply { set(d.annee, d.mois - 1, 1) }.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
            c.drawText("$nomMois · du 01/${String.format("%02d", d.mois)}/${d.annee} au $fin/${String.format("%02d", d.mois)}/${d.annee}",
                xTitre, y + 60f, paint(10f, couleur = GRIS))
            y += 72f
            rect(M, y, W - M, y + 1.2f, OR); y += 12f

            // ---- Société et véhicule
            val wC = (W - 2 * M - 10f) / 2
            val v = d.vehicules.first()
            val hG = carte(M, wC, y, "Société et chauffeur", listOfNotNull(
                "Société" to "$societe ${e.forme}".trim(),
                "SIRET" to e.siret.ifBlank { "—" },
                "Registre VTC" to e.evtc.ifBlank { "—" },
                "Chauffeur" to e.chauffeur.ifBlank { "—" },
                e.adresse.takeIf { it.isNotBlank() }?.let { "Siège" to it }))
            val hD = carte(M + wC + 10f, wC, y, if (d.vehicules.size > 1) "Véhicules" else "Véhicule", d.vehicules.flatMap { vv ->
                listOf("Modèle" to vv.modele, "Immatriculation" to vv.immat.ifBlank { "—" }, "Énergie" to "100 % électrique · ${n1(vv.batterieKwh).removeSuffix(",0")} kWh",
                    "Situation" to vv.statut, "Compteur" to if (vv.connectee) "envoyé par la voiture" else "photo horodatée du tableau de bord")
            })
            y += max(hG, hD) + 6f

            // ---- Synthèse kilométrique
            titre("Synthèse kilométrique du mois")
            val cp = d.compteur
            val synth = mutableListOf<List<String>>()
            if (cp != null) {
                synth += listOf("Premier relevé du compteur (${SimpleDateFormat("dd/MM HH:mm", loc).format(Date(cp.premier.t))})", km(cp.premier.odoKm), "")
                synth += listOf("Dernier relevé du compteur (${SimpleDateFormat("dd/MM HH:mm", loc).format(Date(cp.dernier.t))})", km(cp.dernier.odoKm), "")
                synth += listOf("Km parcourus entre ces deux relevés", km(cp.total), "")
            }
            synth += listOf("Km professionnels (en service)", if (cp != null && cp.service > 0) km(cp.service) else "—", km(d.kmService))
            synth += listOf("Km personnels (hors service)", if (cp != null && cp.service > 0) km(cp.horsService) else "—", km(d.kmPerso))
            synth += listOf("Part professionnelle", if (cp != null && cp.total > 0 && cp.service > 0) "${n1(cp.service / cp.total * 100)} %" else "—",
                if (d.kmService + d.kmPerso > 0) "${n1(d.partPro * 100)} %" else "—")
            val ecart = if (cp != null && cp.service > 0 && d.kmService > 0) (d.kmService - cp.service) / cp.service * 100 else null
            if (ecart != null) synth += listOf("Écart GPS / compteur sur les km professionnels", "", String.format(loc, "%+.2f %%", ecart))
            tableau(listOf(Col("", 5.6f), Col("Compteur du véhicule", 2.2f, true), Col("GPS du téléphone", 2.2f, true)), synth,
                gras = setOf(synth.indexOfFirst { it[0].startsWith("Km professionnels") }, synth.indexOfFirst { it[0] == "Part professionnelle" }))
            if (ecart != null && abs(ecart) > 3) texte("Écart supérieur à 3 % : un relevé du compteur manque probablement (début ou fin de service).", paint(7f, couleur = ROUGE))

            titre("Répartition des kilomètres professionnels (GPS)")
            val kp = d.kmService.takeIf { it > 0 } ?: 1.0
            fun pc(x: Double) = "${n1(x / kp * 100)} %"
            tableau(listOf(Col("Nature du trajet", 6.6f), Col("Km", 1.7f, true), Col("Part", 1.7f, true)), listOf(
                listOf("Domicile › première course, et fin de service › domicile", km(d.kmDomicile), pc(d.kmDomicile)),
                listOf("Approche (course acceptée › client à bord)", km(d.kmApproche), pc(d.kmApproche)),
                listOf("Client à bord (prise en charge › dépose)", km(d.kmClient), pc(d.kmClient)),
                listOf("À vide entre deux courses, recharge, trajets classés pro", km(d.kmVide), pc(d.kmVide)),
                listOf("Total professionnel", km(d.kmService), "100 %")), total = true)

            titre("Activité")
            val act = d.parSource.map { (s, nb, ca) -> listOf(s, nb.toString(), eur(ca)) } + listOf(listOf("Total", d.courses.size.toString(), eur(d.encaisse)))
            tableau(listOf(Col("Plateforme", 5.6f), Col("Courses", 2.2f, true), Col("Encaissé TTC", 2.2f, true)), act, total = true)
            val h = d.minutesService / 60
            texte("${d.joursTravailles} jour${if (d.joursTravailles > 1) "s" else ""} de service" +
                (if (h > 0) " · ${String.format(loc, "%.0f", h)} h de service (bulle lancée)" else "") +
                " · ${d.courses.count { it.prive }} course${if (d.courses.count { it.prive } > 1) "s" else ""} privée${if (d.courses.count { it.prive } > 1) "s" else ""}, " +
                "facturée${if (d.courses.count { it.prive } > 1) "s" else ""} et signée${if (d.courses.count { it.prive } > 1) "s" else ""} par le client · " +
                "encaissé à rapprocher des relevés de paiement des plateformes.", paint(7f, couleur = GRIS))

            titre("Méthode de relevé")
            texte("Chaque kilomètre est enregistré automatiquement par l'application La Bonne Course : (1) position GPS du téléphone, " +
                "un point environ tous les 6 mètres, horodaté à la seconde, pendant tout le service (bulle lancée) : approche, client à bord, " +
                "trajets entre deux courses, départ du domicile et retour ; (2) compteur kilométrique du véhicule, " +
                (if (d.connecte) "envoyé par la voiture elle-même (Tesla Fleet Telemetry via Teslemetry) au début et à la fin de chaque service, " +
                    "à l'acceptation de chaque course, à la prise en charge et à la dépose du client"
                else "photographié au tableau de bord au début et à la fin de chaque service (photo horodatée conservée, kilométrage lu sur la photo)") +
                ". Hors service, chaque trajet est détecté automatiquement puis classé professionnel ou personnel. " +
                "Les tracés GPS, les photos et les factures sont conservés et peuvent être produits course par course.", paint(8f), interligne = 1.4f)

            // ---- Frais
            if (d.frais.isNotEmpty()) {
                titre("Frais du mois")
                val lf = d.frais.map { listOf(it.nom, eur(it.ttc), if (it.tva > 0) eur(it.tva) else "—", eur(it.ht), it.nb.toString(),
                    if (it.justifies == it.nb) "oui" else "${it.justifies} / ${it.nb}") } +
                    listOf(listOf("Total", eur(d.frais.sumOf { it.ttc }), eur(d.frais.sumOf { it.tva }), eur(d.frais.sumOf { it.ht }),
                        d.frais.sumOf { it.nb }.toString(), ""))
                tableau(listOf(Col("Poste", 3.6f), Col("TTC", 1.6f, true), Col("TVA", 1.4f, true), Col("HT", 1.6f, true),
                    Col("Nb", 0.7f, true), Col("Justificatif", 1.3f, true)), lf, total = true)
                if (d.recharges.isNotEmpty()) {
                    titre("Recharges")
                    tableau(listOf(Col("Date", 1.3f), Col("Détail", 6.3f), Col("TTC", 1.4f, true)),
                        d.recharges.map { listOf(SimpleDateFormat("dd/MM HH:mm", loc).format(Date(it.date)), it.note.ifBlank { it.categorie.nom }, eur(it.ttc)) } +
                            listOf(listOf("Total", "", eur(d.recharges.sumOf { it.ttc }))), total = true)
                }
            }

            // ---- Carnet journalier
            nouvellePage()
            titre("Carnet kilométrique jour par jour")
            val js = listOf("dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam.")
            val cal = java.util.Calendar.getInstance()
            val gris = mutableSetOf<Int>()
            val lj = d.jours.mapIndexed { i, j ->
                cal.timeInMillis = j.date
                val jourTxt = "${js[cal.get(java.util.Calendar.DAY_OF_WEEK) - 1]} ${jm.format(Date(j.date))}"
                if (!j.travaille) {
                    gris += i
                    listOf(jourTxt, "Repos", "", "", "", "", "", "", "", if (j.kmPerso > 0) n1(j.kmPerso) else "", "", "")
                } else listOf(jourTxt,
                    if (j.debut != null && j.fin != null) "${hm.format(Date(j.debut))}–${hm.format(Date(j.fin))}" else "",
                    j.odoDebut?.let { n1(it) } ?: "", j.odoFin?.let { n1(it) } ?: "",
                    n1(j.kmService), n1(j.kmDomicile), n1(j.kmApproche), n1(j.kmClient), n1(j.kmVide),
                    if (j.kmPerso > 0) n1(j.kmPerso) else "", j.courses.toString(), if (j.encaisse > 0) eur(j.encaisse) else "")
            } + listOf(listOf("Total", "", "", "", n1(d.kmService), n1(d.kmDomicile), n1(d.kmApproche), n1(d.kmClient), n1(d.kmVide),
                n1(d.kmPerso), d.courses.size.toString(), eur(d.encaisse)))
            tableau(listOf(Col("Jour", 1.05f), Col("Service", 1.2f), Col("Compteur début", 1.1f, true), Col("Compteur fin", 1.1f, true),
                Col("Km service", 0.95f, true), Col("Domicile", 0.85f, true), Col("Approche", 0.85f, true), Col("Client", 0.85f, true),
                Col("À vide", 0.8f, true), Col("Km perso", 0.8f, true), Col("Nb", 0.55f, true), Col("Encaissé", 1.25f, true)),
                lj, total = true, taille = 6.8f, grises = gris)
            texte("Km en kilomètres. Km service : mesurés au GPS, bulle lancée (dont domicile, approche, client à bord, à vide), " +
                "plus les trajets hors bulle classés professionnels. Compteur : relevés du véhicule au début et à la fin du service.", paint(6.8f, couleur = GRIS))

            // ---- Détail des courses
            if (d.courses.isNotEmpty()) {
                nouvellePage()
                titre("Détail des courses (${d.courses.size})")
                fun court(s: String) = s.substringBefore(" (").let { l -> val p = l.split(", "); if (p.size >= 2) "${p.first()} (${p.last()})" else l }
                // Colonne compteur seulement si la voiture l'envoie à chaque course (Tesla)
                val avecOdo = d.courses.any { it.odoFin > 0 }
                val lc = d.courses.map { r ->
                    listOf(jm.format(Date(r.debut)), hm.format(Date(r.debut)), hm.format(Date(r.priseEnCharge)), hm.format(Date(r.fin)),
                        r.source + if (r.facture.isNotBlank()) "\n${r.facture}" else "",
                        listOf(court(r.lieuPrise), court(r.lieuArrivee)).filter { it.isNotBlank() && Classement.coord(it) == null }.joinToString(" › ").ifBlank { "—" },
                        n2(r.kmApproche), n2(r.kmCourse)) + (if (avecOdo) listOf(if (r.odoFin > 0) n1(r.odoFin) else "") else emptyList()) +
                        listOf(if (r.prix > 0) eur(r.prix) else "—")
                } + listOf(listOf("Total", "", "", "", "", "${d.courses.size} courses", n1(d.kmApproche), n1(d.kmClient)) +
                    (if (avecOdo) listOf("") else emptyList()) + listOf(eur(d.encaisse)))
                tableau(listOf(Col("Date", 0.62f), Col("Acceptée", 0.75f), Col("À bord", 0.66f), Col("Déposé", 0.7f), Col("Plateforme", 1.0f),
                    Col("Trajet (prise en charge › dépose)", if (avecOdo) 3.5f else 4.45f), Col("Km appr.", 0.72f, true), Col("Km client", 0.75f, true)) +
                    (if (avecOdo) listOf(Col("Compteur dépose", 0.95f, true)) else emptyList()) + listOf(Col("Montant", 0.95f, true)),
                    lc, total = true, taille = 6.8f)
            }

            // ---- Trajets hors service
            if (d.trajets.isNotEmpty()) {
                titre("Trajets hors bulle (détectés automatiquement ou ajoutés)")
                fun court(s: String) = s.substringBefore(" (").let { if (Classement.coord(it) != null) "" else it }
                val lt = d.trajets.map { t ->
                    listOf("${jm.format(Date(t.debut))} ${hm.format(Date(t.debut))}–${hm.format(Date(t.fin))}",
                        listOf(court(t.depart), court(t.arrivee)).filter { it.isNotBlank() }.joinToString(" › ").ifBlank { "—" },
                        n2(t.km), when (t.statut) { Trajet.PRO -> "Pro"; Trajet.PERSO -> "Perso"; else -> "À classer" },
                        when { t.manuel -> "ajouté à la main"; t.raison.isNotBlank() -> "auto : ${t.raison}"; else -> "choisi par le chauffeur" })
                }
                tableau(listOf(Col("Date", 1.5f), Col("Trajet", 4.4f), Col("Km", 0.8f, true), Col("Classement", 0.9f), Col("Origine", 2.4f)),
                    lt, taille = 6.8f)
            }

            // ---- Relevés du compteur
            if (d.releves.isNotEmpty()) {
                titre("Relevés du compteur (${d.releves.size})")
                val lr = d.releves.map { r ->
                    listOf("${jour.format(Date(r.t))} ${hms.format(Date(r.t))}", r.libelle, km(r.odoKm),
                        if (r.batterie >= 0) "${String.format(loc, "%.0f", r.batterie)} %" else "", r.source +
                            if (r.majVoiture > 0) " (${hms.format(Date(r.majVoiture))})" else "")
                }
                tableau(listOf(Col("Date et heure", 2.0f), Col("Événement", 2.4f), Col("Compteur", 1.4f, true), Col("Batterie", 0.9f, true),
                    Col("Source", 2.5f)), lr, taille = 6.8f)
            }

            // ---- Pièces et attestation
            place(260f)
            titre("Pièces à joindre en cas de contrôle")
            listOf("Ce relevé (PDF) et l'export tableur (CSV) du même mois : données brutes, ouvrables dans Excel.",
                "Relevés de paiement mensuels Uber, Bolt…, pour rapprocher l'encaissé course par course.",
                "Factures des courses privées, signées par les clients.",
                "Contrat de location du véhicule, carte grise, attestation d'assurance VTC.",
                "Justificatifs de frais : factures de recharge, d'électricité, tickets photographiés." +
                    if (!d.connecte) " Photos du compteur horodatées (sur le téléphone)." else ""
            ).forEach { texte("•  $it", paint(8f), x = M + 4f, w = W - 2 * M - 8f) }
            titre("Attestation")
            texte("Je soussigné(e), ${e.chauffeur.ifBlank { "…………………………" }}, représentant de $societe, certifie que les informations de ce relevé " +
                "sont issues de l'enregistrement automatique de l'activité et des relevés du véhicule, et qu'elles sont exactes et complètes " +
                "pour la période du mois de ${nomMois.lowercase(loc)}.", paint(8.5f), interligne = 1.45f)
            y += 14f
            val ville = Regex("\\b\\d{5}\\s+(.+)$").find(e.adresse.trim())?.groupValues?.get(1)?.trim()
                ?: e.adresse.substringAfterLast(",").trim().ifBlank { "…………" }
            c.drawText("Fait à $ville, le ${jour.format(Date(d.edition))}", M, y + 10f, paint(8.5f))
            c.drawText("Signature", M + (W - 2 * M) / 2, y + 10f, paint(8.5f, couleur = GRIS))
            val cadre = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = TRAIT; style = Paint.Style.STROKE; strokeWidth = 0.8f }
            c.drawRoundRect(RectF(M + (W - 2 * M) / 2, y + 18f, W - M, y + 78f), 4f, 4f, cadre)
            y += 86f
        }
        mise.finir()
    }
}
