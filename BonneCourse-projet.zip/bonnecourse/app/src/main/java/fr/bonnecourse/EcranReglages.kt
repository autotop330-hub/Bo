package fr.bonnecourse

import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.appcompat.widget.SwitchCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Onglet « Réglages » : société (factures), voiture, tri des offres, impôts, outils. */
class EcranReglages(private val a: MainActivity) {
    private val store = a.store
    private val PARTS = listOf(1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0)

    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Réglages"))
        col.addView(societe())
        col.addView(domicile())
        col.addView(trafic())
        col.addView(voiture())
        col.addView(offres())
        col.addView(impots())
        col.addView(outils())
    }

    private fun societe(): LinearLayout {
        val c = W.carte(a, "Ma société (sur les factures)")
        val e = store.entreprise
        c.addView(Ui.text(a, if (e.complete) "✓ ${e.raisonSociale} · SIRET ${e.siret}" else "À remplir avant la première facture.", 15f,
            if (e.complete) Ui.GO else Ui.WARN, true))
        FacturePdf.logo(a)?.let { b ->
            c.addView(android.widget.ImageView(a).apply {
                setImageBitmap(b); adjustViewBounds = true
                background = Ui.box(a, android.graphics.Color.WHITE, Ui.LINE, 1, 12)
                val p = Ui.dp(a, 8); setPadding(p, p, p, p)
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(a, 110)))
        }
        c.addView(W.bouton(a, "Voir un exemple de facture", true) {
            try { FacturePdf.ouvrir(a, FacturePdf.exemple(a, store.entreprise, store.profile)) }
            catch (ex: Exception) { a.toast("Exemple impossible : ${ex.message}") }
        })
        val perso = FacturePdf.fichierLogo(a).exists()
        c.addView(Ui.buttonRow(a,
            *listOfNotNull(
                W.bouton(a, "Changer le logo") { a.choisirLogo() },
                if (perso) W.bouton(a, "Logo d'origine") { FacturePdf.fichierLogo(a).delete(); a.afficher() } else null
            ).toTypedArray()))
        val form = Ui.vertical(a, 6)
        val lire = FormSociete.champs(a, form, e)
        form.addView(W.bouton(a, "Enregistrer", true) { store.entreprise = lire(); a.toast("Société enregistrée"); a.afficher() })
        c.addView(Ui.details(a, "Modifier", form, !e.complete))
        return c
    }

    /** Domicile : point de départ et d'arrivée des journées (carnet kilométrique). */
    private fun domicile(): LinearLayout {
        val c = W.carte(a, "Mon domicile")
        val dom = store.domicile
        c.addView(Ui.text(a, if (dom != null) "✓ " + store.adresseDomicile.ifBlank { "Domicile enregistré" } else "Pas encore enregistré.", 15f,
            if (dom != null) Ui.GO else Ui.WARN, true))
        c.addView(W.aide(a, "La bulle lancée devant chez toi enregistre le « Départ du domicile » jusqu'à la 1re course. " +
            "En fin de service : appui long sur la bulle → « Rentrer au domicile » ; le trajet se termine tout seul devant chez toi."))
        c.addView(W.bouton(a, if (dom == null) "Je suis chez moi : enregistrer ma position" else "Mettre à jour avec ma position", dom == null) { a.domicileIci() })
        val form = Ui.vertical(a, 6)
        val adr = W.champ(a, form, "Ou tape l'adresse", "", indice = "ex. 12 rue …, 34540 Balaruc-les-Bains")
        form.addView(W.bouton(a, "Chercher cette adresse") { a.domicileAdresse(W.txt(adr)) })
        c.addView(Ui.details(a, "Saisir l'adresse à la main", form))
        return c
    }

    /** Clé TomTom : trafic réel dans la bulle et tracés recalés sur les routes. */
    private fun trafic(): LinearLayout {
        val c = W.carte(a, "Trafic en temps réel")
        val cle = store.cleTomTom
        c.addView(Ui.text(a, if (cle.isNotBlank()) "✓ Activé : chaque offre est calculée avec les bouchons du moment" else
            "Non activé : la bulle n'a pas encore le trafic en direct", 15f, if (cle.isNotBlank()) Ui.GO else Ui.WARN, true))
        c.addView(W.aide(a, "Avec TomTom (gratuit, sans carte bancaire, 20 000 calculs par mois) :\n" +
            "• durée réelle de l'approche et de la course avec les bouchons du moment ;\n" +
            "• tracé des courses qui suit parfaitement les rues sur la carte."))
        val form = Ui.vertical(a, 6)
        form.addView(W.aide(a, "1. Ouvre developer.tomtom.com et crée un compte gratuit.\n2. Dans « Keys », copie ta clé (API Key).\n3. Colle-la ici."))
        form.addView(W.bouton(a, "Ouvrir le site TomTom") {
            try { a.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://developer.tomtom.com/user/register"))) } catch (_: Exception) {}
        })
        val e = W.champ(a, form, "Clé TomTom (API Key)", cle, indice = "colle ta clé ici")
        form.addView(W.bouton(a, "Enregistrer et tester", true) {
            val k = W.txt(e)
            if (k.isBlank()) { store.cleTomTom = ""; a.toast("Trafic en direct désactivé"); a.afficher(); return@bouton }
            TraficDirect.essayer(a, k)
        })
        c.addView(Ui.details(a, if (cle.isBlank()) "Activer (2 minutes)" else "Modifier la clé", form))
        return c
    }

    private fun voiture(): LinearLayout {
        val c = W.carte(a, "La voiture")
        val p = store.profile
        c.addView(Ui.text(a, "Tesla Model Y Grande Autonomie Propulsion", 16f, Ui.FG, true))
        c.addView(W.aide(a, "Au nom du propriétaire (pas du chauffeur) et louée à la SASU avec un contrat écrit : " +
            "la société paie le loyer, l'assurance, la recharge et l'entretien. Pas d'indemnités kilométriques possibles."))
        val form = Ui.vertical(a, 6)
        val fixes = W.champ(a, form, "Loyer + assurance par mois (€)", W.n(p.fixesMois), W.NOMBRE)
        val conso = W.champ(a, form, "Consommation (kWh pour 100 km)", W.n(p.conso), W.NOMBRE)
        val prix = W.champ(a, form, "Prix moyen du kWh (€) · domicile ≈ 0,20 · Superchargeur ≈ 0,40", W.n(p.prixEnergie), W.NOMBRE)
        val usure = W.champ(a, form, "Pneus et entretien (€ par km)", W.n(p.usure), W.NOMBRE)
        val km = W.champ(a, form, "Km roulés par mois", W.n(p.kmMois), W.NOMBRE)
        form.addView(W.bouton(a, "Enregistrer", true) {
            val o = store.profile
            store.profile = o.copy(fixesMois = W.nombre(fixes) ?: o.fixesMois, conso = W.nombre(conso) ?: o.conso,
                prixEnergie = W.nombre(prix) ?: o.prixEnergie, usure = W.nombre(usure) ?: o.usure, kmMois = (W.nombre(km) ?: o.kmMois).coerceAtLeast(1.0),
                energy = "electrique")
            a.toast("Enregistré · coût ${Analyzer.fmt2(store.profile.coutKm())} € par km roulé"); a.afficher()
        })
        c.addView(W.ligne(a, "Coût par km roulé", "${Analyzer.fmt2(p.coutKm())} €"))
        c.addView(Ui.details(a, "Modifier", form))
        return c
    }

    private fun offres(): LinearLayout {
        val c = W.carte(a, "Trier les offres")
        val p = store.profile
        c.addView(W.pastille(a, Ui.GO, "Vert : bonne course, à accepter", 14f))
        c.addView(W.pastille(a, Ui.WARN, "Orange : moyenne, à prendre si rien de mieux", 14f))
        c.addView(W.pastille(a, Ui.STOP, "Rouge : pas rentable, à refuser", 14f))
        c.addView(W.aide(a, "Calcul : ce qui reste après recharge, usure, loyer, assurance et TVA, rapporté au temps et aux km (approche comprise)."))
        val form = Ui.vertical(a, 6)
        val obj = W.champ(a, form, "Objectif net par heure (€)", W.n(p.objectifHeure), W.NOMBRE)
        val mini = W.champ(a, form, "Minimum par km roulé (€)", W.n(p.minimumKm), W.NOMBRE)
        form.addView(W.aide(a, "Plus tu montes ces deux chiffres, plus la bulle est exigeante."))
        form.addView(W.bouton(a, "Enregistrer", true) {
            val o = store.profile
            store.profile = o.copy(objectifHeure = (W.nombre(obj) ?: o.objectifHeure).coerceAtLeast(1.0),
                minimumKm = (W.nombre(mini) ?: o.minimumKm).coerceAtLeast(0.1))
            a.toast("Enregistré"); a.afficher()
        })
        c.addView(W.ligne(a, "Objectif", "${p.objectifHeure.roundToInt()} €/h · ${Analyzer.fmt2(p.minimumKm)} €/km"))
        c.addView(Ui.details(a, "Modifier", form))
        return c
    }

    private fun impots(): LinearLayout {
        val c = W.carte(a, "Impôts et société")
        val p = store.profile
        val s = store.situation
        c.addView(W.ligne(a, "TVA", if (p.tva) "10 % sur le prix client" else "non assujettie"))
        c.addView(W.ligne(a, "Foyer", "${W.n(s.parts)} part${if (s.parts > 1) "s" else ""}" + if (s.couple) " · en couple" else ""))
        val form = Ui.vertical(a, 6)
        val tva = SwitchCompat(a).apply { text = "Société assujettie à la TVA (obligatoire au-delà de 37 500 € par an)"; setTextColor(Ui.FG); isChecked = p.tva }
        form.addView(tva)
        val comm = W.champ(a, form, "Part gardée par Uber/Bolt sur le prix client (%)", W.n(p.commissionPlateforme), W.NOMBRE)
        val autres = W.champ(a, form, "Frais de la société par mois si rien n'est saisi (comptable, banque, téléphone…)", W.n(p.autresFrais), W.NOMBRE)
        val tmi = W.champ(a, form, "Ta tranche d'impôt (%) : 0, 11, 30…", W.n(p.tmi), W.NOMBRE)
        form.addView(Ui.text(a, "Parts fiscales du foyer", 13f, Ui.MUTED))
        val parts = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, PARTS.map { "${W.n(it)} part" + if (it > 1) "s" else "" })
            setSelection(PARTS.indexOf(s.parts).coerceAtLeast(0))
        }
        form.addView(parts)
        val couple = SwitchCompat(a).apply { text = "Marié ou pacsé"; setTextColor(Ui.FG); isChecked = s.couple }
        form.addView(couple)
        val retraite = SwitchCompat(a).apply { text = "Valider 4 trimestres de retraite par an"; setTextColor(Ui.FG); isChecked = s.retraite }
        form.addView(retraite)
        val autresRev = W.champ(a, form, "Autres revenus du foyer par an (€)", W.n(s.autresRevenus), W.NOMBRE)
        val (pg, pk) = store.prevision
        val prevG = W.champ(a, form, "Prévision : versements par mois (0 = mes vraies courses)", W.n(pg), W.NOMBRE)
        val prevK = W.champ(a, form, "Prévision : km pro par mois", W.n(pk), W.NOMBRE)
        form.addView(W.bouton(a, "Enregistrer", true) {
            val o = store.profile
            store.profile = o.copy(tva = tva.isChecked, commissionPlateforme = (W.nombre(comm) ?: o.commissionPlateforme).coerceIn(0.0, 90.0),
                autresFrais = W.nombre(autres) ?: o.autresFrais, tmi = (W.nombre(tmi) ?: o.tmi).coerceIn(0.0, 45.0))
            store.situation = Optimiseur.Situation(PARTS[parts.selectedItemPosition.coerceIn(0, PARTS.size - 1)], couple.isChecked,
                W.nombre(autresRev) ?: 0.0, retraite.isChecked)
            store.prevision = (W.nombre(prevG) ?: 0.0) to (W.nombre(prevK) ?: 4000.0)
            a.toast("Enregistré"); a.afficher()
        })
        c.addView(Ui.details(a, "Modifier", form))
        return c
    }

    private fun outils(): LinearLayout {
        val c = W.carte(a, "Outils")
        val auto = SwitchCompat(a).apply { text = "Détecter mes trajets automatiquement (bulle arrêtée)"; setTextColor(Ui.FG); isChecked = store.autoTrajets }
        auto.setOnCheckedChangeListener { _, on -> a.basculerAuto(on) }
        c.addView(auto)
        c.addView(W.aide(a, "Chaque trajet en voiture est enregistré tout seul ; une notification demande ensuite : pro ou perso ?"))
        c.addView(W.bouton(a, "Tester la bulle avec une capture d'écran") { a.testerCapture() })
        // Historique des offres lues
        val h = store.history()
        val det = Ui.vertical(a, 6)
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        h.take(40).forEach { e ->
            val v = runCatching { Verdict.valueOf(e.verdict) }.getOrDefault(Verdict.A_VOIR)
            det.addView(W.pastille(a, Ui.color(v), "${fmt.format(Date(e.t))} · ${Analyzer.fmt2(e.prix)} € · ${v.mot} · ${e.parHeure.roundToInt()} €/h", 13f))
        }
        if (h.isNotEmpty()) det.addView(W.bouton(a, "Effacer l'historique") { store.clear(); a.afficher() })
        else det.addView(W.aide(a, "Aucune offre lue pour l'instant."))
        c.addView(Ui.details(a, "Offres lues par la bulle (${h.size})", det))
        return c
    }
}
