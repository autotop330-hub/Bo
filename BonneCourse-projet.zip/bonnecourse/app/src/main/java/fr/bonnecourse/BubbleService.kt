package fr.bonnecourse

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/**
 * Service de premier plan :
 *  - affiche la bulle par-dessus les autres applis ;
 *  - toucher la bulle → capture de l'écran → lecture → tuile de verdict ;
 *  - « J'accepte » → compteur GPS de la course (approche puis client à bord), à la minute et au mètre.
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_START = "fr.bonnecourse.START"
        const val ACTION_STOP = "fr.bonnecourse.STOP"
        /** Démarre une course client privé (lance le service en GPS seul s'il ne tourne pas). */
        const val ACTION_PRIVE = "fr.bonnecourse.PRIVE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "bulle"
        private const val NOTIF_ID = 7
        private const val TILE_MS = 15_000L
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var store: Store
    private val main = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null

    // Capture d'écran
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val lock = Any()
    private var latest: Image? = null

    // Bulle et tuile
    private var bubble: View? = null
    private var bubbleRing: GradientDrawable? = null
    private var tileWrap: FrameLayout? = null
    private var busy = false
    private val closeTile = Runnable { removeTile() }

    // Kilométrage
    private val odo = Odometer()
    private val tracker = RideTracker(odo)
    private var gps = false
    private var lastFix = 0L
    private var pendingM = 0.0
    private var pendingPersoM = 0.0
    private var perso = false                      // mode trajet perso : km exclus des indemnités
    private var nextPrice: Double? = null          // offre acceptée pendant une course (enchaînement)
    private var nextMeta: Meta? = null
    private var meta: Meta? = null                 // ce que disait l'offre de la course en cours
    private val trace = ArrayList<Point>()         // boîte noire : tracé GPS de la course en cours
    private var dernierPoint: Point? = null

    /** Ce que l'offre acceptée annonçait, gardé avec la course. */
    // Carnet kilométrique : trajet domicile → 1re course, ou fin de service → domicile
    private var segType: String? = null
    private var segDebut = 0L
    private var segM = 0.0
    private var segLieu = ""
    private val segTrace = ArrayList<Point>()
    private var attenteDepart = false

    // Position : fournisseur « fused » de Google (GPS + capteurs, plus précis en ville), sinon GPS seul
    private var fused: com.google.android.gms.location.FusedLocationProviderClient? = null
    private val fusedCb = object : com.google.android.gms.location.LocationCallback() {
        override fun onLocationResult(r: com.google.android.gms.location.LocationResult) { r.locations.forEach { surPosition(it) } }
    }

    private data class Meta(val plateforme: String, val verdict: String, val score: Double, val km: Double, val min: Double)
    private var ridePanelOpen = false
    private val tick = object : Runnable {
        override fun run() { if (ridePanelOpen) { drawRidePanel(); main.postDelayed(this, 1000) } }
    }
    private val jour = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        store = Store(this)
    }

    private fun hasLocation() =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                // Passer en premier plan AVANT de récupérer la projection (obligatoire depuis Android 14)
                var types = 0
                if (Build.VERSION.SDK_INT >= 29) {
                    types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    if (hasLocation()) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                }
                ServiceCompat.startForeground(this, NOTIF_ID, notification(), types)
                val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
                if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
                releaseCapture()
                startCapture(code, data)
                // Un trajet automatique en cours s'arrête : la bulle prend le relais
                if (TrackService.running) try { startService(Intent(this, TrackService::class.java).setAction(TrackService.ACTION_STOP)) } catch (_: Exception) {}
                startGps()
                perso = false; store.modePerso = false   // lancer la bulle = début du service
                attenteDepart = segType == null && tracker.phase == Phase.AUCUNE   // parti du domicile ? (1re position)
                showBubble()
                updateBubbleLook()
                running = true
            }
            ACTION_PRIVE -> {
                if (!running) {
                    if (!hasLocation()) { stopSelf(); return START_NOT_STICKY }
                    ServiceCompat.startForeground(this, NOTIF_ID, notification(),
                        if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
                    if (TrackService.running) try { startService(Intent(this, TrackService::class.java).setAction(TrackService.ACTION_STOP)) } catch (_: Exception) {}
                    startGps()
                    perso = false; store.modePerso = false
                    showBubble()
                    running = true
                }
                if (tracker.phase == Phase.AUCUNE) {
                    flushService(); perso = false; store.modePerso = false
                    commencer(0.0, "prive", null)
                    updateBubbleLook(); openRidePanel()
                }
            }
        }
        return START_NOT_STICKY
    }

    /** Début d'une course : compteur, tracé GPS et infos de l'offre. */
    private fun commencer(prix: Double, type: String, m: Meta?) {
        // Le trajet depuis le domicile s'arrête à la 1re course ; un retour interrompu par une course est abandonné
        attenteDepart = false
        if (segType == Segment.DEPART) finirSegment(true) else if (segType == Segment.RETOUR) finirSegment(false)
        tracker.accepter(prix, type)
        meta = m
        trace.clear(); dernierPoint = null
        odo.position?.let { (la, lo) -> ajouterPoint(la, lo, System.currentTimeMillis()) }
    }

    private fun ajouterPoint(lat: Double, lon: Double, t: Long) {
        val ph = when (tracker.phase) { Phase.APPROCHE -> 0; Phase.COURSE -> 1; Phase.AUCUNE -> return }
        val d = dernierPoint
        // Un point tous les 6 m, ou toutes les 10 s à l'arrêt, ou à chaque changement de phase : le tracé suit les rues
        if (d != null && d.phase == ph && t - d.t < 10_000 && Odometer.distanceM(d.lat, d.lon, lat, lon) < 6) return
        val p = Point(lat, lon, t, ph)
        trace += p; dernierPoint = p
    }

    // ================================================================ GPS

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) = surPosition(l)
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    /** Chaque position : km du jour, tracé de la course ou du trajet domicile, arrivée au domicile. */
    private fun surPosition(l: Location) {
        if (l.time - lastFix > 60_000) odo.reset()      // GPS perdu plus d'une minute
        lastFix = l.time
        val d = odo.add(l.latitude, l.longitude, l.accuracy, l.time, if (l.hasSpeed()) l.speed else null)
        val maintenant = System.currentTimeMillis()
        if (l.accuracy <= 35f) {
            if (tracker.phase != Phase.AUCUNE) ajouterPoint(l.latitude, l.longitude, maintenant)
            else if (segType != null && !perso) pointSegment(l.latitude, l.longitude, maintenant)
        }
        if (segType != null && !perso && tracker.phase == Phase.AUCUNE) segM += d
        if (perso) pendingPersoM += d else pendingM += d
        if (pendingM + pendingPersoM >= 200) flushService()
        verifierDomicile(l)
    }

    @SuppressLint("MissingPermission")
    private fun startGps() {
        if (gps || !hasLocation()) return
        try {
            val req = com.google.android.gms.location.LocationRequest.Builder(
                com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(1000L)
                .build()
            val c = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(this)
            c.requestLocationUpdates(req, fusedCb, Looper.getMainLooper())
            fused = c
            gps = true
            return
        } catch (_: Exception) { fused = null }
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
            gps = true
        } catch (_: Exception) { gps = false }
    }

    private fun stopGps() {
        if (!gps) return
        try { fused?.removeLocationUpdates(fusedCb) } catch (_: Exception) {}
        fused = null
        try { (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(locListener) } catch (_: Exception) {}
        gps = false
    }

    // ================================================================ Domicile (carnet kilométrique)

    private fun coordonnees() = odo.position?.let { String.format(Locale.US, "%.5f,%.5f", it.first, it.second) } ?: ""

    private fun nomDomicile() = store.adresseDomicile.ifBlank { "Domicile" }

    private fun verifierDomicile(l: Location) {
        val dom = store.domicile ?: return
        if (l.accuracy > 50f) return
        val dist = Odometer.distanceM(l.latitude, l.longitude, dom.first, dom.second)
        if (attenteDepart) {
            attenteDepart = false
            if (dist < 300 && segType == null && tracker.phase == Phase.AUCUNE && !perso) demarrerSegment(Segment.DEPART)
        }
        if (segType == Segment.RETOUR && dist < 120) finirSegment(true)
    }

    private fun demarrerSegment(type: String) {
        flushService()
        segType = type; segDebut = System.currentTimeMillis(); segM = 0.0
        segTrace.clear()
        segLieu = if (type == Segment.DEPART) nomDomicile() else coordonnees()
        odo.position?.let { (la, lo) -> pointSegment(la, lo, segDebut) }
        updateBubbleLook()
    }

    private fun pointSegment(lat: Double, lon: Double, t: Long) {
        val d = segTrace.lastOrNull()
        if (d != null && t - d.t < 10_000 && Odometer.distanceM(d.lat, d.lon, lat, lon) < 6) return
        segTrace += Point(lat, lon, t, 2)
    }

    /** Termine le trajet domicile en cours ; enregistré si [garder] et assez long. */
    private fun finirSegment(garder: Boolean) {
        val type = segType ?: return
        segType = null
        val points = ArrayList(segTrace)
        segTrace.clear()
        updateBubbleLook()
        if (!garder || segM < 100) return
        flushService()
        val sg = Segment(segDebut, System.currentTimeMillis(), type, segM / 1000.0,
            segLieu, if (type == Segment.RETOUR) nomDomicile() else coordonnees())
        store.addSegment(sg)
        store.saveTraceSegment(sg.debut, points)
        if (type == Segment.RETOUR) {
            vibrateShort()
            android.widget.Toast.makeText(this, "Bien rentré · ${Analyzer.fmt1(sg.km)} km enregistrés", android.widget.Toast.LENGTH_LONG).show()
        }
        Thread {
            try { store.addSegment(sg.copy(lieuDepart = lieu(sg.lieuDepart), lieuArrivee = lieu(sg.lieuArrivee))) } catch (_: Exception) {}
        }.start()
    }

    /** Ajoute les km roulés depuis la dernière fois au total du jour. */
    private fun flushService() {
        val j = jour.format(Date())
        store.addService(j, pendingM / 1000.0)
        store.addPerso(j, pendingPersoM / 1000.0)
        pendingM = 0.0; pendingPersoM = 0.0
    }

    // ================================================================ Capture

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data) ?: run { stopSelf(); return }
        projection = mp
        val thread = HandlerThread("capture").also { it.start() }
        bgThread = thread
        val bg = Handler(thread.looper)

        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, bg)

        val (w, h, dpi) = screenSize()
        val ir = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        // On garde seulement la dernière image de l'écran, prête pour le toucher.
        ir.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            synchronized(lock) { latest?.close(); latest = img }
        }, bg)
        reader = ir
        display = mp.createVirtualDisplay(
            "bonnecourse", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, bg
        )
    }

    /** Taille de capture : l'écran réel, réduit à 1080 px de large au maximum. */
    private fun screenSize(): Triple<Int, Int, Int> {
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width(); h = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels; h = dm.heightPixels
        }
        val k = min(1.0, 1080.0 / w)
        return Triple((w * k).toInt(), (h * k).toInt(), (resources.displayMetrics.densityDpi * k).toInt())
    }

    private fun grabBitmap(): Bitmap? = synchronized(lock) {
        val img = latest ?: return null
        try {
            val plane = img.planes[0]
            val buf = plane.buffer.duplicate().apply { rewind() }
            val ps = plane.pixelStride
            val rowPad = plane.rowStride - ps * img.width
            val full = Bitmap.createBitmap(img.width + rowPad / ps, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(buf)
            if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        } catch (e: Exception) { null }
    }

    private fun releaseCapture() {
        display?.release(); display = null
        synchronized(lock) { latest?.close(); latest = null }
        reader?.close(); reader = null
        projection?.stop(); projection = null
        bgThread?.quitSafely(); bgThread = null
    }

    // ================================================================ Bulle

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        if (bubble != null) return
        val size = Ui.dp(this, 58)
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(Ui.SURFACE); setStroke(Ui.dp(this@BubbleService, 3), Ui.ACCENT)
        }
        bubbleRing = ring
        val v = FrameLayout(this).apply {
            background = ring
            elevation = Ui.dp(this@BubbleService, 6).toFloat()
            addView(ImageView(this@BubbleService).apply { setImageResource(R.drawable.ic_launcher_fg) },
                FrameLayout.LayoutParams(size, size))
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - Ui.dp(this@BubbleService, 8)
            y = resources.displayMetrics.heightPixels / 3
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false; var longDone = false
        val longPress = Runnable { if (!moved) { longDone = true; vibrateShort(); openMenu() } }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY; moved = false; longDone = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                    main.postDelayed(longPress, 600)   // appui long = menu (client privé, trajet perso)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) { moved = true; main.removeCallbacks(longPress) }
                    if (moved) { lp.x = startX + dx; lp.y = startY + dy; wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    main.removeCallbacks(longPress)
                    if (!moved && !longDone && e.action == MotionEvent.ACTION_UP) onBubbleTap()
                }
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    /** Couleur de l'anneau : bleu = en attente, orange = approche, vert = client à bord. */
    /** Anneau : bleu = en service, orange = approche, vert = client à bord, gris = trajet perso. */
    private fun updateBubbleLook() {
        val c = when {
            perso -> Ui.MUTED
            tracker.phase == Phase.APPROCHE -> Ui.WARN
            tracker.phase == Phase.COURSE -> Ui.GO
            segType != null -> Ui.FG          // trajet domicile en cours : anneau blanc
            else -> Ui.ACCENT
        }
        bubbleRing?.setStroke(Ui.dp(this, if (tracker.phase == Phase.AUCUNE && segType == null) 3 else 5), c)
        bubble?.alpha = if (perso) 0.6f else 1f
    }

    private fun onBubbleTap() {
        if (perso) { openMenu(); return }
        if (tracker.phase != Phase.AUCUNE && !ridePanelOpen) { openRidePanel(); return }
        analyse()
    }

    /** Menu de l'appui long : course client privé, trajet perso / reprise du service. */
    private fun openMenu() {
        flushService()
        showTile(Tile.menu(this, perso, tracker.phase != Phase.AUCUNE, segType,
            onDomicile = {
                removeTile()
                when {
                    segType != null -> finirSegment(true)
                    store.domicile == null -> showError("Enregistre d'abord ton domicile : Bonne Course → Réglages → Mon domicile.")
                    else -> demarrerSegment(Segment.RETOUR)
                }
            },
            onDepart = { removeTile(); demarrerSegment(Segment.DEPART) },
            onPrive = {
                removeTile()
                commencer(0.0, "prive", null)   // montant, client et signature à l'arrivée
                updateBubbleLook(); openRidePanel()
            },
            onPerso = {
                flushService(); perso = true; store.modePerso = true
                updateBubbleLook(); removeTile()
            },
            onService = {
                flushService(); perso = false; store.modePerso = false
                updateBubbleLook(); removeTile()
            },
            onClose = { removeTile() }
        ), autoClose = false, tapToClose = false)
    }

    private fun vibrateShort() {
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        try { vib.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
    }

    private fun analyse() {
        if (projection == null) {
            showError("La lecture des offres n'est pas lancée. Ouvre Bonne Course et touche « Lancer la bulle ».")
            return
        }
        if (busy) return
        busy = true
        removeTile()
        val b = bubble ?: return
        b.visibility = View.INVISIBLE          // la bulle ne doit pas cacher l'offre sur la capture
        main.postDelayed({
            val bmp = grabBitmap()
            b.visibility = View.VISIBLE
            b.alpha = 0.5f                     // bulle grisée = analyse en cours
            if (bmp == null) { done(); showError("Capture d'écran impossible"); return@postDelayed }
            Reader.analyse(bmp, store) { result, err, texte, id ->
                done()
                val plat = Plateforme.detecter(texte)?.also { store.dernierePlateforme = it } ?: store.dernierePlateforme
                if (result != null) showResult(result, id, plat) else showError(err ?: "Lecture impossible")
            }
        }, 350)
    }

    private fun done() { busy = false; bubble?.alpha = 1f }

    // ================================================================ Tuiles

    private fun showResult(r: Result, id: Long, plateforme: String) {
        vibrate(r.verdict)
        val m = Meta(plateforme, r.verdict.name, r.score, r.offer.approcheKm + r.offer.courseKm, r.offer.approcheMin + r.offer.courseMin)
        showTile(Tile.build(this, r, store.profile, { removeTile() },
            onAccept = { store.decide(id, "acc"); accept(r.offer.prix, m) },
            onRefuse = { store.decide(id, "ref"); removeTile() }
        ), autoClose = true, tapToClose = true)
    }

    private fun showError(msg: String) = showTile(Tile.error(this, msg) { removeTile() }, autoClose = true, tapToClose = true)

    private fun showTile(view: View, autoClose: Boolean, tapToClose: Boolean) {
        removeTile()
        val m = Ui.dp(this, 12)
        val wrap = FrameLayout(this).apply {
            setPadding(m, 0, m, 0)
            addView(view)
            if (tapToClose) setOnClickListener { removeTile() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP; y = Ui.dp(this@BubbleService, 40) }
        wm.addView(wrap, lp)
        tileWrap = wrap
        main.removeCallbacks(closeTile)
        if (autoClose) main.postDelayed(closeTile, TILE_MS)
    }

    private fun removeTile() {
        main.removeCallbacks(closeTile)
        ridePanelOpen = false
        panelPhase = null; panelUpdate = null
        main.removeCallbacks(tick)
        tileWrap?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tileWrap = null
    }

    // ================================================================ Course en cours

    private fun accept(prix: Double, m: Meta) {
        removeTile()
        if (tracker.phase == Phase.AUCUNE) {
            commencer(prix, "plateforme", m)
            updateBubbleLook()
            openRidePanel()
        } else {
            nextPrice = prix; nextMeta = m   // course enchaînée : son approche démarrera à la fin de celle-ci
        }
    }

    private fun openRidePanel() {
        ridePanelOpen = false
        showTile(FrameLayout(this), autoClose = false, tapToClose = false)
        ridePanelOpen = true
        drawRidePanel()
        main.postDelayed(tick, 1000)
    }

    private var panelPhase: Phase? = null
    private var panelUpdate: ((Double, Double) -> Unit)? = null

    /** Construit le panneau quand la phase change, sinon met juste à jour le chrono et les km. */
    private fun drawRidePanel() {
        val wrap = tileWrap ?: return
        if (panelPhase != tracker.phase || panelUpdate == null || wrap.childCount == 0) {
            val (panel, update) = Tile.ride(this, tracker.phase, gps, tracker.typeEnCours == "prive",
                onNext = { nextStep() },
                onAnalyse = { removeTile(); analyse() },
                onCancel = { tracker.annuler(); nextPrice = null; nextMeta = null; trace.clear(); meta = null; updateBubbleLook(); removeTile() },
                onClose = { removeTile() }
            )
            wrap.removeAllViews()
            wrap.addView(panel)
            panelPhase = tracker.phase
            panelUpdate = update
        }
        val (minutes, km) = tracker.compteur()
        panelUpdate?.invoke(minutes, km)
    }

    private fun nextStep() {
        when (tracker.phase) {
            Phase.APPROCHE -> { tracker.clientABord(); updateBubbleLook(); drawRidePanel() }
            Phase.COURSE -> {
                val ride = completer(tracker.terminer() ?: return)
                flushService()
                saveRide(ride, ArrayList(trace))
                val next = nextPrice
                val nm = nextMeta
                nextPrice = null; nextMeta = null
                if (next != null) commencer(next, "plateforme", nm) else { trace.clear(); meta = null }
                updateBubbleLook()
                showTile(Tile.saved(this, ride), autoClose = true, tapToClose = true)
                main.removeCallbacks(closeTile); main.postDelayed(closeTile, 5000)
            }
            Phase.AUCUNE -> removeTile()
        }
    }

    /** Ajoute à la course ce que disait l'offre (plateforme, verdict, km et minutes annoncés). */
    private fun completer(r: Ride): Ride {
        val m = meta ?: return r
        return r.copy(plateforme = m.plateforme, verdict = m.verdict, score = m.score, offreKm = m.km, offreMin = m.min)
    }

    /**
     * Boîte noire : enregistre la course, son tracé GPS et le nom des rues et des villes, en arrière-plan.
     * Course privée : ouvre ensuite l'écran de signature et de facture.
     */
    private fun saveRide(ride: Ride, points: List<Point>) {
        store.addRide(ride)               // tout de suite : rien n'est perdu si le téléphone s'éteint
        store.saveTrace(ride.debut, points)
        Thread {
            val r = try {
                ride.copy(lieuDepart = lieu(ride.lieuDepart), lieuPrise = lieu(ride.lieuPrise), lieuArrivee = lieu(ride.lieuArrivee))
            } catch (_: Exception) { ride }
            store.addRide(r)
            if (r.prive) main.post {
                try {
                    startActivity(Intent(this, FactureActivity::class.java)
                        .putExtra(FactureActivity.EXTRA_COURSE, r.debut)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }
        }.start()
    }

    /** "48.98712,2.44831" → "Avenue Pierre Salvi, Gonesse (48.98712,2.44831)". Sans réseau : les coordonnées seules. */
    private fun lieu(coord: String): String {
        if (coord.isEmpty() || !Geocoder.isPresent()) return coord
        return try {
            val (la, lo) = coord.split(",").map { it.toDouble() }
            @Suppress("DEPRECATION")
            val a = Geocoder(this, Locale.FRANCE).getFromLocation(la, lo, 1)?.firstOrNull() ?: return coord
            val nom = listOfNotNull(a.thoroughfare, a.locality ?: a.subAdminArea).joinToString(", ")
            if (nom.isBlank()) coord else "$nom ($coord)"
        } catch (_: Exception) { coord }
    }

    private fun vibrate(v: Verdict) {
        val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        val pattern = when (v) {
            Verdict.ACCEPTER -> longArrayOf(0, 60)
            Verdict.A_VOIR -> longArrayOf(0, 60, 120, 60)
            Verdict.REFUSER -> longArrayOf(0, 250)
        }
        try { vib.vibrate(VibrationEffect.createWaveform(pattern, -1)) } catch (_: Exception) {}
    }

    // ================================================================ Notification

    private fun notification(): android.app.Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Bulle active", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("Bonne Course est prête")
            .setContentText(if (hasLocation()) "Bulle active · courses enregistrées avec le GPS" else "Bulle active · GPS non autorisé")
            .setContentIntent(open)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        // Une course en cours est enregistrée telle quelle
        tracker.terminer()?.let { store.addRide(completer(it)); store.saveTrace(it.debut, trace) }
        if (segType != null) finirSegment(true)
        flushService()
        stopGps()
        main.removeCallbacksAndMessages(null)
        removeTile()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        releaseCapture()
        super.onDestroy()
    }
}
