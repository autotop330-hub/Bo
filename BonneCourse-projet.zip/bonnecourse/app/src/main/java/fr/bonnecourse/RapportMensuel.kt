package fr.bonnecourse

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import androidx.appcompat.app.AlertDialog
import java.io.File

/** Rapport mensuel PDF (contrôle fiscal) : assemblage des données, dessin, ouverture ou envoi. */
object RapportMensuel {

    fun fichier(ctx: Context, annee: Int, mois: Int) =
        File(File(ctx.filesDir, "rapports").apply { mkdirs() }, String.format("Releve-mensuel-%04d-%02d.pdf", annee, mois))

    fun donnees(ctx: Context, annee: Int, mois: Int): RapportDonnees {
        val s = Store(ctx)
        return RapportDonnees.assembler(annee, mois, System.currentTimeMillis(), s.entreprise, s.vehicules(), s.vehiculeActif,
            s.rides(), s.service(), s.perso(), s.segments(), s.trajets(), s.releves(), s.frais(), s.minutesService(), s.profile.tva)
    }

    fun creer(ctx: Context, annee: Int, mois: Int): File {
        val d = donnees(ctx, annee, mois)
        val logo = FacturePdf.logo(ctx) ?: BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_facture)
        val doc = PdfDocument()
        try {
            RapportDessin.dessiner(doc, d, logo)
            val f = fichier(ctx, annee, mois)
            f.outputStream().use { doc.writeTo(it) }
            return f
        } finally { doc.close() }
    }

    /** Crée le rapport en arrière-plan puis propose de l'ouvrir ou de l'envoyer. */
    fun lancer(a: MainActivity, annee: Int, mois: Int) {
        a.toast("Préparation du rapport…")
        Thread {
            try {
                val f = creer(a, annee, mois)
                a.runOnUiThread { proposer(a, f, W.nomMois(annee, mois)) }
            } catch (e: Exception) {
                a.runOnUiThread { a.toast("Rapport impossible : ${e.message}") }
            }
        }.start()
    }

    fun proposer(a: MainActivity, f: File, nom: String) {
        AlertDialog.Builder(a).setTitle("Rapport de ${nom.lowercase()} prêt")
            .setMessage("À garder 6 ans. En cas de contrôle, envoie-le avec l'export tableur du mois et les relevés des plateformes " +
                "(messagerie sécurisée de l'espace professionnel impots.gouv.fr, ou par ton comptable).")
            .setPositiveButton("Ouvrir") { _, _ -> FacturePdf.ouvrir(a, f) }
            .setNeutralButton("Envoyer") { _, _ -> envoyer(a, f, nom) }
            .setNegativeButton("Fermer", null).show()
    }

    private fun envoyer(a: MainActivity, f: File, nom: String) {
        val e = a.store.entreprise
        val i = Intent(Intent.ACTION_SEND).setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, FacturePdf.uri(a, f))
            .putExtra(Intent.EXTRA_SUBJECT, "Relevé mensuel d'activité et carnet kilométrique · $nom" +
                if (e.raisonSociale.isNotBlank()) " · ${e.raisonSociale}" else "")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { a.startActivity(Intent.createChooser(i, "Envoyer le rapport")) } catch (_: Exception) { a.toast("Aucune appli pour envoyer le fichier") }
    }
}
