package fr.bonnecourse

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar
import java.util.Locale

/**
 * Relevé du compteur pour un véhicule qui n'envoie pas ses données (Mercedes EQV…) :
 * une photo du tableau de bord, le kilométrage est lu sur la photo (sur le téléphone), on vérifie, c'est enregistré
 * avec la photo comme preuve. Rappel par notification en début et en fin de service.
 */
object Compteur {
    const val EXTRA = "fr.bonnecourse.RELEVE_COMPTEUR"
    private const val CANAL = "releve_compteur"
    private const val NOTIF = 77

    val TYPES = listOf("debut_service" to "Début de service", "fin_service" to "Fin de service", "manuel" to "Autre relevé")

    fun km(x: Double) = String.format(Locale.FRANCE, "%,.0f km", x)

    /** Dernier relevé du véhicule actif. */
    fun dernier(store: Store): Releve? {
        val v = store.vehiculeActif.id
        return store.releves().filter { it.vehicule == v && it.odoKm > 0 }.maxByOrNull { it.t }
    }

    /** Type le plus probable : début de service si la bulle tourne et rien n'est relevé aujourd'hui, fin si le service est fini… */
    fun typeParDefaut(store: Store): String {
        val debutJour = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val v = store.vehiculeActif.id
        val jour = store.releves().filter { it.t >= debutJour && it.vehicule == v }
        val dernierDebut = jour.filter { it.type == "debut_service" }.maxOfOrNull { it.t }
        val derniereFin = jour.filter { it.type == "fin_service" }.maxOfOrNull { it.t } ?: 0L
        return when {
            BubbleService.running && (dernierDebut == null || derniereFin > dernierDebut) -> "debut_service"
            !BubbleService.running && dernierDebut != null && derniereFin < dernierDebut -> "fin_service"
            !BubbleService.running && dernierDebut == null && store.serviceDebut == 0L &&
                store.minutesService()[java.text.SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(java.util.Date())] != null -> "fin_service"
            else -> "manuel"
        }
    }

    /** Notification « Photographie le compteur » (début ou fin de service). */
    fun rappel(ctx: Context, type: String) {
        val store = Store(ctx)
        val v = store.vehiculeActif
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CANAL, "Relevé du compteur", NotificationManager.IMPORTANCE_DEFAULT))
        val i = Intent(ctx, MainActivity::class.java).putExtra(EXTRA, type)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(ctx, 77 + type.length, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val quand = TYPES.find { it.first == type }?.second ?: "Relevé"
        val n = NotificationCompat.Builder(ctx, CANAL)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("📷 Photographie le compteur · $quand")
            .setContentText("${v.court} : 5 secondes pour un carnet kilométrique incontestable.")
            .setContentIntent(pi).setAutoCancel(true)
            .addAction(0, "Prendre la photo", pi)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(NOTIF, n) } catch (_: SecurityException) {}
    }

    fun annulerRappel(ctx: Context) = try { NotificationManagerCompat.from(ctx).cancel(NOTIF) } catch (_: Exception) {}

    /** Photo du tableau de bord → lecture du kilométrage → vérification → enregistrement. */
    fun photographier(a: MainActivity, type: String? = null) {
        annulerRappel(a)
        a.prendrePhoto("compteur") { chemin ->
            if (chemin == null) return@prendrePhoto
            val bmp = BitmapFactory.decodeFile(chemin)
            if (bmp == null) { saisir(a, type, null, chemin, null); return@prendrePhoto }
            a.toast("Lecture du compteur…")
            Reader.read(bmp) { texte, _ ->
                val dern = dernier(a.store)?.odoKm
                val km = texte?.let { LectureCompteur.extraire(it, dern) }
                a.runOnUiThread { saisir(a, type, km, chemin, texte) }
            }
        }
    }

    /** Fenêtre de vérification (aussi pour une saisie à la main, sans photo). */
    fun saisir(a: MainActivity, type: String?, kmLu: Double?, photo: String?, texte: String?) {
        val store = a.store
        val v = store.vehiculeActif
        val dern = dernier(store)
        val col = Ui.vertical(a, 10).apply { val p = Ui.dp(a, 20); setPadding(p, p, p, p); setBackgroundColor(Ui.BG) }
        col.addView(Ui.text(a, "Compteur · ${v.court}", 20f, Ui.FG, true))
        if (photo != null) col.addView(ImageView(a).apply {
            setImageBitmap(BitmapFactory.decodeFile(photo)); adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_CROP
            background = Ui.box(a, Ui.RAISE, Ui.LINE, 1, 14); clipToOutline = true
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(a, 170)))
        col.addView(W.aide(a, when {
            photo == null -> "Tape le kilométrage total affiché au tableau de bord."
            kmLu != null -> "Lu sur la photo : ${km(kmLu)}. Vérifie le chiffre avant d'enregistrer."
            else -> "Le chiffre n'a pas pu être lu (reflet, flou ?) : tape-le, la photo reste jointe comme preuve."
        }))
        val eKm = W.champ(a, col, "Kilométrage total (km)", kmLu?.let { W.n(it) } ?: "", W.NOMBRE, dern?.let { "dernier : ${km(it.odoKm)}" } ?: "ex. 12345")
        val eBat = W.champ(a, col, "Batterie (%) · facultatif, sert à mesurer la consommation", "", W.NOMBRE, "ex. 80")
        col.addView(Ui.text(a, "Moment du relevé", 13f, Ui.MUTED))
        val choix = type ?: typeParDefaut(store)
        val sp = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, TYPES.map { it.second })
            setSelection(TYPES.indexOfFirst { it.first == choix }.coerceAtLeast(0))
        }
        col.addView(sp)
        if (dern != null) col.addView(W.aide(a, "Dernier relevé : ${km(dern.odoKm)} le " +
            java.text.SimpleDateFormat("dd/MM à HH:mm", Locale.FRANCE).format(java.util.Date(dern.t)) + " (${dern.source})"))
        val d = AlertDialog.Builder(a).setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton("Enregistrer") { _, _ ->
                val k = W.nombre(eKm)
                if (k == null || k <= 0) { a.toast("Kilométrage manquant : rien n'est enregistré"); photo?.let { java.io.File(it).delete() }; return@setPositiveButton }
                val bat = W.nombre(eBat)?.takeIf { it in 0.0..100.0 } ?: -1.0
                val t = TYPES[sp.selectedItemPosition.coerceIn(0, TYPES.size - 1)].first
                val enregistrer = { enregistrer(a, k, bat, t, photo) }
                if (dern != null && k < dern.odoKm - 0.5)
                    W.confirmer(a, "Inférieur au dernier relevé", "Le compteur ne recule jamais : ${km(k)} < ${km(dern.odoKm)}. Enregistrer quand même ?",
                        "Enregistrer") { enregistrer() }
                else if (dern != null && k - dern.odoKm > 2500)
                    W.confirmer(a, "Gros écart", "${km(k - dern.odoKm)} depuis le dernier relevé. Le chiffre est-il bon ?", "Oui, enregistrer") { enregistrer() }
                else enregistrer()
            }
            .setNegativeButton("Annuler") { _, _ -> photo?.let { java.io.File(it).delete() } }
        if (photo != null) d.setNeutralButton("Reprendre la photo") { _, _ -> java.io.File(photo).delete(); photographier(a, type) }
        d.show()
        if (texte != null && kmLu == null && texte.isBlank()) a.toast("Rien de lisible sur la photo")
    }

    private fun enregistrer(a: MainActivity, km: Double, bat: Double, type: String, photo: String?) {
        val store = a.store
        store.addReleve(Releve(System.currentTimeMillis(), type, km, bat, -1.0, 0.0, 0.0, 0L,
            if (photo != null) "photo du tableau de bord" else "saisi à la main", photo ?: "", store.vehiculeActif.id))
        if (type == "fin_service") TeslaAuto.appliquerConso(store)
        a.toast("Compteur enregistré : ${km(km)}")
        a.afficher()
    }
}
