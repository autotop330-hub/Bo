package fr.bonnecourse

import org.json.JSONArray
import org.json.JSONObject

/**
 * Un véhicule de l'activité (on peut en avoir plusieurs et changer de véhicule à tout moment).
 * Le véhicule actif fixe la consommation utilisée pour juger les offres, la batterie,
 * et la façon de relever le compteur : en direct par la voiture (Tesla via Teslemetry) ou en photo du tableau de bord.
 */
data class Vehicule(
    val id: String,
    val modele: String,
    val immat: String = "",
    val batterieKwh: Double = 75.0,     // capacité utile
    val conso: Double = 16.0,           // kWh/100 km en VTC (ville, clim, pertes de recharge comprises)
    val places: Int = 5,
    val cv: Int = 7,                    // puissance fiscale (carte grise, case P.6)
    val connexion: String = PHOTO,      // TESLA = compteur envoyé par la voiture ; PHOTO = photo du compteur
    val statut: String = "Loué à la SASU"
) {
    val connectee get() = connexion == TESLA
    /** « Tesla Model Y » / « Mercedes EQV » : nom court pour l'écran. */
    val court get() = modele.split(" ").take(3).joinToString(" ").removeSuffix(" Grande").removeSuffix(" 300")
    val libelle get() = modele + if (immat.isNotBlank()) " · $immat" else ""

    fun json(): JSONObject = JSONObject().put("id", id).put("modele", modele).put("immat", immat).put("bat", batterieKwh)
        .put("conso", conso).put("places", places).put("cv", cv).put("cx", connexion).put("statut", statut)

    companion object {
        const val TESLA = "tesla"
        const val PHOTO = "photo"

        fun de(o: JSONObject) = Vehicule(o.getString("id"), o.optString("modele", "Véhicule"), o.optString("immat", ""),
            o.optDouble("bat", 75.0), o.optDouble("conso", 16.0), o.optInt("places", 5), o.optInt("cv", 7),
            o.optString("cx", PHOTO), o.optString("statut", "Loué à la SASU"))

        fun liste(s: String?): List<Vehicule> = try {
            val a = JSONArray(s ?: "[]"); (0 until a.length()).map { de(a.getJSONObject(it)) }
        } catch (_: Exception) { emptyList() }

        fun texte(l: List<Vehicule>) = JSONArray().apply { l.forEach { put(it.json()) } }.toString()
    }
}

/**
 * Modèles prêts à l'emploi : valeurs constructeur, consommation réaliste en VTC (à affiner : l'appli la mesure ensuite).
 *  - Tesla Model Y Grande Autonomie Propulsion : ≈ 75 kWh utiles, ≈ 16 kWh/100 km en ville.
 *  - Mercedes EQV 300 : 90 kWh, 28,1 kWh/100 km en cycle WLTP mixte, 355 km d'autonomie WLTP (version L2), 6 à 8 places.
 */
object Modeles {
    data class Modele(val nom: String, val batterie: Double, val conso: Double, val places: Int, val cv: Int, val connexion: String, val note: String)

    val LISTE = listOf(
        Modele("Tesla Model Y Grande Autonomie Propulsion", 75.0, 16.0, 5, 7, Vehicule.TESLA,
            "Compteur et batterie envoyés par la voiture (Teslemetry)"),
        Modele("Mercedes EQV 300", 90.0, 28.0, 7, 7, Vehicule.PHOTO,
            "Van 7 places · compteur relevé en photo du tableau de bord"),
        Modele("Autre véhicule électrique", 60.0, 18.0, 5, 7, Vehicule.PHOTO,
            "Valeurs à ajuster · compteur relevé en photo")
    )

    fun creer(m: Modele, immat: String = "") = Vehicule("v${System.currentTimeMillis()}", m.nom, immat.trim().uppercase(),
        m.batterie, m.conso, m.places, m.cv, m.connexion)
}
