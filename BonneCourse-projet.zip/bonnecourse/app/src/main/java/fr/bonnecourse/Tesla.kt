package fr.bonnecourse

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Lien avec la Tesla par Teslemetry (même jeton que l'appli Fluide).
 *
 * Lecture du dernier état envoyé par la voiture (Fleet Telemetry) : la voiture n'est jamais réveillée.
 * Tesla envoie les distances en miles : tout est converti en km ici.
 */
object Tesla {
    private const val API = "https://api.teslemetry.com"
    const val MILE = 1.609344

    /** Champs suivis et fréquence d'envoi par la voiture (secondes). */
    private val CHAMPS = linkedMapOf(
        "Odometer" to 30, "BatteryLevel" to 60, "EstBatteryRange" to 60, "DetailedChargeState" to 30,
        "FastChargerPresent" to 60, "Gear" to 10, "Location" to 30, "NominalFullPackEnergyKwh" to 3600
    )
    /** Compteurs d'énergie (logiciel Tesla récent) : ajoutés à part, ignorés si la voiture ne les connaît pas. */
    private val CHAMPS_ENERGIE = linkedMapOf("LifetimeEnergyChargedKwh" to 300, "LifetimeDcChargeEnergyKwh" to 300)

    /** Dernier état connu de la voiture. Les valeurs absentes sont null. */
    data class Etat(
        val lu: Long,                 // heure de la lecture par l'appli
        val maj: Long,                // heure du relevé du compteur par la voiture
        val odoKm: Double?,
        val batterie: Double?,        // %
        val autonomieKm: Double?,
        val charge: String?,          // Charging, Complete, Disconnected, Stopped…
        val rapide: Boolean?,         // borne rapide branchée (Superchargeur)
        val rapport: String?,         // P, R, N, D
        val lat: Double?, val lon: Double?,
        val capaciteKwh: Double?,
        val chargeTotaleKwh: Double?, // énergie rechargée depuis la sortie d'usine
        val chargeDcKwh: Double?      // dont en charge rapide
    ) {
        val enCharge get() = charge == "Charging" || charge == "Starting"
        val roule get() = rapport == "D" || rapport == "R"
        fun json(): String = JSONObject().put("lu", lu).put("maj", maj).put("odo", odoKm ?: JSONObject.NULL)
            .put("bat", batterie ?: JSONObject.NULL).put("aut", autonomieKm ?: JSONObject.NULL).put("ch", charge ?: JSONObject.NULL)
            .put("rap", rapide ?: JSONObject.NULL).put("gear", rapport ?: JSONObject.NULL).put("lat", lat ?: JSONObject.NULL)
            .put("lon", lon ?: JSONObject.NULL).put("cap", capaciteKwh ?: JSONObject.NULL).put("ctot", chargeTotaleKwh ?: JSONObject.NULL)
            .put("cdc", chargeDcKwh ?: JSONObject.NULL).toString()

        companion object {
            fun de(s: String?): Etat? = try {
                if (s.isNullOrBlank()) null else JSONObject(s).let { o ->
                    fun d(k: String) = if (o.isNull(k)) null else o.optDouble(k).takeIf { !it.isNaN() }
                    Etat(o.getLong("lu"), o.optLong("maj", o.getLong("lu")), d("odo"), d("bat"), d("aut"),
                        if (o.isNull("ch")) null else o.optString("ch"), if (o.isNull("rap")) null else o.optBoolean("rap"),
                        if (o.isNull("gear")) null else o.optString("gear"), d("lat"), d("lon"), d("cap"), d("ctot"), d("cdc"))
                }
            } catch (_: Exception) { null }
        }
    }

    private fun requete(methode: String, chemin: String, jeton: String, corps: String? = null): JSONObject? = try {
        val c = URL(API + chemin).openConnection() as HttpURLConnection
        c.requestMethod = methode
        c.connectTimeout = 6000; c.readTimeout = 10000
        c.setRequestProperty("Authorization", "Bearer ${jeton.trim()}")
        c.setRequestProperty("User-Agent", "BonneCourse/2 (Android)")
        if (corps != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(corps.toByteArray()) }
        }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (ok) JSONObject(txt.ifBlank { "{}" }) else JSONObject().put("erreur", c.responseCode).put("texte", txt.take(300))
    } catch (e: Exception) { JSONObject().put("erreur", -1).put("texte", e.message ?: "réseau") }

    /** Véhicules du compte : (VIN, nom). null si le jeton est refusé ou pas de réseau. */
    fun vehicules(jeton: String): List<Pair<String, String>>? {
        val r = requete("GET", "/api/1/vehicles", jeton) ?: return null
        if (r.has("erreur")) return null
        val arr = r.optJSONArray("response") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val v = arr.optJSONObject(i) ?: return@mapNotNull null
            val vin = v.optString("vin").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            vin to v.optString("display_name").ifBlank { "Tesla" }
        }
    }

    /**
     * Demande à la voiture d'envoyer les champs utiles. Ne touche pas aux champs déjà réglés
     * (par exemple la position réglée par Fluide). Renvoie un message d'erreur, ou null si tout va bien.
     */
    fun configurer(jeton: String, vin: String): String? {
        val rep = requete("GET", "/api/config/$vin", jeton)
        val actuelLu = rep != null && !rep.has("erreur")
        val actuel = rep?.optJSONObject("fields") ?: JSONObject()
        fun envoyer(champs: Map<String, Int>): String? {
            val manquants = champs.filterKeys { !actuel.has(it) }
            if (manquants.isEmpty()) return null
            val f = JSONObject().apply { manquants.forEach { (k, s) -> put(k, JSONObject().put("interval_seconds", s)) } }
            var r = requete("PATCH", "/api/config/$vin", jeton, JSONObject().put("fields", f).toString())
            if (r != null && r.optInt("erreur") == -1 && actuelLu && r.optString("texte").contains("PATCH", true)) {
                // Téléphone sans PATCH : on renvoie la configuration complète (champs existants + nouveaux)
                val tout = JSONObject(actuel.toString()).apply { manquants.forEach { (k, s) -> put(k, JSONObject().put("interval_seconds", s)) } }
                r = requete("POST", "/api/config/$vin", jeton, JSONObject().put("fields", tout).toString())
            }
            return when {
                r == null -> "pas de réseau"
                r.has("erreur") -> "refusé (${r.optInt("erreur")}) ${r.optString("texte")}"
                r.has("error") -> r.optString("error_description", r.optString("error"))
                else -> null
            }
        }
        val e = envoyer(CHAMPS)
        envoyer(CHAMPS_ENERGIE)   // facultatif
        return e
    }

    private val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    private fun date(s: String?): Long? = try { if (s.isNullOrBlank()) null else iso.parse(s.take(19))?.time } catch (_: Exception) { null }

    /** Lit le dernier état envoyé par la voiture (sans la réveiller). */
    fun lire(jeton: String, vin: String): Etat? {
        val champs = (CHAMPS.keys + CHAMPS_ENERGIE.keys).joinToString(";")
        val r = requete("GET", "/api/1/vehicles/$vin/telemetry?fields=" + URLEncoder.encode(champs, "UTF-8"), jeton) ?: return null
        if (r.has("erreur")) return null
        return analyser(r)
    }

    /** Réponse de /telemetry → état de la voiture (séparé pour pouvoir être testé). */
    fun analyser(r: JSONObject): Etat? {
        val data = r.optJSONObject("response")?.optJSONObject("data") ?: return null
        fun champ(k: String) = data.optJSONObject(k)
        fun nombre(k: String): Double? {
            val c = champ(k) ?: return null
            if (c.isNull("value")) return null
            val v = c.opt("value")
            return when (v) { is Number -> v.toDouble(); is String -> v.toDoubleOrNull(); else -> null }
        }
        fun texte(k: String, prefixe: String) = champ(k)?.takeIf { !it.isNull("value") }?.optString("value")?.removePrefix(prefixe)
        fun km(k: String): Double? {
            val v = nombre(k) ?: return null
            val u = champ(k)?.optString("unit", "mi") ?: "mi"
            return if (u.startsWith("km")) v else v * MILE
        }
        val pos = champ("Location")?.optJSONObject("value")
        val maj = date(champ("Odometer")?.optString("createdAt")) ?: System.currentTimeMillis()
        return Etat(
            lu = System.currentTimeMillis(), maj = maj,
            odoKm = km("Odometer"), batterie = nombre("BatteryLevel"), autonomieKm = km("EstBatteryRange"),
            charge = texte("DetailedChargeState", "DetailedChargeState"),
            rapide = champ("FastChargerPresent")?.takeIf { !it.isNull("value") }?.opt("value")?.let { it == true || it.toString() == "true" },
            rapport = texte("Gear", "ShiftState"),
            lat = pos?.optDouble("latitude")?.takeIf { !it.isNaN() }, lon = pos?.optDouble("longitude")?.takeIf { !it.isNaN() },
            capaciteKwh = nombre("NominalFullPackEnergyKwh"),
            chargeTotaleKwh = nombre("LifetimeEnergyChargedKwh"), chargeDcKwh = nombre("LifetimeDcChargeEnergyKwh")
        )
    }
}
