package fr.bonnecourse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Calendar

/**
 * L'appli en 5 onglets :
 *  Rouler  · la bulle, la journée, les courses privées
 *  Courses · la boîte noire (chaque course, horodatée, avec son tracé GPS)
 *  Frais   · recharge, repas, assurance, abonnements…
 *  Mon mois· graphiques, net dans la poche, te payer au mieux, exports
 *  Réglages· société (factures), voiture, impôts
 */
class MainActivity : AppCompatActivity() {

    lateinit var store: Store
    private lateinit var contenu: FrameLayout
    private lateinit var barre: LinearLayout
    private var onglet = 0
    private val ONGLETS = listOf("Rouler", "Courses", "Frais", "Mon mois", "Réglages")

    // Mois affiché (commun à tous les onglets)
    var vueAnnee = Calendar.getInstance().get(Calendar.YEAR)
    var vueMois = Calendar.getInstance().get(Calendar.MONTH) + 1
    var filtreSource = "Toutes"

    // ---------------------------------------------------------------- Autorisations et lancements

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            startForegroundService(Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_START)
                .putExtra(BubbleService.EXTRA_CODE, res.resultCode).putExtra(BubbleService.EXTRA_DATA, res.data))
            contenu.postDelayed({ afficher() }, 600)
            Toast.makeText(this, "Bulle lancée. Ouvre Uber ou Bolt, elle reste à l'écran.", Toast.LENGTH_LONG).show()
        } else Toast.makeText(this, "Sans l'autorisation de capture, la bulle ne peut pas lire l'offre.", Toast.LENGTH_LONG).show()
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askLocation() }

    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] != true)
            Toast.makeText(this, "Sans la position précise, les km et le tracé ne seront pas enregistrés.", Toast.LENGTH_LONG).show()
        askProjection()
    }

    private val privePermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (aLaPosition()) lancerPrivee()
        else Toast.makeText(this, "La position précise est nécessaire pour enregistrer la course.", Toast.LENGTH_LONG).show()
    }

    private val autoPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Build.VERSION.SDK_INT >= 29 && !AutoDetection.autorise(this) && aLaPosition()) {
            Toast.makeText(this, "Choisis « Toujours autoriser » pour la position, sinon les trajets ne seront pas détectés.", Toast.LENGTH_LONG).show()
            bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else finirActivationAuto()
    }
    private val bgLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { finirActivationAuto() }

    private val importLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        val texte = try { contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } } catch (_: Exception) { null }
        if (texte == null) Toast.makeText(this, "Fichier illisible", Toast.LENGTH_LONG).show()
        else EcranMois(this).afficherRapprochement(texte)
    }

    private var exportContenu: () -> String = { "" }
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(exportContenu().toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Fichier enregistré", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Enregistrement impossible : ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bmp == null) { Toast.makeText(this, "Image illisible", Toast.LENGTH_SHORT).show(); return@registerForActivityResult }
        Reader.analyse(bmp, store) { r, err, raw, _ ->
            val col = Ui.vertical(this, 8).apply { val p = Ui.dp(this@MainActivity, 16); setPadding(p, p, p, p); setBackgroundColor(Ui.BG) }
            col.addView(if (r != null) Tile.build(this, r, store.profile, null) else Tile.error(this, err ?: "Erreur", null))
            Plateforme.detecter(raw)?.let { col.addView(W.aide(this, "Plateforme reconnue : $it")) }
            col.addView(W.aide(this, "Texte lu sur l'image :"))
            col.addView(Ui.text(this, raw.ifBlank { "(rien)" }, 12f, Ui.MUTED).apply { setTextIsSelectable(true) })
            AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(col) }).setPositiveButton("Fermer", null).show()
        }
    }

    private val logoLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        try {
            val b = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: throw Exception("image illisible")
            val k = minOf(1f, 800f / maxOf(b.width, b.height))
            val r = Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true)
            FacturePdf.fichierLogo(this).outputStream().use { r.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Logo enregistré : il sera sur les prochaines factures", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Logo impossible : ${e.message}", Toast.LENGTH_LONG).show() }
        afficher()
    }

    fun choisirLogo() = logoLauncher.launch("image/*")

    private var photoFichier: File? = null
    private var photoRetour: ((String?) -> Unit)? = null
    private val photoLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = photoFichier
        val chemin = if (ok && f != null && f.exists()) { reduire(f); f.absolutePath } else { f?.delete(); null }
        photoRetour?.invoke(chemin)
        photoRetour = null
    }

    // ---------------------------------------------------------------- Cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        onglet = savedInstanceState?.getInt("onglet", 0) ?: 0
        contenu = FrameLayout(this)
        barre = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.SURFACE)
            val p = Ui.dp(this@MainActivity, 4); setPadding(p, p, p, p)
        }
        ONGLETS.forEachIndexed { i, nom ->
            barre.addView(Ui.text(this, nom, 13f, Ui.MUTED, true).apply {
                gravity = Gravity.CENTER
                val p = Ui.dp(this@MainActivity, 10); setPadding(0, p, 0, p)
                setOnClickListener { onglet = i; afficher() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val racine = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG)
            addView(contenu, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(barre, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(racine)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("onglet", onglet)
    }

    override fun onResume() {
        super.onResume()
        if (store.autoTrajets) AutoDetection.activer(this)
        afficher()
    }

    /** Redessine l'onglet en cours (après chaque changement). */
    fun afficher() {
        val col = Ui.vertical(this, 14).apply { val p = Ui.dp(this@MainActivity, 16); setPadding(p, p, p, p * 2) }
        try {
            when (onglet) {
                0 -> EcranRouler(this).remplir(col)
                1 -> EcranCourses(this).remplir(col)
                2 -> EcranFrais(this).remplir(col)
                3 -> EcranMois(this).remplir(col)
                else -> EcranReglages(this).remplir(col)
            }
        } catch (e: Exception) {
            col.addView(Ui.text(this, "Erreur d'affichage : ${e.message}", 14f, Ui.STOP))
        }
        contenu.removeAllViews()
        contenu.addView(ScrollView(this).apply { addView(col) })
        for (i in 0 until barre.childCount) (barre.getChildAt(i) as android.widget.TextView).apply {
            setTextColor(if (i == onglet) Ui.ACCENT else Ui.MUTED)
            background = if (i == onglet) Ui.box(this@MainActivity, Ui.RAISE, Ui.RAISE, 0, 10) else null
        }
    }

    fun ouvrirOnglet(i: Int) { onglet = i; afficher() }

    // ---------------------------------------------------------------- Mois affiché

    fun changeMois(d: Int) {
        vueMois += d
        if (vueMois < 1) { vueMois = 12; vueAnnee-- }
        if (vueMois > 12) { vueMois = 1; vueAnnee++ }
        afficher()
    }

    fun allerAuMois(annee: Int, mois: Int) { vueAnnee = annee; vueMois = mois; afficher() }

    fun navMois() = W.navMois(this, W.nomMois(vueAnnee, vueMois), { changeMois(-1) }, { changeMois(1) })

    /** Mois écoulés de l'année affichée (pour projeter sur 12 mois). */
    fun moisEcoules(): Double {
        val now = Calendar.getInstance()
        val a = now.get(Calendar.YEAR)
        return when {
            vueAnnee < a -> 12.0
            vueAnnee > a -> 0.0
            else -> now.get(Calendar.MONTH) + now.get(Calendar.DAY_OF_MONTH).toDouble() / now.getActualMaximum(Calendar.DAY_OF_MONTH)
        }
    }

    fun duMois(t: Long, annee: Int = vueAnnee, mois: Int = vueMois): Boolean {
        val c = Calendar.getInstance(); c.timeInMillis = t
        return c.get(Calendar.YEAR) == annee && c.get(Calendar.MONTH) + 1 == mois
    }

    // ---------------------------------------------------------------- Bulle

    fun peutAfficherBulle() = Settings.canDrawOverlays(this)

    fun autoriserBulle() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    fun lancerBulle() {
        if (!peutAfficherBulle()) { autoriserBulle(); return }
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else askLocation()
    }

    fun arreterBulle() {
        startService(Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_STOP))
        contenu.postDelayed({ afficher() }, 400)
    }

    private fun askLocation() = locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    fun aLaPosition() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Course privée suivie au GPS : la bulle apparaît (approche → client à bord → terminée), puis signature et facture. */
    fun demarrerPrivee() {
        if (!peutAfficherBulle()) {
            Toast.makeText(this, "Autorise d'abord Bonne Course à s'afficher par-dessus les applis.", Toast.LENGTH_LONG).show()
            autoriserBulle(); return
        }
        if (BubbleService.running && aLaPosition()) { lancerPrivee(); return }
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        privePermLauncher.launch(perms.toTypedArray())
    }

    private fun lancerPrivee() {
        val i = Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_PRIVE)
        if (BubbleService.running) startService(i) else startForegroundService(i)
        Toast.makeText(this, "Course privée lancée. Touche la bulle : client à bord, puis course terminée.", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)
    }

    // ---------------------------------------------------------------- Détection automatique

    fun basculerAuto(on: Boolean) {
        if (!on) {
            store.autoTrajets = false
            AutoDetection.desactiver(this)
            Toast.makeText(this, "Détection automatique arrêtée", Toast.LENGTH_SHORT).show()
            return
        }
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 29) perms += Manifest.permission.ACTIVITY_RECOGNITION
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        autoPermLauncher.launch(perms.toTypedArray())
    }

    private fun finirActivationAuto() {
        val ok = AutoDetection.autorise(this)
        store.autoTrajets = ok
        if (ok) {
            AutoDetection.activer(this)
            Toast.makeText(this, "C'est parti : tes trajets seront enregistrés tout seuls.", Toast.LENGTH_LONG).show()
        } else Toast.makeText(this, "Il manque une autorisation (position « Toujours » ou activité physique).", Toast.LENGTH_LONG).show()
        afficher()
    }

    // ---------------------------------------------------------------- Fichiers

    fun exporter(nom: String, texte: () -> String) { exportContenu = texte; exportLauncher.launch(nom) }

    fun importerReleve() = importLauncher.launch("*/*")

    fun testerCapture() = pickImage.launch("image/*")

    /** Photo d'un ticket ou d'une facture, rangée avec le frais. */
    fun prendrePhoto(retour: (String?) -> Unit) {
        val f = File(File(filesDir, "justificatifs").apply { mkdirs() }, "ticket-${System.currentTimeMillis()}.jpg")
        photoFichier = f; photoRetour = retour
        try { photoLauncher.launch(FacturePdf.uri(this, f)) }
        catch (_: Exception) { Toast.makeText(this, "Pas d'appareil photo disponible", Toast.LENGTH_SHORT).show(); retour(null) }
    }

    /** Réduit la photo à 1600 px (un ticket reste lisible, le téléphone ne se remplit pas). */
    private fun reduire(f: File) {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, o)
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= 1600) s *= 2
            val b = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = s }) ?: return
            f.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        } catch (_: Exception) {}
    }

    fun voirPhoto(chemin: String) {
        val f = File(chemin)
        if (!f.exists()) { Toast.makeText(this, "Photo introuvable", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(FacturePdf.uri(this, f), "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "Aucune appli pour voir la photo", Toast.LENGTH_SHORT).show() }
    }

    fun ouvrirCourse(r: Ride) = startActivity(Intent(this, CourseActivity::class.java).putExtra(CourseActivity.EXTRA_COURSE, r.debut))

    fun ouvrirFacture(r: Ride?) = startActivity(Intent(this, FactureActivity::class.java).apply {
        if (r != null) putExtra(FactureActivity.EXTRA_COURSE, r.debut)
    })

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
