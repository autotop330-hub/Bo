package fr.bonnecourse

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var status: TextView
    private lateinit var permBtn: Button
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var testOut: LinearLayout
    private lateinit var histBox: LinearLayout
    private lateinit var stats: TextView

    private val energies = listOf("essence" to "Essence", "diesel" to "Diesel", "hybride" to "Hybride", "electrique" to "Électrique")
    private val energyDefaults = mapOf("essence" to (6.5 to 1.85), "diesel" to (5.8 to 1.72), "hybride" to (4.8 to 1.85), "electrique" to (16.0 to 0.25))
    private val fields = mutableMapOf<String, EditText>()
    private lateinit var energySpin: Spinner
    private lateinit var deviseSpin: Spinner
    private lateinit var fixesSwitch: SwitchCompat

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            val i = Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_START)
                .putExtra(BubbleService.EXTRA_CODE, res.resultCode)
                .putExtra(BubbleService.EXTRA_DATA, res.data)
            startForegroundService(i)
            status.postDelayed({ refresh() }, 600)
            Toast.makeText(this, "Bulle lancée. Ouvre Uber, elle reste à l'écran.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Sans l'autorisation de capture, la bulle ne peut pas lire l'offre.", Toast.LENGTH_LONG).show()
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askLocation() }

    private val locLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.ACCESS_FINE_LOCATION] != true)
            Toast.makeText(this, "Sans la position précise, le kilométrage ne sera pas compté.", Toast.LENGTH_LONG).show()
        askProjection()
    }

    // Kilométrage
    private lateinit var kmBox: LinearLayout
    private lateinit var btnLouee: LinearLayout
    private lateinit var autoSwitch: SwitchCompat
    private var majAutoEnCours = false

    private val autoPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Build.VERSION.SDK_INT >= 29 && !AutoDetection.autorise(this) &&
            androidx.core.content.ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Choisis « Toujours autoriser » pour la position, sinon les trajets ne seront pas détectés.", Toast.LENGTH_LONG).show()
            bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else finirActivationAuto()
    }
    private val bgLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { finirActivationAuto() }
    private lateinit var btnMienne: LinearLayout
    private lateinit var argentBox: LinearLayout
    private lateinit var rapBox: LinearLayout
    private lateinit var tvaSwitch: SwitchCompat
    private val argentFields = mutableMapOf<String, EditText>()
    private var dernierRapprochement: Rapprochement.Resultat? = null
    private lateinit var optBox: LinearLayout
    private lateinit var optParts: Spinner
    private lateinit var optCouple: SwitchCompat
    private lateinit var optRetraite: SwitchCompat
    private val optFields = mutableMapOf<String, EditText>()
    private val PARTS = listOf(1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0)
    private val REGIMES = listOf("location", "ik", "micro")
    private lateinit var moisTitre: TextView
    private lateinit var regimeSpin: Spinner
    private lateinit var cvSpin: Spinner
    private val cal: java.util.Calendar = java.util.Calendar.getInstance()
    private var vueAnnee = cal.get(java.util.Calendar.YEAR)
    private var vueMois = cal.get(java.util.Calendar.MONTH) + 1
    private var deleteArm = 0L

    private val importLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        val texte = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        } catch (e: Exception) { null }
        if (texte == null) { Toast.makeText(this, "Fichier illisible", Toast.LENGTH_LONG).show(); return@registerForActivityResult }
        importerReleve(texte)
    }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        uri ?: return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(csvMois().toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Relevé enregistré", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Enregistrement impossible : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bmp == null) { Toast.makeText(this, "Image illisible", Toast.LENGTH_SHORT).show(); return@registerForActivityResult }
        testOut.removeAllViews()
        testOut.addView(Ui.text(this, "Lecture en cours…", 14f, Ui.MUTED))
        Reader.analyse(bmp, store) { r, err, raw, _ ->
            testOut.removeAllViews()
            testOut.addView(if (r != null) Tile.build(this, r, store.profile, null) else Tile.error(this, err ?: "Erreur", null))
            testOut.addView(Ui.text(this, "Texte lu sur l'image :", 13f, Ui.MUTED).apply { setPadding(0, Ui.dp(this@MainActivity, 10), 0, 0) })
            testOut.addView(Ui.text(this, raw.ifBlank { "(rien)" }, 12f, Ui.MUTED).apply { setTextIsSelectable(true) })
            drawHistory()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        setContentView(buildUi())
        fillProfile()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        drawHistory()
        if (store.autoTrajets) AutoDetection.activer(this)
        majAutoEnCours = true; autoSwitch.isChecked = store.autoTrajets; majAutoEnCours = false
        drawKm()
    }

    // ---------------------------------------------------------------- Écran

    private fun buildUi(): View {
        val pad = Ui.dp(this, 16)
        val col = Ui.vertical(this, 14).apply { setPadding(pad, pad, pad, pad * 2) }

        col.addView(Ui.text(this, "Bonne Course", 30f).apply { typeface = Ui.CONDENSED })

        // Bulle
        val bulle = card()
        bulle.addView(label("La bulle"))
        status = Ui.text(this, "", 15f)
        bulle.addView(status)
        permBtn = button("1. Autoriser l'affichage par-dessus les applis", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        startBtn = button("Lancer la bulle", true) { startBubble() }
        stopBtn = button("Arrêter la bulle", false) {
            startService(Intent(this, BubbleService::class.java).setAction(BubbleService.ACTION_STOP))
            status.postDelayed({ refresh() }, 400)
        }
        bulle.addView(permBtn); bulle.addView(startBtn); bulle.addView(stopBtn)
        bulle.addView(Ui.text(this,
            "Au lancement, Android demande l'autorisation d'enregistrer l'écran : choisis « Écran entier ». " +
            "Rien n'est enregistré ni envoyé : l'image est lue sur le téléphone puis jetée.", 13f, Ui.MUTED))
        col.addView(bulle)

        // Kilométrage
        val km = card()
        km.addView(label("Kilométrage et frais"))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        val prev = Ui.text(this, "‹", 32f, Ui.ACCENT).apply { setPadding(Ui.dp(this@MainActivity, 8), 0, Ui.dp(this@MainActivity, 16), 0); setOnClickListener { changeMois(-1) } }
        val next = Ui.text(this, "›", 32f, Ui.ACCENT).apply { setPadding(Ui.dp(this@MainActivity, 16), 0, Ui.dp(this@MainActivity, 8), 0); setOnClickListener { changeMois(1) } }
        moisTitre = Ui.text(this, "", 22f).apply { typeface = Ui.CONDENSED; gravity = android.view.Gravity.CENTER }
        nav.addView(prev); nav.addView(moisTitre,LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); nav.addView(next)
        km.addView(nav)
        // Le choix de la voiture, bien visible
        btnLouee = choixVoiture("Voiture louée", "la société paie loyer et frais") { choisirRegime("location") }
        btnMienne = choixVoiture("Ma voiture", "la société te verse des indemnités km") { choisirRegime("ik") }
        km.addView(Ui.buttonRow(this, btnLouee, btnMienne))
        kmBox = Ui.vertical(this, 8)
        km.addView(kmBox)
        val kmReg = Ui.vertical(this, 8)
        regimeSpin = spinner(listOf("SASU · voiture louée à la société", "SASU · indemnités km (voiture à ton nom)", "Micro-entreprise"))
        kmReg.addView(row("Régime", regimeSpin))
        cvSpin = spinner(listOf("3 CV et moins", "4 CV", "5 CV", "6 CV", "7 CV et plus"))
        kmReg.addView(row("Puissance fiscale", cvSpin))
        val onFiscal = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val reg = REGIMES[regimeSpin.selectedItemPosition.coerceIn(0, 2)]
                val cv = cvSpin.selectedItemPosition + 3
                val old = store.profile
                if (old.regime != reg || old.cv != cv) { store.profile = old.copy(regime = reg, cv = cv); drawKm() }
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        regimeSpin.onItemSelectedListener = onFiscal
        cvSpin.onItemSelectedListener = onFiscal
        kmReg.addView(Ui.text(this, "La puissance fiscale est sur la carte grise, case P.6.", 13f, Ui.MUTED))
        autoSwitch = SwitchCompat(this).apply { text = "Détecter mes trajets automatiquement"; setTextColor(Ui.FG) }
        autoSwitch.setOnCheckedChangeListener { _, on -> if (!majAutoEnCours) basculerAuto(on) }
        kmReg.addView(autoSwitch)
        kmReg.addView(Ui.text(this, "Quand la bulle n'est pas lancée, chaque trajet en voiture est enregistré tout seul. " +
            "À l'arrivée, une notification demande : pro ou perso ?", 13f, Ui.MUTED))
        km.addView(Ui.details(this, "Réglages", kmReg))
        km.addView(button("Exporter le relevé du mois (tableur)", true) {
            exportLauncher.launch(String.format("kilometrage-%04d-%02d.csv", vueAnnee, vueMois))
        })
        col.addView(km)

        // Argent : ce qui reste vraiment dans la poche
        val argent = card()
        argent.addView(label("Ce que tu gagnes vraiment"))
        argentBox = Ui.vertical(this, 8)
        argent.addView(argentBox)
        val argReg = Ui.vertical(this, 8)
        tvaSwitch = SwitchCompat(this).apply { text = "Société assujettie à la TVA (10 % sur le prix client)"; setTextColor(Ui.FG) }
        argReg.addView(tvaSwitch)
        listOf(
            "commPlat" to "Part gardée par Uber/Bolt sur le prix client (%)",
            "autresFrais" to "Frais fixes de la société par mois (comptable, banque, téléphone…)",
            "tmi" to "Ta tranche d'impôt (%) : 0, 11, 30…",
            "tauxMicro" to "Cotisations URSSAF micro-entreprise (%)"
        ).forEach { (k, lab) ->
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(Ui.FG); textSize = 18f
            }
            argentFields[k] = e
            argReg.addView(Ui.text(this, lab, 13f, Ui.MUTED))
            argReg.addView(e)
        }
        argReg.addView(button("Enregistrer et recalculer", true) { saveArgent() })
        argent.addView(Ui.details(this, "Réglages", argReg))
        col.addView(argent)

        // Optimisation fiscale
        val opt = card()
        opt.addView(label("Te payer au mieux"))
        optBox = Ui.vertical(this, 8)
        opt.addView(optBox)
        val optReg = Ui.vertical(this, 8)
        optParts = spinner(PARTS.map { "$it part" + if (it > 1) "s" else "" })
        optReg.addView(row("Parts fiscales du foyer", optParts))
        optCouple = SwitchCompat(this).apply { text = "Marié ou pacsé"; setTextColor(Ui.FG) }
        optReg.addView(optCouple)
        optRetraite = SwitchCompat(this).apply { text = "Valider 4 trimestres de retraite par an"; setTextColor(Ui.FG) }
        optReg.addView(optRetraite)
        listOf(
            "autres" to "Autres revenus du foyer par an (salaire du conjoint…)",
            "prevGains" to "Prévision : versements par mois (0 = mes vraies courses)",
            "prevKm" to "Prévision : km pro par mois"
        ).forEach { (k, lab) ->
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(Ui.FG); textSize = 18f
            }
            optFields[k] = e
            optReg.addView(Ui.text(this, lab, 13f, Ui.MUTED)); optReg.addView(e)
        }
        optReg.addView(button("Recalculer", true) { saveOpt(); drawKm() })
        opt.addView(Ui.details(this, "Ma situation", optReg))
        col.addView(opt)

        // Rapprochement avec les relevés des plateformes
        val rap = card()
        rap.addView(label("Rapprochement Uber / Bolt"))
        rap.addView(Ui.text(this, "Exporte ton relevé de gains en CSV depuis le site chauffeur de la plateforme, puis choisis le fichier ici. " +
            "Chaque paiement est comparé aux courses suivies par la bulle.", 14f, Ui.MUTED))
        rap.addView(button("Importer un relevé (CSV)", true) { importLauncher.launch("*/*") })
        rapBox = Ui.vertical(this, 8)
        rap.addView(rapBox)
        col.addView(rap)

        // Test
        val test = card()
        test.addView(label("Tester avec une capture"))
        test.addView(Ui.text(this, "Fais une capture d'écran d'une offre Uber ou Bolt, puis choisis-la ici pour vérifier la lecture.", 14f, Ui.MUTED))
        test.addView(button("Choisir une capture", false) { pickImage.launch("image/*") })
        testOut = Ui.vertical(this, 6)
        test.addView(testOut)
        col.addView(test)

        // Profil
        val prof = card()
        prof.addView(label("Mon véhicule"))
        energySpin = spinner(energies.map { it.second })
        prof.addView(row("Énergie", energySpin))
        listOf(
            "conso" to "Consommation (L ou kWh /100 km)",
            "prixEnergie" to "Prix du carburant (€/L ou €/kWh)",
            "usure" to "Entretien et pneus (€/km)",
            "commission" to "Commission à déduire (%) · 0 pour Uber",
            "fixesMois" to "Charges fixes par mois (LLD, assurance…)",
            "kmMois" to "Km roulés par mois",
            "objectifHeure" to "Objectif net (€/h)",
            "minimumKm" to "Minimum brut (€/km)"
        ).forEach { (k, lab) ->
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(Ui.FG); textSize = 18f
            }
            fields[k] = e
            prof.addView(Ui.text(this, lab, 13f, Ui.MUTED))
            prof.addView(e)
        }
        fixesSwitch = SwitchCompat(this).apply { text = "Répartir les charges fixes sur chaque km"; setTextColor(Ui.FG) }
        prof.addView(fixesSwitch)
        deviseSpin = spinner(listOf("€", "CHF"))
        prof.addView(row("Devise", deviseSpin))
        energySpin.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            var first = true
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                energyDefaults[energies[pos].first]?.let { (c, pr) ->
                    fields["conso"]?.setText(c.toString()); fields["prixEnergie"]?.setText(pr.toString())
                }
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        prof.addView(button("Enregistrer", true) { saveProfile() })
        col.addView(prof)

        // Historique
        val hist = card()
        hist.addView(label("Historique des analyses"))
        stats = Ui.text(this, "", 15f)
        hist.addView(stats)
        histBox = Ui.vertical(this, 6)
        hist.addView(histBox)
        hist.addView(button("Effacer l'historique", false) { store.clear(); drawHistory() })
        col.addView(hist)

        return ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            addView(col)
        }
    }

    private fun card() = Ui.vertical(this, 10).apply {
        background = Ui.box(this@MainActivity, Ui.SURFACE)
        val p = Ui.dp(this@MainActivity, 14); setPadding(p, p, p, p)
    }

    private fun label(s: String) = Ui.text(this, s.uppercase(), 13f, Ui.MUTED, true).apply { letterSpacing = 0.08f }

    private fun button(s: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f
        setTextColor(if (primary) Ui.BG else Ui.FG)
        background = Ui.box(this@MainActivity, if (primary) Ui.ACCENT else Ui.RAISE, if (primary) Ui.ACCENT else Ui.LINE, 1, 12)
        setOnClickListener { onClick() }
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun row(lab: String, v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(Ui.text(this@MainActivity, lab, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(v)
    }

    // ---------------------------------------------------------------- Bulle

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        permBtn.visibility = if (canDraw) View.GONE else View.VISIBLE
        startBtn.text = if (canDraw) "Lancer la bulle" else "2. Lancer la bulle"
        stopBtn.visibility = if (BubbleService.running) View.VISIBLE else View.GONE
        status.text = when {
            BubbleService.running -> "Bulle active. Quand une course sonne, touche la bulle."
            !canDraw -> "Étape 1 : autorise Bonne Course à s'afficher par-dessus les autres applis."
            else -> "Prêt. Lance la bulle avant d'ouvrir Uber."
        }
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else askLocation()
    }

    private fun askLocation() {
        locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    private fun askProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    // ---------------------------------------------------------------- Profil

    private fun fillProfile() {
        val p = store.profile
        energySpin.setSelection(energies.indexOfFirst { it.first == p.energy }.coerceAtLeast(0))
        mapOf("conso" to p.conso, "prixEnergie" to p.prixEnergie, "usure" to p.usure, "commission" to p.commission,
            "fixesMois" to p.fixesMois, "kmMois" to p.kmMois, "objectifHeure" to p.objectifHeure, "minimumKm" to p.minimumKm)
            .forEach { (k, v) -> fields[k]?.setText(if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()) }
        fixesSwitch.isChecked = p.inclureFixes
        deviseSpin.setSelection(if (p.devise == "CHF") 1 else 0)
        regimeSpin.setSelection(REGIMES.indexOf(p.regime).coerceAtLeast(0))
        tvaSwitch.isChecked = p.tva
        val sit = store.situation
        optParts.setSelection(PARTS.indexOf(sit.parts).coerceAtLeast(0))
        optCouple.isChecked = sit.couple
        optRetraite.isChecked = sit.retraite
        val (pg, pk) = store.prevision
        fun t(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString().replace('.', ',')
        optFields["autres"]?.setText(t(sit.autresRevenus)); optFields["prevGains"]?.setText(t(pg)); optFields["prevKm"]?.setText(t(pk))
        mapOf("commPlat" to p.commissionPlateforme, "autresFrais" to p.autresFrais, "tmi" to p.tmi, "tauxMicro" to p.tauxMicro)
            .forEach { (k, v) -> argentFields[k]?.setText(if (v % 1.0 == 0.0) v.toLong().toString() else v.toString().replace('.', ',')) }
        cvSpin.setSelection((p.cv - 3).coerceIn(0, 4))
    }

    private fun saveProfile() {
        fun f(k: String, d: Double) = fields[k]?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()?.takeIf { it >= 0 } ?: d
        val old = store.profile
        store.profile = Profile(
            energy = energies[energySpin.selectedItemPosition].first,
            conso = f("conso", old.conso), prixEnergie = f("prixEnergie", old.prixEnergie), usure = f("usure", old.usure),
            commission = f("commission", old.commission), fixesMois = f("fixesMois", old.fixesMois), kmMois = f("kmMois", old.kmMois),
            inclureFixes = fixesSwitch.isChecked, objectifHeure = f("objectifHeure", old.objectifHeure).coerceAtLeast(1.0),
            minimumKm = f("minimumKm", old.minimumKm).coerceAtLeast(0.1), devise = deviseSpin.selectedItem.toString(),
            cv = old.cv, regime = old.regime
        )
        drawKm()
        val p = store.profile
        Toast.makeText(this, "Enregistré · coût ${Analyzer.fmt2(p.coutKm())} ${p.devise} par km roulé", Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- Historique

    private fun drawHistory() {
        val h = store.history()
        val d = store.profile.devise
        val ok = h.count { it.verdict == Verdict.ACCEPTER.name }
        val bof = h.count { it.verdict == Verdict.A_VOIR.name }
        val ko = h.count { it.verdict == Verdict.REFUSER.name }
        val moy = if (h.isNotEmpty()) h.sumOf { it.parHeure } / h.size else 0.0
        stats.text = if (h.isEmpty()) "Aucune analyse pour l'instant. Touche la bulle sur une offre pour commencer."
        else "${h.size} analysées · $ok à accepter · $bof à voir · $ko à refuser\nMoyenne des offres : ${moy.roundToInt()} $d/h net"
        histBox.removeAllViews()
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        h.take(40).forEach { e ->
            val v = runCatching { Verdict.valueOf(e.verdict) }.getOrDefault(Verdict.A_VOIR)
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            line.addView(View(this).apply { setBackgroundColor(Ui.color(v)) }, LinearLayout.LayoutParams(Ui.dp(this, 4), ViewGroup.LayoutParams.MATCH_PARENT).apply { marginEnd = Ui.dp(this@MainActivity, 10) })
            val txt = Ui.vertical(this)
            txt.addView(Ui.text(this, "${Analyzer.fmt2(e.prix)} $d · ${v.mot} · ${Analyzer.fmt1(e.score)}/10", 15f, Ui.FG, true))
            txt.addView(Ui.text(this, "${fmt.format(Date(e.t))} · ${Analyzer.fmt1(e.km)} km · ${e.min.roundToInt()} min · net ${Analyzer.fmt2(e.net)} $d · ${e.parHeure.roundToInt()} $d/h", 13f, Ui.MUTED))
            line.addView(txt)
            histBox.addView(line)
        }
    }

    // ---------------------------------------------------------------- Kilométrage

    /** Saisie du montant d'une course client privé. */
    private fun askPrice(r: Ride) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (r.prix > 0) setText(Analyzer.fmt2(r.prix))
            hint = "Montant encaissé"
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Montant de la course")
            .setView(input)
            .setPositiveButton("Enregistrer") { _, _ ->
                val v = input.text.toString().replace(',', '.').toDoubleOrNull()
                if (v != null && v >= 0) { store.setRidePrice(r.debut, v); drawKm() }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- Argent

    private fun saveArgent() {
        fun f(k: String, d: Double) = argentFields[k]?.text?.toString()?.replace(',', '.')?.toDoubleOrNull()?.takeIf { it >= 0 } ?: d
        val o = store.profile
        store.profile = o.copy(tva = tvaSwitch.isChecked, commissionPlateforme = f("commPlat", o.commissionPlateforme).coerceAtMost(90.0),
            autresFrais = f("autresFrais", o.autresFrais), tmi = f("tmi", o.tmi).coerceAtMost(45.0), tauxMicro = f("tauxMicro", o.tauxMicro))
        drawKm()
        Toast.makeText(this, "Recalculé", Toast.LENGTH_SHORT).show()
    }

    private fun drawArgent() {
        if (!::argentBox.isInitialized) return
        val p = store.profile
        val n = Finance.mois(store.rides(), store.service(), store.perso(), vueAnnee, vueMois, p, moisEcoules())
        val b = n.base
        argentBox.removeAllViews()
        // Même méthode que « Te payer au mieux » : le mois prend le taux de la meilleure option de l'année
        var net = n.meilleur
        if (p.regime != "micro") activiteAnnee(p)?.let { a ->
            val o = Optimiseur.optimiser(a, p, store.situation, p.regime)
            if (o.annuel.resultat > 0)
                net = max(n.resultat, 0.0) * (o.recommande.net - o.recommande.bonusIk) / o.annuel.resultat + min(n.resultat, 0.0) + n.bonusIk
        }
        fun m(x: Double) = String.format(Locale.FRANCE, "%,.0f €", x)
        fun ligne(box: LinearLayout, a: String, v: String, fort: Boolean = false, couleur: Int = Ui.FG) = box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Ui.text(this@MainActivity, a, 15f, if (fort) Ui.FG else Ui.MUTED, fort), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Ui.text(this@MainActivity, v, 15f, couleur, true))
        })

        // L'essentiel
        argentBox.addView(Ui.vertical(this).apply {
            background = Ui.box(this@MainActivity, Ui.RAISE, Ui.RAISE, 0, 12)
            val pd = Ui.dp(this@MainActivity, 12); setPadding(pd, pd, pd, pd)
            addView(Ui.text(this@MainActivity, m(net), 34f, if (net >= 0) Ui.GO else Ui.STOP).apply { typeface = Ui.CONDENSED })
            addView(Ui.text(this@MainActivity, "dans ta poche ce mois", 13f, Ui.MUTED))
        })
        val voitureFrais = (if (p.regime == "ik") b.coutVoiturePerso else b.chargesVoiture) + b.autresFrais
        val impots = b.gains - b.tvaNette - voitureFrais - net
        ligne(argentBox, "Encaissé", m(b.gains))
        if (p.tva) ligne(argentBox, "TVA", "− " + m(b.tvaNette))
        ligne(argentBox, "Voiture et frais", "− " + m(voitureFrais))
        ligne(argentBox, "Impôts et cotisations", "− " + m(impots))

        // Le détail, replié
        val det = Ui.vertical(this, 8)
        ligne(det, "Versé par les plateformes", m(b.gainsPlateformes))
        if (b.gainsPrives > 0) ligne(det, "Clients privés", m(b.gainsPrives))
        if (p.tva) {
            ligne(det, "TVA à reverser (10 % du prix client)", "− " + m(b.tvaCollectee))
            if (b.tvaDeductible > 0) ligne(det, "TVA récupérée", "+ " + m(b.tvaDeductible))
        }
        ligne(det, when (p.regime) { "ik" -> "Indemnités km versées"; "location" -> "Voiture (loyer, assurance, recharge…)"; else -> "Voiture" }, "− " + m(b.chargesVoiture))
        ligne(det, "Frais de la société", "− " + m(b.autresFrais))
        if (p.regime == "micro") {
            ligne(det, "Cotisations URSSAF", "− " + m(n.cotisationsMicro))
            ligne(det, "Impôt sur le revenu", "− " + m(n.impotMicro))
        } else {
            ligne(det, "Bénéfice de la société", m(n.resultat), true)
            ligne(det, "Impôts et cotisations (meilleure option)", "− " + m(n.resultat + n.bonusIk - net))
            if (n.bonusIk != 0.0) ligne(det, "Indemnités km nettes de frais", "+ " + m(n.bonusIk))
        }
        det.addView(Ui.text(this, "Estimation, à valider avec ton comptable.", 13f, Ui.MUTED))
        argentBox.addView(Ui.details(this, "Voir le détail", det))
        if (!p.tva && n.depasseFranchiseTva)
            argentBox.addView(Ui.text(this, "Attention : à ce rythme, la TVA devient obligatoire (plus de 37 500 € par an).", 14f, Ui.WARN))
    }

    // ---------------------------------------------------------------- Optimisation fiscale

    private fun saveOpt() {
        fun f(k: String) = optFields[k]?.text?.toString()?.replace(',', '.')?.replace(" ", "")?.toDoubleOrNull()?.takeIf { it >= 0 } ?: 0.0
        store.situation = Optimiseur.Situation(PARTS[optParts.selectedItemPosition.coerceIn(0, PARTS.size - 1)],
            optCouple.isChecked, f("autres"), optRetraite.isChecked)
        store.prevision = f("prevGains") to f("prevKm")
    }

    /** L'année : prévision saisie, ou projection des vraies courses. */
    private fun activiteAnnee(p: Profile): Optimiseur.Activite? {
        val (pg, pk) = store.prevision
        if (pg > 0) return Optimiseur.Activite(pg * 12, 0.0, pk * 12)
        val now = java.util.Calendar.getInstance()
        val ecoules = now.get(java.util.Calendar.MONTH) +
            now.get(java.util.Calendar.DAY_OF_MONTH).toDouble() / now.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        return Optimiseur.activiteDepuisDonnees(store.rides(), store.service(), store.perso(), now.get(java.util.Calendar.YEAR), ecoules, p)
    }

    private fun drawOpt() {
        if (!::optBox.isInitialized) return
        optBox.removeAllViews()
        val p = store.profile
        val s = store.situation
        val activite = activiteAnnee(p)
        if (activite == null) {
            optBox.addView(Ui.text(this, "Pas encore assez de courses. Ouvre « Ma situation » et mets une prévision.", 14f, Ui.WARN))
            return
        }
        fun m(x: Double) = String.format(Locale.FRANCE, "%,.0f €", x)
        fun ligne(box: LinearLayout, a: String, v: String, fort: Boolean = false, couleur: Int = Ui.FG) = box.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Ui.text(this@MainActivity, a, 15f, if (fort) Ui.FG else Ui.MUTED, fort), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Ui.text(this@MainActivity, v, 15f, couleur, true))
        })
        val noms = mapOf("location" to "Voiture louée à la SASU", "ik" to "Indemnités km (voiture au nom du chauffeur)", "micro" to "Micro-entreprise")
        val res = listOf("location", "ik", "micro").map { it to Optimiseur.optimiser(activite, p, s, it) }
        val o = res.first { it.first == p.regime }.second
        val pl = o.recommande

        // L'essentiel : combien, et comment
        optBox.addView(Ui.vertical(this).apply {
            background = Ui.box(this@MainActivity, Ui.RAISE, Ui.RAISE, 0, 12)
            val pd = Ui.dp(this@MainActivity, 12); setPadding(pd, pd, pd, pd)
            addView(Ui.text(this@MainActivity, "${m(pl.net / 12)} par mois", 32f, Ui.GO).apply { typeface = Ui.CONDENSED })
            addView(Ui.text(this@MainActivity, "net pour toi, en te payant de la meilleure façon", 13f, Ui.MUTED))
        })
        val comment = if (p.regime == "micro") "Micro-entreprise : cotisations et impôt déjà déduits."
            else (if (pl.salaireBrut < 1) "Pas de salaire. " else "Salaire : ${m(pl.salaireBrut / 12)} brut par mois. ") +
                "Dividendes : ${m(pl.dividendes)} par an" + (if (pl.dividendesAuBareme) ", en cochant la case 2OP." else ".")
        optBox.addView(Ui.text(this, comment, 15f, Ui.FG, true))
        val mieux = res.filter { it.second.eligible && it.first != p.regime }.maxByOrNull { it.second.recommande.net }
        if (mieux != null && mieux.second.recommande.net > pl.net + 100)
            optBox.addView(Ui.text(this, "Plus rentable : ${noms[mieux.first]}, +${m(mieux.second.recommande.net - pl.net)} par an.", 14f, Ui.WARN))
        val leviers = Optimiseur.leviers(o, p, s)
        // Deux conseils de plus, sans répéter la phrase du dessus
        leviers.filterNot { l -> listOf("Se verser", "Ne pas se verser", "Cocher", "Garder la flat tax").any { l.startsWith(it) } }
            .take(2).forEach { optBox.addView(Ui.text(this, "• $it", 14f)) }

        // Le détail, replié
        val det = Ui.vertical(this, 8)
        det.addView(Ui.text(this, "Net par an selon le montage", 14f, Ui.FG, true))
        res.forEach { (reg, x) -> ligne(det, noms[reg] ?: reg, if (x.eligible) m(x.recommande.net) else "impossible", reg == p.regime) }
        if (p.regime != "micro") {
            det.addView(Ui.text(this, "Net par an selon la façon de te payer", 14f, Ui.FG, true))
            listOfNotNull(o.toutDividendes, o.toutSalaire, o.optimal.takeIf { kotlin.math.abs(it.coutSalaire - o.toutDividendes.coutSalaire) >= 1 },
                o.optimalRetraite).forEach {
                val moi = kotlin.math.abs(it.net - pl.net) < 1 && kotlin.math.abs(it.coutSalaire - pl.coutSalaire) < 1
                ligne(det, it.nom + (if (moi) " ✓" else ""), m(it.net), moi, if (moi) Ui.GO else Ui.FG)
            }
        }
        ligne(det, "Total impôts et cotisations par an", m(pl.totalPrelevements), true)
        leviers.forEach { det.addView(Ui.text(this, "• $it", 14f)) }
        det.addView(Ui.text(this, "Estimation 2026, à valider avec ton comptable.", 13f, Ui.MUTED))
        optBox.addView(Ui.details(this, "Voir le détail", det))
    }

    // ---------------------------------------------------------------- Rapprochement

    private fun importerReleve(texte: String) {
        rapBox.removeAllViews()
        val table = Rapprochement.lireCsv(texte)
        val cols = Rapprochement.detecter(table)
        if (cols == null) {
            rapBox.addView(Ui.text(this, "Je n'ai pas reconnu les colonnes date et montant de ce fichier. " +
                "Colonnes trouvées : ${table.entetes.joinToString(", ").ifBlank { "aucune" }}. " +
                "Envoie-moi un exemple de ce fichier et j'ajouterai ce format.", 14f, Ui.WARN))
            return
        }
        val lignes = Rapprochement.lignes(table, cols)
        val res = Rapprochement.rapprocher(store.rides(), lignes)
        dernierRapprochement = res
        val d = store.profile.devise
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        fun m(x: Double) = "${Analyzer.fmt2(x)} $d"
        fun t(s: String, c: Int = Ui.FG, sp: Float = 14f, b: Boolean = false) = Ui.text(this, s, sp, c, b)

        rapBox.addView(t("Colonnes lues : date « ${table.entetes[cols.date]} »" +
            (cols.heure?.let { ", heure « ${table.entetes[it]} »" } ?: "") + ", montant « ${table.entetes[cols.montant]} »", Ui.MUTED, 13f))
        rapBox.addView(t("Relevé : ${m(res.totalReleve)} · Appli : ${m(res.totalAppli)} · Écart : ${m(res.totalReleve - res.totalAppli)}", Ui.FG, 15f, true))
        fun pl(n: Int, un: String, plusieurs: String) = "$n ${if (n > 1) plusieurs else un}"
        rapBox.addView(t("✓ ${pl(res.identiques.size, "course identique", "courses identiques")}", Ui.GO))
        if (res.ecarts.isNotEmpty()) {
            rapBox.addView(t("~ ${pl(res.ecarts.size, "course avec un montant différent", "courses avec un montant différent")} (pourboire, majoration, frais d'attente…)", Ui.WARN))
            res.ecarts.take(30).forEach { (r, l) -> rapBox.addView(t("   ${fmt.format(Date(r.debut))} : appli ${m(r.prix)} → relevé ${m(l.montant)}", Ui.MUTED, 13f)) }
            rapBox.addView(button("Corriger avec les montants du relevé", true) {
                res.ecarts.forEach { (r, l) -> store.setRidePrice(r.debut, l.montant) }
                Toast.makeText(this, "${res.ecarts.size} montants corrigés", Toast.LENGTH_SHORT).show()
                rapBox.removeAllViews(); drawKm()
            })
        }
        if (res.absentesAppli.isNotEmpty()) {
            rapBox.addView(t("✕ ${pl(res.absentesAppli.size, "course payée mais pas suivie", "courses payées mais pas suivies")} par la bulle", Ui.STOP))
            res.absentesAppli.take(30).forEach { rapBox.addView(t("   ${fmt.format(Date(it.t))} : ${m(it.montant)}", Ui.MUTED, 13f)) }
            rapBox.addView(t("Leurs km sont déjà comptés si la bulle était active. Ajoute-les pour que ton chiffre d'affaires soit complet.", Ui.MUTED, 13f))
            rapBox.addView(button("Ajouter ces courses au chiffre d'affaires", false) {
                res.absentesAppli.forEach { store.addRide(Ride(it.t, it.t, it.t, 0.0, 0.0, it.montant, lieuArrivee = "Ajoutée depuis le relevé")) }
                Toast.makeText(this, "${res.absentesAppli.size} courses ajoutées", Toast.LENGTH_SHORT).show()
                rapBox.removeAllViews(); drawKm()
            })
        }
        if (res.absentesReleve.isNotEmpty()) {
            rapBox.addView(t("? ${pl(res.absentesReleve.size, "course suivie mais absente", "courses suivies mais absentes")} du relevé (annulée ? autre plateforme ?)", Ui.WARN))
            res.absentesReleve.take(30).forEach { rapBox.addView(t("   ${fmt.format(Date(it.debut))} : ${m(it.prix)} · ${Analyzer.fmt1(it.kmTotal)} km", Ui.MUTED, 13f)) }
        }
        val negatifs = lignes.filter { it.montant < 0 }
        if (negatifs.isNotEmpty()) rapBox.addView(t("${pl(negatifs.size, "retenue ou ajustement", "retenues ou ajustements")} dans le relevé : ${m(negatifs.sumOf { it.montant })}", Ui.MUTED, 13f))
    }

    private val MOIS = listOf("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre")

    private fun choixVoiture(titre: String, sous: String, onClick: () -> Unit) = Ui.vertical(this, 2).apply {
        val pd = Ui.dp(this@MainActivity, 10); setPadding(pd, pd, pd, pd)
        addView(Ui.text(this@MainActivity, titre, 18f).apply { typeface = Ui.CONDENSED })
        addView(Ui.text(this@MainActivity, sous, 12f, Ui.MUTED))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun choisirRegime(r: String) {
        val o = store.profile
        if (o.regime != r) store.profile = o.copy(regime = r)
        regimeSpin.setSelection(REGIMES.indexOf(r).coerceAtLeast(0))
        drawKm()
    }

    private fun majChoixVoiture(regime: String) {
        listOf(btnLouee to "location", btnMienne to "ik").forEach { (v, r) ->
            val actif = regime == r
            v.background = Ui.box(this, if (actif) Ui.SURFACE else Ui.RAISE, if (actif) Ui.ACCENT else Ui.LINE, 2, 12)
        }
    }

    // ---------------------------------------------------------------- Détection automatique

    private fun basculerAuto(on: Boolean) {
        if (!on) {
            store.autoTrajets = false
            AutoDetection.desactiver(this)
            Toast.makeText(this, "Détection automatique arrêtée", Toast.LENGTH_SHORT).show()
            return
        }
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 29) perms += Manifest.permission.ACTIVITY_RECOGNITION
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        autoPermLauncher.launch(perms.toTypedArray())
    }

    private fun finirActivationAuto() {
        val ok = AutoDetection.autorise(this)
        store.autoTrajets = ok
        if (ok) {
            AutoDetection.activer(this)
            Toast.makeText(this, "C'est parti : tes trajets seront enregistrés tout seuls.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Il manque une autorisation (position « Toujours » ou activité physique).", Toast.LENGTH_LONG).show()
        }
        majAutoEnCours = true; autoSwitch.isChecked = ok; majAutoEnCours = false
    }

    /** Une ligne de trajet avec les boutons Pro / Perso. */
    private fun ligneTrajet(t: Trajet): View = Ui.vertical(this, 6).apply {
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        val ville = { x: String -> x.substringBefore(" (").let { it.substringAfter(", ", it) } }
        val lieux = listOf(ville(t.depart), ville(t.arrivee)).filter { it.isNotBlank() }.joinToString(" → ")
        addView(Ui.text(this@MainActivity, "${fmt.format(Date(t.debut))} · ${Analyzer.fmt1(t.km)} km · ${t.minutes.roundToInt()} min", 15f, Ui.FG, true))
        if (lieux.isNotBlank()) addView(Ui.text(this@MainActivity, lieux, 13f, Ui.MUTED))
        fun bouton(lab: String, statut: String, couleur: Int) = Ui.button(this@MainActivity, lab,
            if (t.statut == statut) couleur else Ui.RAISE, if (t.statut == statut) Ui.BG else Ui.FG, if (t.statut == statut) couleur else Ui.LINE) {
            store.classer(t.debut, statut); drawKm()
        }
        addView(Ui.buttonRow(this@MainActivity, bouton("Pro", Trajet.PRO, Ui.GO), bouton("Perso", Trajet.PERSO, Ui.MUTED)))
        setOnLongClickListener {
            val now = System.currentTimeMillis()
            if (now - deleteArm < 3000) { store.supprimerTrajet(t.debut); deleteArm = 0; drawKm() }
            else { deleteArm = now; Toast.makeText(this@MainActivity, "Appui long encore une fois pour supprimer ce trajet", Toast.LENGTH_SHORT).show() }
            true
        }
    }

    private fun changeMois(d: Int) {
        vueMois += d
        if (vueMois < 1) { vueMois = 12; vueAnnee-- }
        if (vueMois > 12) { vueMois = 1; vueAnnee++ }
        drawKm()
    }

    private fun moisEcoules(): Double {
        val now = java.util.Calendar.getInstance()
        val a = now.get(java.util.Calendar.YEAR)
        return when {
            vueAnnee < a -> 12.0
            vueAnnee > a -> 0.0
            else -> now.get(java.util.Calendar.MONTH) +
                now.get(java.util.Calendar.DAY_OF_MONTH).toDouble() / now.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
        }
    }

    private fun rapport(): MonthReport {
        val p = store.profile
        return Reports.mois(store.rides(), store.service(), vueAnnee, vueMois, p.cv, p.electrique, p.coutKm(), moisEcoules(), store.perso())
    }

    private fun csvMois(): String {
        val p = store.profile
        val km = Reports.csv(store.rides(), store.service(), vueAnnee, vueMois, rapport(), p, store.perso())
        val n = Finance.mois(store.rides(), store.service(), store.perso(), vueAnnee, vueMois, p, moisEcoules())
        val b = n.base
        fun x(v: Double) = String.format(Locale.FRANCE, "%.2f", v)
        val sb = StringBuilder(km).append("\nSynthèse financière (estimation);€\n")
        sb.append("Versé par les plateformes;${x(b.gainsPlateformes)}\n").append("Clients privés;${x(b.gainsPrives)}\n")
        if (p.tva) sb.append("Prix payés par les clients;${x(b.prixClients)}\n").append("TVA collectée (10 %);${x(b.tvaCollectee)}\n")
            .append("TVA déductible;${x(b.tvaDeductible)}\n")
        sb.append("Charges voiture;${x(b.chargesVoiture)}\n").append("Frais de la société;${x(b.autresFrais)}\n")
        if (p.regime == "micro") {
            sb.append("Cotisations URSSAF;${x(n.cotisationsMicro)}\n").append("Impôt sur le revenu estimé;${x(n.impotMicro)}\n")
                .append("Net dans la poche;${x(n.netMicro)}\n")
        } else {
            sb.append("Bénéfice avant impôt;${x(n.resultat)}\n").append("Impôt sur les sociétés du mois;${x(n.impotSocietes)}\n")
                .append("Net via dividendes (flat tax 31,4 %);${x(n.totalDividendes)}\n")
                .append("Net via salaire;${x(n.totalSalaire)}\n")
        }
        return sb.toString()
    }

    private fun drawKm() {
        if (!::kmBox.isInitialized) return
        moisTitre.text = "${MOIS[vueMois - 1].replaceFirstChar { it.uppercase() }} $vueAnnee"
        val p = store.profile
        val r = rapport()
        val d = p.devise
        majChoixVoiture(p.regime)
        kmBox.removeAllViews()

        // Chiffre principal
        val big = Ui.vertical(this).apply {
            background = Ui.box(this@MainActivity, Ui.RAISE, Ui.RAISE, 0, 12)
            val pd = Ui.dp(this@MainActivity, 12); setPadding(pd, pd, pd, pd)
        }
        if (p.regime == "ik") {
            big.addView(Ui.text(this, "${Analyzer.fmt2(r.bareme)} $d", 34f, Ui.GO).apply { typeface = Ui.CONDENSED })
            big.addView(Ui.text(this, "d'indemnités km à te faire rembourser ce mois", 13f, Ui.MUTED))
        } else {
            big.addView(Ui.text(this, "${Analyzer.fmt1(r.kmPro)} km", 34f, Ui.FG).apply { typeface = Ui.CONDENSED })
            big.addView(Ui.text(this, "professionnels ce mois", 13f, Ui.MUTED))
        }
        kmBox.addView(big)

        fun ligne(a: String, b: String) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(Ui.text(this@MainActivity, a, 15f, Ui.MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Ui.text(this@MainActivity, b, 15f, Ui.FG, true))
        }
        if (p.regime == "ik") kmBox.addView(ligne("Km pro", "${Analyzer.fmt1(r.kmPro)} km"))
        kmBox.addView(ligne("Courses", "${r.courses}"))
        kmBox.addView(ligne("Trajets perso (non comptés)", "${Analyzer.fmt1(r.kmPerso)} km"))

        // Trajets détectés automatiquement qui attendent un classement
        val tous = store.trajets()
        val aClasser = tous.filter { it.statut == Trajet.A_CLASSER }
        if (aClasser.isNotEmpty()) {
            kmBox.addView(Ui.text(this, "${aClasser.size} trajet${if (aClasser.size > 1) "s" else ""} à classer · ${Analyzer.fmt1(aClasser.sumOf { it.km })} km",
                15f, Ui.WARN, true))
            aClasser.take(10).forEach { kmBox.addView(ligneTrajet(it)) }
        }

        val det = Ui.vertical(this, 8)
        fun dl(a: String, b: String) = det.addView(ligne(a, b))
        dl("Client à bord", "${Analyzer.fmt1(r.kmCourse)} km")
        dl("Approche", "${Analyzer.fmt1(r.kmApproche)} km")
        dl("À vide entre courses", "${Analyzer.fmt1(r.kmVide)} km")
        if (r.kmPerso > 0) dl("Part pro", "${(r.partPro * 100).roundToInt()} %")
        dl("Temps en course", "${(r.minutes / 60).toInt()} h ${String.format("%02d", (r.minutes % 60).roundToInt())}")
        if (r.coursesPrivees > 0) dl("Clients privés", "${r.coursesPrivees}")
        if (r.chiffre > 0) dl("Montant des courses", "${Analyzer.fmt2(r.chiffre)} $d")
        dl("Coût de ces km", "${Analyzer.fmt2(r.coutReel)} $d")
        if (p.regime == "ik") {
            dl("Km pro de l'année avant ce mois", "${Analyzer.fmt1(r.kmAnneeAvant)} km")
            det.addView(Ui.text(this, "Barème : " + Bareme.description(r.kmAnneeAvant + r.kmPro, p.cv, p.electrique), 13f, Ui.ACCENT))
            det.addView(Ui.text(this, "Sans impôt ni cotisations pour toi. En échange, la société ne paie rien sur la voiture.", 13f, Ui.MUTED))
        }
        kmBox.addView(Ui.details(this, "Voir le détail", det))
        drawArgent()
        drawOpt()

        // Courses du mois (appui long pour supprimer une erreur)
        val cal = java.util.Calendar.getInstance()
        val rides = store.rides().filter {
            cal.timeInMillis = it.debut
            cal.get(java.util.Calendar.YEAR) == vueAnnee && cal.get(java.util.Calendar.MONTH) + 1 == vueMois
        }.sortedByDescending { it.debut }
        if (rides.isEmpty()) {
            kmBox.addView(Ui.text(this, "Aucune course ce mois. Touche « J'accepte » sur la tuile pour lancer le compteur.", 14f, Ui.MUTED))
        } else {
            val liste = Ui.vertical(this, 8)
            val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
            val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
            rides.take(60).forEach { r2 ->
                val t = Ui.vertical(this).apply {
                    addView(Ui.text(this@MainActivity,
                        (if (r2.prive) "Client privé · " else "") +
                        "${fmt.format(Date(r2.debut))} → ${h.format(Date(r2.fin))} · ${r2.minTotal.roundToInt()} min · ${Analyzer.fmt2(r2.kmTotal)} km", 15f, Ui.FG, true))
                    if (r2.prive && r2.prix <= 0) addView(Ui.text(this@MainActivity, "Touche pour saisir le montant", 13f, Ui.WARN))
                    if (r2.prive) setOnClickListener { askPrice(r2) }
                    if (r2.lieuPrise.isNotEmpty() || r2.lieuArrivee.isNotEmpty()) addView(Ui.text(this@MainActivity,
                        "${r2.lieuPrise.substringBefore(" (")} → ${r2.lieuArrivee.substringBefore(" (")}", 13f, Ui.FG))
                    addView(Ui.text(this@MainActivity,
                        "approche ${r2.minApproche.roundToInt()} min ${Analyzer.fmt1(r2.kmApproche)} km · course ${r2.minCourse.roundToInt()} min ${Analyzer.fmt1(r2.kmCourse)} km" +
                            (if (r2.prix > 0) " · ${Analyzer.fmt2(r2.prix)} $d" else ""), 13f, Ui.MUTED))
                    setOnLongClickListener {
                        val now = System.currentTimeMillis()
                        if (now - deleteArm < 3000) { store.deleteRide(r2.debut); deleteArm = 0; drawKm()
                            Toast.makeText(this@MainActivity, "Course supprimée", Toast.LENGTH_SHORT).show() }
                        else { deleteArm = now
                            Toast.makeText(this@MainActivity, "Appui long encore une fois pour supprimer cette course", Toast.LENGTH_SHORT).show() }
                        true
                    }
                }
                liste.addView(t)
            }
            kmBox.addView(Ui.details(this, "Courses du mois (${rides.size})", liste))
        }
        val calT = java.util.Calendar.getInstance()
        val trajetsMois = store.trajets().filter {
            calT.timeInMillis = it.debut
            it.statut != Trajet.A_CLASSER && calT.get(java.util.Calendar.YEAR) == vueAnnee && calT.get(java.util.Calendar.MONTH) + 1 == vueMois
        }
        if (trajetsMois.isNotEmpty()) {
            val lt = Ui.vertical(this, 10)
            trajetsMois.forEach { lt.addView(ligneTrajet(it)) }
            kmBox.addView(Ui.details(this, "Trajets automatiques du mois (${trajetsMois.size})", lt))
        }
    }
}
