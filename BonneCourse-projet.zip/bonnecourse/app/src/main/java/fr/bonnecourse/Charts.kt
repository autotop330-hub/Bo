package fr.bonnecourse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import kotlin.math.ceil
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

/**
 * Colonnes empilées : ce qui a été encaissé chaque mois, par source (Uber, Bolt, Privé…).
 * Couleur = source (toujours la même), total au-dessus de chaque colonne, mois choisi en clair.
 * Toucher une colonne choisit ce mois.
 */
class ColonnesEmpilees(
    ctx: Context,
    private val etiquettes: List<String>,
    private val sources: List<String>,
    private val valeurs: List<Map<String, Double>>,
    private val choisi: Int,
    private val onChoix: (Int) -> Unit
) : View(ctx) {
    private val dp = ctx.resources.displayMetrics.density
    private val remplissage = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grille = Paint().apply { color = Ui.LINE; strokeWidth = 1f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11 * dp; color = Ui.MUTED }
    private val total = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12 * dp; color = Ui.FG; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }

    private fun pasRond(maxi: Double): Double {
        if (maxi <= 0) return 100.0
        val brut = maxi / 3
        val p = 10.0.pow(kotlin.math.floor(log10(brut)))
        return listOf(1.0, 2.0, 2.5, 5.0, 10.0).map { it * p }.first { it >= brut }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val n = etiquettes.size
        if (n == 0) return
        val gauche = 40 * dp; val bas = 22 * dp; val haut = 20 * dp
        val hUtile = height - bas - haut
        val maxi = valeurs.maxOfOrNull { it.values.sum() } ?: 0.0
        val pas = pasRond(maxi)
        val plafond = max(pas, ceil(maxi / pas) * pas)
        // Grille discrète
        var v = 0.0
        while (v <= plafond + 0.1) {
            val y = (height - bas - v / plafond * hUtile).toFloat()
            c.drawLine(gauche, y, width.toFloat(), y, grille)
            c.drawText(if (v >= 1000) "${(v / 1000).let { if (it % 1.0 == 0.0) it.toInt().toString() else String.format("%.1f", it) }}k" else "${v.toInt()}", 2 * dp, y + 4 * dp, txt)
            v += pas
        }
        val larg = (width - gauche) / n
        val barre = minOf(larg * 0.56f, 34 * dp)
        val ecart = 2 * dp
        for (i in 0 until n) {
            val cx = gauche + larg * i + larg / 2
            var y = height - bas
            val segs = sources.map { it to (valeurs[i][it] ?: 0.0) }.filter { it.second > 0 }
            segs.forEachIndexed { k, (s, montant) ->
                val h = (montant / plafond * hUtile).toFloat()
                val dernier = k == segs.size - 1
                val r = RectF(cx - barre / 2, y - h + (if (k > 0) ecart else 0f), cx + barre / 2, y)
                remplissage.color = W.couleurSource(s)
                remplissage.alpha = if (i == choisi) 255 else 150
                if (dernier && r.height() > 4 * dp) {
                    // Haut arrondi (4 dp), base droite posée sur l'axe
                    val p = Path(); val rr = 4 * dp
                    p.addRoundRect(r, floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f), Path.Direction.CW)
                    c.drawPath(p, remplissage)
                } else c.drawRect(r, remplissage)
                y -= h
            }
            val somme = valeurs[i].values.sum()
            if (somme > 0) c.drawText(W.eur(somme).replace(" €", ""), cx, y - 5 * dp, total.apply { color = if (i == choisi) Ui.FG else Ui.MUTED })
            val lab = Paint(txt).apply {
                textAlign = Paint.Align.CENTER
                color = if (i == choisi) Ui.FG else Ui.MUTED
                typeface = if (i == choisi) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            c.drawText(etiquettes[i], cx, height - 6 * dp, lab)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val gauche = 40 * dp
            val i = ((e.x - gauche) / ((width - gauche) / etiquettes.size)).toInt()
            if (i in etiquettes.indices && i != choisi) onChoix(i)
        }
        return true
    }
}

/** Barres horizontales : une ligne par poste (libellé et montant en texte, barre proportionnelle). */
object Barres {
    fun vue(ctx: Context, lignes: List<Triple<String, Double, Boolean>>, couleur: Int = W.couleurSource("Uber")): View {
        val col = Ui.vertical(ctx, 10)
        val maxi = lignes.maxOfOrNull { it.second } ?: 0.0
        lignes.forEach { (nom, montant, estime) ->
            val bloc = Ui.vertical(ctx, 4)
            bloc.addView(W.ligne(ctx, nom + if (estime) " (estimé)" else "", W.eur(montant)))
            val piste = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val part = if (maxi > 0) (montant / maxi).toFloat().coerceIn(0.02f, 1f) else 0f
            piste.addView(View(ctx).apply {
                background = Ui.box(ctx, couleur, couleur, 0, 4)
                alpha = if (estime) 0.45f else 1f
            }, LinearLayout.LayoutParams(0, Ui.dp(ctx, 8), part))
            if (part < 1f) piste.addView(View(ctx), LinearLayout.LayoutParams(0, Ui.dp(ctx, 8), 1f - part))
            bloc.addView(piste, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            col.addView(bloc)
        }
        return col
    }
}
