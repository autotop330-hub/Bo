package fr.bonnecourse

import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Lieu favori, façon Driversnote : « Gare Saint-Roch », « Aéroport », « Superchargeur Odysseum »…
 * Il donne son nom aux trajets et aide à les classer : un lieu « pro » rend pro le trajet qui y va ou en part.
 */
data class Favori(val id: String, val nom: String, val lat: Double, val lon: Double, val type: String = PRO) {
    companion object {
        const val PRO = "pro"
        const val PERSO = "perso"
        const val RAYON_M = 150.0

        fun liste(s: String?): List<Favori> = try {
            val a = JSONArray(s ?: "[]")
            (0 until a.length()).map { val o = a.getJSONObject(it)
                Favori(o.getString("id"), o.getString("nom"), o.getDouble("lat"), o.getDouble("lon"), o.optString("type", PRO)) }
        } catch (_: Exception) { emptyList() }

        fun texte(l: List<Favori>) = JSONArray().apply {
            l.forEach { put(JSONObject().put("id", it.id).put("nom", it.nom).put("lat", it.lat).put("lon", it.lon).put("type", it.type)) }
        }.toString()
    }
}

/** Heures de travail : en dehors de la bulle, un trajet dans ces heures est pro, sinon perso. */
data class HeuresTravail(val actif: Boolean, val jours: Set<Int>, val debut: Int, val fin: Int) {
    /** Le moment [t] est-il dans les heures de travail ? (plage de nuit acceptée : 18 h → 4 h) */
    fun contient(t: Long): Boolean {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val jour = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 + 1          // lundi = 1 … dimanche = 7
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return if (debut <= fin) jour in jours && m in debut until fin
        else (jour in jours && m >= debut) || (((jour + 5) % 7 + 1) in jours && m < fin)   // après minuit : jour de la veille
    }

    fun texte(): String {
        val noms = listOf("lun", "mar", "mer", "jeu", "ven", "sam", "dim")
        val j = when (jours) { (1..7).toSet() -> "tous les jours"; (1..5).toSet() -> "du lundi au vendredi"; (1..6).toSet() -> "du lundi au samedi"
            else -> jours.sorted().joinToString(", ") { noms[it - 1] } }
        fun h(x: Int) = String.format("%02d:%02d", x / 60, x % 60)
        return "$j, de ${h(debut)} à ${h(fin)}"
    }
}

/**
 * Classement intelligent des trajets détectés (bulle arrêtée), du plus sûr au moins sûr :
 *  1. départ ou arrivée à un lieu favori : son type (pro / perso) ;
 *  2. le même trajet a déjà été classé au moins 2 fois de la même façon : on refait pareil ;
 *  3. heures de travail réglées : dedans = pro, dehors = perso.
 * Sinon le trajet reste « à classer » (notification Pro / Perso, ou glisser dans le journal).
 */
object Classement {

    /** « Rue X, Ville (43.61,3.87) » ou « 43.61,3.87 » → coordonnées. */
    fun coord(s: String): Pair<Double, Double>? {
        val brut = if (s.endsWith(")") && "(" in s) s.substringAfterLast("(").removeSuffix(")") else s
        val p = brut.split(",")
        if (p.size != 2) return null
        val la = p[0].trim().toDoubleOrNull() ?: return null
        val lo = p[1].trim().toDoubleOrNull() ?: return null
        return if (la in -90.0..90.0 && lo in -180.0..180.0) la to lo else null
    }

    fun favoriProche(favoris: List<Favori>, c: Pair<Double, Double>?, rayon: Double = Favori.RAYON_M): Favori? {
        c ?: return null
        return favoris.map { it to Odometer.distanceM(c.first, c.second, it.lat, it.lon) }
            .filter { it.second <= rayon }.minByOrNull { it.second }?.first
    }

    /** Nom à afficher pour un lieu : le favori s'il est tout près, sinon le nom de rue déjà trouvé. */
    fun nomLieu(favoris: List<Favori>, lieu: String): String {
        val f = favoriProche(favoris, coord(lieu)) ?: return lieu
        val c = coord(lieu) ?: return f.nom
        return String.format(java.util.Locale.US, "%s (%.5f,%.5f)", f.nom, c.first, c.second)
    }

    private fun proches(a: Pair<Double, Double>?, b: Pair<Double, Double>?, m: Double) =
        a != null && b != null && Odometer.distanceM(a.first, a.second, b.first, b.second) <= m

    /** (statut, raison) proposé pour [t], ou null si rien de sûr. */
    fun proposer(t: Trajet, favoris: List<Favori>, historique: List<Trajet>, heures: HeuresTravail,
                 domicile: Pair<Double, Double>?): Pair<String, String>? {
        val de = coord(t.depart); val a = coord(t.arrivee)
        val tous = favoris.filter { it.id != "domicile" } + listOfNotNull(domicile?.let { Favori("domicile", "Domicile", it.first, it.second, Favori.PERSO) })
        val fA = favoriProche(tous, a); val fD = favoriProche(tous, de)
        // 1. Lieu favori pro (gare, aéroport, borne…) au départ ou à l'arrivée
        val pro = listOfNotNull(fA, fD).firstOrNull { it.type == Favori.PRO }
        if (pro != null) return Trajet.PRO to (if (pro == fA) "vers ${pro.nom}" else "depuis ${pro.nom}")
        // 2. Même trajet déjà classé (dans un sens ou dans l'autre)
        val pareils = historique.filter { h -> h.debut != t.debut && h.statut != Trajet.A_CLASSER &&
            ((proches(coord(h.depart), de, 300.0) && proches(coord(h.arrivee), a, 300.0)) ||
             (proches(coord(h.depart), a, 300.0) && proches(coord(h.arrivee), de, 300.0))) }
        if (pareils.size >= 2) {
            val (statut, n) = pareils.groupingBy { it.statut }.eachCount().maxByOrNull { it.value }!!
            if (n >= 2 && n * 3 >= pareils.size * 2) return statut to "comme tes $n trajets précédents"
        }
        // 3. Heures de travail
        if (heures.actif) return if (heures.contient(t.debut)) Trajet.PRO to "heures de travail" else Trajet.PERSO to "hors heures de travail"
        // Lieux perso des deux côtés (domicile → favori perso)
        if (fA?.type == Favori.PERSO && fD?.type == Favori.PERSO && fA != fD) return Trajet.PERSO to "${fD.nom} → ${fA.nom}"
        return null
    }
}
