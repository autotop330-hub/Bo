package fr.bonnecourse

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.ActivityTransitionResult
import com.google.android.gms.location.DetectedActivity
import java.util.Locale

/**
 * Détection automatique des trajets, façon Driversnote :
 * le téléphone signale « en voiture » → on enregistre le trajet au GPS → à l'arrivée,
 * une notification demande « Pro ou Perso ? ».
 * Rien ne se passe pendant que la bulle est lancée : elle compte déjà les km du service.
 */
object AutoDetection {
    private const val ACTION = "fr.bonnecourse.TRANSITION"

    private fun pendingIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 42, Intent(ctx, TransitionReceiver::class.java).setAction(ACTION),
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
    )

    fun autorise(ctx: Context): Boolean {
        fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
        return ok(Manifest.permission.ACCESS_FINE_LOCATION) &&
            (Build.VERSION.SDK_INT < 29 || (ok(Manifest.permission.ACTIVITY_RECOGNITION) && ok(Manifest.permission.ACCESS_BACKGROUND_LOCATION)))
    }

    @SuppressLint("MissingPermission")
    fun activer(ctx: Context) {
        if (!autorise(ctx)) return
        val transitions = listOf(ActivityTransition.ACTIVITY_TRANSITION_ENTER, ActivityTransition.ACTIVITY_TRANSITION_EXIT).map {
            ActivityTransition.Builder().setActivityType(DetectedActivity.IN_VEHICLE).setActivityTransition(it).build()
        }
        try {
            ActivityRecognition.getClient(ctx).requestActivityTransitionUpdates(ActivityTransitionRequest(transitions), pendingIntent(ctx))
        } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    fun desactiver(ctx: Context) {
        try { ActivityRecognition.getClient(ctx).removeActivityTransitionUpdates(pendingIntent(ctx)) } catch (_: Exception) {}
        if (TrackService.running) ctx.startService(Intent(ctx, TrackService::class.java).setAction(TrackService.ACTION_STOP))
    }
}

/** Reçoit « monté en voiture » / « sorti de la voiture ». */
class TransitionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (!ActivityTransitionResult.hasResult(intent)) return
        val res = ActivityTransitionResult.extractResult(intent) ?: return
        if (!Store(ctx).autoTrajets) return
        for (e in res.transitionEvents) {
            if (e.activityType != DetectedActivity.IN_VEHICLE) continue
            val action = if (e.transitionType == ActivityTransition.ACTIVITY_TRANSITION_ENTER) {
                if (BubbleService.running) continue                 // la bulle compte déjà
                if (TrackService.running) TrackService.ACTION_EN_VOITURE else TrackService.ACTION_START
            } else {
                if (!TrackService.running) continue
                TrackService.ACTION_SORTIE
            }
            val i = Intent(ctx, TrackService::class.java).setAction(action)
            try {
                if (action == TrackService.ACTION_START) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
            } catch (_: Exception) {}
        }
    }
}

/** Après un redémarrage du téléphone, on réactive la détection. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Store(ctx).autoTrajets) AutoDetection.activer(ctx)
    }
}

/** Boutons « Pro » / « Perso » de la notification de fin de trajet. */
class TrajetActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val debut = intent.getLongExtra("debut", 0L)
        val statut = intent.getStringExtra("statut") ?: return
        Store(ctx).classer(debut, statut)
        NotificationManagerCompat.from(ctx).cancel(TrackService.notifId(debut))
    }
}

/** Nom de rue et de ville à partir de coordonnées « lat,lon ». */
object Lieux {
    fun nom(ctx: Context, coord: String): String {
        if (coord.isEmpty() || !Geocoder.isPresent()) return coord
        return try {
            val (la, lo) = coord.split(",").map { it.toDouble() }
            @Suppress("DEPRECATION")
            val a = Geocoder(ctx, Locale.FRANCE).getFromLocation(la, lo, 1)?.firstOrNull() ?: return coord
            val n = listOfNotNull(a.thoroughfare, a.locality ?: a.subAdminArea).joinToString(", ")
            if (n.isBlank()) coord else "$n ($coord)"
        } catch (_: Exception) { coord }
    }
}

/** Enregistre un trajet détecté automatiquement, en service de premier plan (obligatoire pour le GPS). */
class TrackService : Service() {

    companion object {
        const val ACTION_START = "fr.bonnecourse.TRAJET_START"
        const val ACTION_STOP = "fr.bonnecourse.TRAJET_STOP"
        const val ACTION_SORTIE = "fr.bonnecourse.TRAJET_SORTIE"
        const val ACTION_EN_VOITURE = "fr.bonnecourse.TRAJET_EN_VOITURE"
        private const val NOTIF_EN_COURS = 8
        private const val CANAL_EN_COURS = "trajet_en_cours"
        private const val CANAL_FIN = "trajet_fini"
        @Volatile var running = false
        fun notifId(debut: Long) = (1000 + (debut / 1000 % 1_000_000)).toInt()
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: Enregistreur? = null
    private var gps = false
    private val verif = object : Runnable {
        override fun run() {
            val r = rec ?: return
            if (r.termine(System.currentTimeMillis())) { finir(); return }
            majNotif(r.km)
            main.postDelayed(this, 30_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private val ecoute = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            rec?.position(l.latitude, l.longitude, l.accuracy, l.time, if (l.hasSpeed()) l.speed else null)
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (rec != null) return START_NOT_STICKY
                canaux()
                ServiceCompat.startForeground(this, NOTIF_EN_COURS, notifEnCours(0.0),
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    stopSelf(); return START_NOT_STICKY
                }
                rec = Enregistreur(System.currentTimeMillis())
                try {
                    (getSystemService(Context.LOCATION_SERVICE) as LocationManager)
                        .requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 0f, ecoute, Looper.getMainLooper())
                    gps = true
                } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
                running = true
                main.postDelayed(verif, 30_000)
            }
            ACTION_SORTIE -> rec?.sortieVoiture(System.currentTimeMillis())
            ACTION_EN_VOITURE -> rec?.enVoiture()
            ACTION_STOP -> finir()
        }
        return START_NOT_STICKY
    }

    private fun finir() {
        main.removeCallbacks(verif)
        val t = rec?.trajet()
        rec = null
        if (gps) { (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(ecoute); gps = false }
        if (t != null) {
            val app = applicationContext
            Thread {
                val nomme = t.copy(depart = Lieux.nom(app, t.depart), arrivee = Lieux.nom(app, t.arrivee))
                Store(app).addTrajet(nomme)
                notifFin(app, nomme)
            }.start()
        }
        running = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun canaux() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CANAL_EN_COURS, "Trajet en cours", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CANAL_FIN, "Trajets à classer", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun ouvrirAppli() = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun notifEnCours(km: Double) = NotificationCompat.Builder(this, CANAL_EN_COURS)
        .setSmallIcon(R.drawable.ic_launcher_fg)
        .setContentTitle("Trajet en cours")
        .setContentText("${Analyzer.fmt1(km)} km · enregistré automatiquement")
        .setContentIntent(ouvrirAppli())
        .setOngoing(true)
        .build()

    private fun majNotif(km: Double) {
        try { NotificationManagerCompat.from(this).notify(NOTIF_EN_COURS, notifEnCours(km)) } catch (_: SecurityException) {}
    }

    private fun notifFin(ctx: Context, t: Trajet) {
        fun action(statut: String, code: Int) = PendingIntent.getBroadcast(ctx, code + (t.debut % 100_000).toInt(),
            Intent(ctx, TrajetActionReceiver::class.java).putExtra("debut", t.debut).putExtra("statut", statut),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val de = t.depart.substringBefore(" (").substringAfter(", ", t.depart.substringBefore(" ("))
        val a = t.arrivee.substringBefore(" (").substringAfter(", ", t.arrivee.substringBefore(" ("))
        val n = NotificationCompat.Builder(ctx, CANAL_FIN)
            .setSmallIcon(R.drawable.ic_launcher_fg)
            .setContentTitle("Trajet de ${Analyzer.fmt1(t.km)} km · pro ou perso ?")
            .setContentText(listOf(de, a).filter { it.isNotBlank() }.joinToString(" → ").ifBlank { "${t.minutes.toInt()} min" })
            .setContentIntent(ouvrirAppli())
            .addAction(0, "Pro", action(Trajet.PRO, 1))
            .addAction(0, "Perso", action(Trajet.PERSO, 2))
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(notifId(t.debut), n) } catch (_: SecurityException) {}
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        if (gps) { (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(ecoute); gps = false }
        super.onDestroy()
    }
}
