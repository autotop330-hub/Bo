package fr.bonnecourse

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Onglet « Courses » : la boîte noire du mois, jour par jour.
 * Chaque journée = carnet kilométrique : départ du domicile, courses (approche + client à bord), retour au domicile.
 * Suppression : appui long sur une ligne, corbeille du détail, ou « Sélectionner » pour en supprimer plusieurs.
 */
class EcranCourses(private val a: MainActivity) {
    private val store = a.store
    private val jourCle = SimpleDateFormat("yyyyMMdd", Locale.FRANCE)

    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Boîte noire"))
        col.addView(a.navMois())
        val tout = store.rides().filter { a.duMois(it.debut) }
        val sources = listOf("Toutes") + tout.map { it.source }.distinct().sortedBy { listOf("Uber", "Bolt", "Privé").indexOf(it).let { i -> if (i < 0) 9 else i } }
        if (a.filtreSource !in sources) a.filtreSource = "Toutes"
        if (sources.size > 2) col.addView(filtres(sources))
        val rs = tout.filter { a.filtreSource == "Toutes" || it.source == a.filtreSource }
        val sgs = if (a.filtreSource == "Toutes") store.segments().filter { a.duMois(it.debut) } else emptyList()
        val sel = a.selection

        // Résumé du mois
        val resume = W.carte(a)
        resume.addView(W.hero(a, W.eur2(rs.sumOf { it.prix }), "${rs.size} course${if (rs.size > 1) "s" else ""} ce mois"))
        resume.addView(Ui.buttonRow(a,
            W.chiffreKm(a, "Approche", rs.sumOf { it.kmApproche }, Ui.WARN),
            W.chiffreKm(a, "Client", rs.sumOf { it.kmCourse }, Ui.GO),
            W.chiffreKm(a, "Domicile", sgs.sumOf { it.km }, Ui.ACCENT)))
        val aSigner = rs.count { it.prive && it.facture.isBlank() }
        if (aSigner > 0) resume.addView(Ui.text(a, "$aSigner course${if (aSigner > 1) "s" else ""} privée${if (aSigner > 1) "s" else ""} à faire signer", 14f, Ui.WARN, true))
        if (sel == null && (rs.isNotEmpty() || sgs.isNotEmpty()))
            resume.addView(W.bouton(a, "Sélectionner pour supprimer") { a.selection = mutableSetOf(); a.afficher() })
        col.addView(resume)

        // Mode sélection : barre d'action en haut de la liste
        if (sel != null) col.addView(barreSelection(sel, rs, sgs))

        if (rs.isEmpty() && sgs.isEmpty()) {
            col.addView(W.aide(a, "Aucune course ce mois. Elles s'ajoutent quand tu touches « J'accepte » sur la tuile, ou avec une course privée."))
        } else {
            val jourF = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)
            val jours = (rs.map { jourCle.format(Date(it.debut)) } + sgs.map { jourCle.format(Date(it.debut)) }).distinct().sortedDescending()
            jours.forEach { j ->
                val rj = rs.filter { jourCle.format(Date(it.debut)) == j }
                val sj = sgs.filter { jourCle.format(Date(it.debut)) == j }
                val premier = (rj.map { it.debut } + sj.map { it.debut }).min()
                val c = Ui.vertical(a, 8)
                c.addView(W.ligne(a, jourF.format(Date(premier)).replaceFirstChar { it.uppercase() }, W.eur2(rj.sumOf { it.prix }), true, Ui.ACCENT).apply {
                    setPadding(Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4), 0)
                })
                val kmJour = rj.sumOf { it.kmTotal } + sj.sumOf { it.km }
                c.addView(W.aide(a, "${Analyzer.fmt1(kmJour)} km pro enregistrés" +
                    (if (sj.isNotEmpty()) " dont ${Analyzer.fmt1(sj.sumOf { it.km })} km domicile" else "")).apply { setPadding(Ui.dp(a, 4), 0, 0, 0) })
                // Ordre chronologique dans la journée : départ, courses, retour
                val lignes = rj.map { it.debut to ligne(it, sel) } + sj.map { it.debut to ligneSegment(it, sel) }
                lignes.sortedBy { it.first }.forEach { c.addView(it.second) }
                col.addView(c)
            }
        }
        col.addView(W.aide(a, "Toucher : détail et carte. Appui long : supprimer."))
        col.addView(W.bouton(a, "Exporter le mois (tableur)") {
            a.exporter(String.format("courses-%04d-%02d.csv", a.vueAnnee, a.vueMois)) { EcranMois(a).csvMois() }
        })
    }

    private fun filtres(sources: List<String>): View = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        sources.forEachIndexed { i, s ->
            val actif = s == a.filtreSource
            addView(Ui.text(a, s, 14f, if (actif) Ui.BG else Ui.FG, true).apply {
                gravity = Gravity.CENTER
                val p = Ui.dp(a, 9); setPadding(p, p, p, p)
                val coul = if (s == "Toutes") Ui.ACCENT else W.couleurSource(s)
                background = Ui.box(a, if (actif) coul else Ui.SURFACE, if (actif) coul else Ui.LINE, 1, 22)
                setOnClickListener { a.filtreSource = s; a.afficher() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = Ui.dp(a, 6) })
        }
    }

    // ---------------------------------------------------------------- Lignes

    /** Case de sélection ronde (mode « Sélectionner »). */
    private fun caseSel(coche: Boolean, possible: Boolean): View = View(a).apply {
        background = if (!possible) Ui.box(a, Ui.RAISE, Ui.LINE, 1, 12)
        else if (coche) Ui.box(a, Ui.STOP, Ui.STOP, 0, 12) else Ui.box(a, Ui.RAISE, Ui.MUTED, 2, 12)
        layoutParams = LinearLayout.LayoutParams(Ui.dp(a, 24), Ui.dp(a, 24)).apply { marginEnd = Ui.dp(a, 12) }
    }

    private fun basculer(sel: MutableSet<String>, cle: String) {
        if (!sel.remove(cle)) sel += cle
        a.afficher()
    }

    /** Une course : heure, plateforme, lieux, km d'approche et avec client ; montant à droite. */
    private fun ligne(r: Ride, sel: MutableSet<String>?): View {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val cle = "r${r.debut}"
        val possible = r.facture.isBlank()
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.box(a, Ui.RAISE, if (sel?.contains(cle) == true) Ui.STOP else Ui.RAISE, 1, 18)
            val p = Ui.dp(a, 14); setPadding(p, p, Ui.dp(a, 8), p)
        }
        if (sel != null) l.addView(caseSel(cle in sel, possible))
        val t = Ui.vertical(a, 5)
        t.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(Ui.text(a, "${h.format(Date(r.debut))} → ${h.format(Date(r.fin))}", 16f, Ui.FG, true))
            addView(W.puce(a, r.source, W.couleurSource(r.source)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = Ui.dp(a, 10) })
        })
        val lieux = listOf(r.lieuPrise, r.lieuArrivee).map { it.substringBefore(" (").substringAfterLast(", ") }.filter { it.isNotBlank() && !it[0].isDigit() }
        if (lieux.isNotEmpty()) t.addView(Ui.text(a, lieux.joinToString("  →  "), 14f).apply { maxLines = 2 })
        t.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            if (!r.manuelle && r.kmApproche > 0) addView(W.pastille(a, Ui.WARN, "${Analyzer.fmt2(r.kmApproche)} km", 12f),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(a, 12) })
            addView(W.pastille(a, Ui.GO, "${Analyzer.fmt2(r.kmCourse)} km", 12f),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(a, 12) })
            addView(Ui.text(a, "${r.minTotal.roundToInt()} min" + if (r.manuelle) " · à la main" else "", 12f, Ui.MUTED))
        })
        when {
            r.prive && r.facture.isBlank() && store.dejaSignee(r.debut) -> t.addView(Ui.text(a, "Signée · facture à finir", 13f, Ui.WARN, true))
            r.prive && r.facture.isBlank() -> t.addView(Ui.text(a, "À faire signer", 13f, Ui.WARN, true))
            r.facture.isNotBlank() -> t.addView(Ui.text(a, "✓ Facture ${r.facture}", 13f, Ui.GO))
        }
        l.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, if (r.prix > 0) W.eur2(r.prix) else "—", 17f, Ui.FG, true).apply { setPadding(Ui.dp(a, 8), 0, 0, 0) })
        if (sel == null) l.addView(W.icone(a, R.drawable.ic_chevron, Ui.MUTED, 20))
        l.setOnClickListener {
            if (sel != null) { if (possible) basculer(sel, cle) else a.toast("Course facturée : elle ne se supprime pas.") }
            else a.ouvrirCourse(r)
        }
        l.setOnLongClickListener { supprimer(r); true }
        return l
    }

    /** Trajet domicile ↔ service (carnet kilométrique). */
    private fun ligneSegment(sg: Segment, sel: MutableSet<String>?): View {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val cle = "s${sg.debut}"
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.box(a, Ui.SURFACE, if (sel?.contains(cle) == true) Ui.STOP else Ui.LINE, 1, 18)
            val p = Ui.dp(a, 14); setPadding(p, Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12))
        }
        if (sel != null) l.addView(caseSel(cle in sel, true))
        else l.addView(W.icone(a, R.drawable.ic_rouler, Ui.ACCENT, 20).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = Ui.dp(a, 12)
        })
        val t = Ui.vertical(a, 3)
        t.addView(Ui.text(a, "${sg.nom} · ${h.format(Date(sg.debut))} → ${h.format(Date(sg.fin))}", 15f, Ui.FG, true))
        t.addView(W.aide(a, "${sg.minutes.roundToInt()} min · " + listOf(sg.lieuDepart, sg.lieuArrivee)
            .map { it.substringBefore(" (").substringAfterLast(", ") }.filter { it.isNotBlank() && !it[0].isDigit() }.joinToString(" → ")))
        l.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, "${Analyzer.fmt2(sg.km)} km", 15f, Ui.ACCENT, true).apply { setPadding(Ui.dp(a, 8), 0, 0, 0) })
        if (sel == null) l.addView(W.icone(a, R.drawable.ic_chevron, Ui.MUTED, 20))
        l.setOnClickListener { if (sel != null) basculer(sel, cle) else a.ouvrirSegment(sg) }
        l.setOnLongClickListener {
            W.confirmer(a, "Supprimer ce trajet ?", "${sg.nom} · ${Analyzer.fmt2(sg.km)} km. C'est définitif.", "Supprimer") {
                store.deleteSegment(sg.debut); a.toast("Trajet supprimé"); a.afficher()
            }; true
        }
        return l
    }

    // ---------------------------------------------------------------- Suppression

    private fun barreSelection(sel: MutableSet<String>, rs: List<Ride>, sgs: List<Segment>): View {
        val c = W.carte(a)
        c.addView(Ui.text(a, if (sel.isEmpty()) "Touche les courses à supprimer" else "${sel.size} sélectionnée${if (sel.size > 1) "s" else ""}", 16f, Ui.FG, true))
        val tout = rs.filter { it.facture.isBlank() }.map { "r${it.debut}" } + sgs.map { "s${it.debut}" }
        c.addView(Ui.buttonRow(a,
            W.bouton(a, if (sel.containsAll(tout) && tout.isNotEmpty()) "Tout désélectionner" else "Tout le mois") {
                if (sel.containsAll(tout)) sel.clear() else sel.addAll(tout); a.afficher()
            },
            W.bouton(a, "Annuler") { a.selection = null; a.afficher() }))
        if (sel.isNotEmpty()) c.addView(W.boutonDanger(a, "Supprimer (${sel.size})") {
            W.confirmer(a, "Supprimer ${sel.size} élément${if (sel.size > 1) "s" else ""} ?",
                "Les courses disparaissent de la boîte noire, avec leur tracé GPS, et du chiffre d'affaires. C'est définitif.", "Supprimer") {
                sel.forEach { k ->
                    val t = k.drop(1).toLong()
                    if (k[0] == 'r') { store.deleteRide(t); store.supprimerBrouillon(t) } else store.deleteSegment(t)
                }
                a.toast("${sel.size} supprimé${if (sel.size > 1) "s" else ""}")
                a.selection = null; a.afficher()
            }
        })
        if (rs.any { it.facture.isNotBlank() }) c.addView(W.aide(a, "Les courses facturées ne se suppriment pas."))
        return c
    }

    private fun supprimer(r: Ride) {
        if (r.facture.isNotBlank()) {
            a.toast("Course facturée (${r.facture}) : une facture ne se supprime pas.")
            return
        }
        val h = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        W.confirmer(a, "Supprimer cette course ?",
            "${h.format(Date(r.debut))} · ${r.source} · ${if (r.prix > 0) W.eur2(r.prix) else "sans montant"}\n\n" +
                "Elle disparaît de la boîte noire, avec son tracé GPS, et du chiffre d'affaires. C'est définitif.", "Supprimer") {
            store.deleteRide(r.debut); store.supprimerBrouillon(r.debut)
            a.toast("Course supprimée"); a.afficher()
        }
    }
}
