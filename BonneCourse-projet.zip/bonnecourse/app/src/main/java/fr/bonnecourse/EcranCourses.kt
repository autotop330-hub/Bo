package fr.bonnecourse

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Onglet « Courses » : la boîte noire du mois, jour par jour. */
class EcranCourses(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Boîte noire"))
        col.addView(a.navMois())
        val tout = store.rides().filter { a.duMois(it.debut) }
        val sources = listOf("Toutes") + tout.map { it.source }.distinct().sortedBy { listOf("Uber", "Bolt", "Privé").indexOf(it).let { i -> if (i < 0) 9 else i } }
        if (a.filtreSource !in sources) a.filtreSource = "Toutes"
        if (sources.size > 2) col.addView(filtres(sources))
        val rs = tout.filter { a.filtreSource == "Toutes" || it.source == a.filtreSource }.sortedByDescending { it.debut }

        val resume = W.carte(a)
        resume.addView(W.hero(a, W.eur2(rs.sumOf { it.prix }), "${rs.size} course${if (rs.size > 1) "s" else ""} · ${Analyzer.fmt1(rs.sumOf { it.kmTotal })} km avec les approches"))
        val aSigner = rs.count { it.prive && it.facture.isBlank() }
        if (aSigner > 0) resume.addView(Ui.text(a, "$aSigner course${if (aSigner > 1) "s" else ""} privée${if (aSigner > 1) "s" else ""} à faire signer", 14f, Ui.WARN, true))
        resume.addView(W.aide(a, "Chaque course est enregistrée à la seconde, avec les lieux et le tracé GPS. Touche une course pour la voir sur la carte ; appui long pour la supprimer."))
        col.addView(resume)

        if (rs.isEmpty()) {
            col.addView(W.aide(a, "Aucune course ce mois. Elles s'ajoutent quand tu touches « J'accepte » sur la tuile, ou avec une course privée."))
        } else {
            val jourF = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)
            rs.groupBy { SimpleDateFormat("yyyyMMdd", Locale.FRANCE).format(Date(it.debut)) }.forEach { (_, l) ->
                val c = Ui.vertical(a, 8)
                c.addView(W.ligne(a, jourF.format(Date(l.first().debut)).replaceFirstChar { it.uppercase() }, W.eur2(l.sumOf { it.prix }), true, Ui.ACCENT).apply {
                    setPadding(Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 4), 0)
                })
                l.forEach { c.addView(ligne(it)) }
                col.addView(c)
            }
        }
        col.addView(W.bouton(a, "Exporter le mois (tableur)") {
            a.exporter(String.format("courses-%04d-%02d.csv", a.vueAnnee, a.vueMois)) { EcranMois(a).csvMois() }
        })
    }

    private fun filtres(sources: List<String>): View = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL
        sources.forEachIndexed { i, s ->
            val actif = s == a.filtreSource
            addView(Ui.text(a, s, 14f, if (actif) Ui.BG else Ui.FG, true).apply {
                gravity = Gravity.CENTER
                val p = Ui.dp(a, 8); setPadding(p, p, p, p)
                val coul = if (s == "Toutes") Ui.ACCENT else W.couleurSource(s)
                background = Ui.box(a, if (actif) coul else Ui.RAISE, if (actif) coul else Ui.LINE, 1, 20)
                setOnClickListener { a.filtreSource = s; a.afficher() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = Ui.dp(a, 6) })
        }
    }

    /** Une course : heure, plateforme, lieux, km ; montant à droite. Toucher = détail, appui long = supprimer. */
    private fun ligne(r: Ride): View {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
            background = Ui.box(a, Ui.RAISE, Ui.RAISE, 0, 16)
            val p = Ui.dp(a, 14); setPadding(p, p, Ui.dp(a, 8), p)
        }
        val t = Ui.vertical(a, 4)
        t.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
            addView(Ui.text(a, "${h.format(Date(r.debut))} → ${h.format(Date(r.fin))}", 16f, Ui.FG, true))
            addView(W.puce(a, r.source, W.couleurSource(r.source)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = Ui.dp(a, 10) })
        })
        val lieux = listOf(r.lieuPrise, r.lieuArrivee).map { it.substringBefore(" (").substringAfterLast(", ") }.filter { it.isNotBlank() && !it[0].isDigit() }
        if (lieux.isNotEmpty()) t.addView(Ui.text(a, lieux.joinToString("  →  "), 14f).apply { maxLines = 2 })
        t.addView(W.aide(a, "${r.minTotal.roundToInt()} min · ${Analyzer.fmt1(r.kmTotal)} km" +
            (if (r.kmApproche > 0) " · ${Analyzer.fmt1(r.kmApproche)} km d'approche" else "") +
            (if (r.manuelle) " · saisie à la main" else "")))
        when {
            r.prive && r.facture.isBlank() && store.dejaSignee(r.debut) -> t.addView(Ui.text(a, "Signée · facture à finir", 13f, Ui.WARN, true))
            r.prive && r.facture.isBlank() -> t.addView(Ui.text(a, "À faire signer", 13f, Ui.WARN, true))
            r.facture.isNotBlank() -> t.addView(Ui.text(a, "✓ Facture ${r.facture}", 13f, Ui.GO))
        }
        l.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, if (r.prix > 0) W.eur2(r.prix) else "—", 17f, Ui.FG, true).apply { setPadding(Ui.dp(a, 8), 0, 0, 0) })
        l.addView(W.icone(a, R.drawable.ic_chevron, Ui.MUTED, 20))
        l.setOnClickListener { a.ouvrirCourse(r) }
        l.setOnLongClickListener { supprimer(r); true }
        return l
    }

    private fun supprimer(r: Ride) {
        if (r.facture.isNotBlank()) {
            a.toast("Course facturée (${r.facture}) : une facture ne se supprime pas.")
            return
        }
        val h = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        W.confirmer(a, "Supprimer cette course ?",
            "${h.format(Date(r.debut))} · ${r.source} · ${if (r.prix > 0) W.eur2(r.prix) else "sans montant"}\n\n" +
                "Elle disparaît de la boîte noire, avec son tracé GPS, et du chiffre d'affaires. C'est définitif.", "Supprimer") {
            store.deleteRide(r.debut); store.supprimerBrouillon(r.debut)
            a.toast("Course supprimée"); a.afficher()
        }
    }
}
