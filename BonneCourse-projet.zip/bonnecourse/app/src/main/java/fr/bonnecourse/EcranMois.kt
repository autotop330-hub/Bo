package fr.bonnecourse

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Onglet « Mon mois » : graphiques, net dans la poche, te payer au mieux, kilomètres, exports. */
class EcranMois(private val a: MainActivity) {
    private val store = a.store
    private val p = store.profile

    private fun net(): Pair<Finance.NetMois, Double> {
        val n = Finance.mois(store.rides(), store.service(), store.perso(), a.vueAnnee, a.vueMois, p, a.moisEcoules(), store.frais())
        // Même méthode que « Te payer au mieux » : le mois prend le taux de la meilleure option de l'année
        var net = n.meilleur
        activiteAnnee()?.let { act ->
            val o = Optimiseur.optimiser(act, p, store.situation, p.regime)
            if (o.annuel.resultat > 0)
                net = max(n.resultat, 0.0) * (o.recommande.net - o.recommande.bonusIk) / o.annuel.resultat + min(n.resultat, 0.0) + n.bonusIk
        }
        return n to net
    }

    /** L'année : prévision saisie, ou projection des vraies courses et des vrais frais. */
    private fun activiteAnnee(): Optimiseur.Activite? {
        val (pg, pk) = store.prevision
        if (pg > 0) return Optimiseur.Activite(pg * 12, 0.0, pk * 12)
        val now = Calendar.getInstance()
        val ecoules = now.get(Calendar.MONTH) + now.get(Calendar.DAY_OF_MONTH).toDouble() / now.getActualMaximum(Calendar.DAY_OF_MONTH)
        return Optimiseur.activiteDepuisDonnees(store.rides(), store.service(), store.perso(), now.get(Calendar.YEAR), ecoules, p, store.frais())
    }

    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Mon mois"))
        col.addView(a.navMois())
        val (n, net) = net()
        val b = n.base

        // L'essentiel
        val c = W.carteVedette(a, "Dans ta poche")
        c.addView(W.hero(a, W.eur(net), "ce mois, après TVA, frais, impôts et cotisations", if (net >= 0) Ui.FG else Ui.STOP))
        val frais = b.chargesVoiture + b.autresFrais
        c.addView(W.ligne(a, "Encaissé", W.eur(b.gains)))
        if (p.tva) c.addView(W.ligne(a, "TVA à reverser (nette)", "− " + W.eur(b.tvaNette)))
        c.addView(W.ligne(a, "Frais", "− " + W.eur(frais)))
        c.addView(W.ligne(a, "Impôts et cotisations", "− " + W.eur(b.gains - b.tvaNette - frais - net)))
        if (b.postes.any { it.estime }) c.addView(W.aide(a, "Une partie des frais est estimée : saisis-les dans l'onglet Frais pour un calcul exact."))
        col.addView(c)

        col.addView(graphiqueRevenus())
        if (b.postes.isNotEmpty()) {
            val g = W.carte(a, "Frais du mois par poste")
            g.addView(Barres.vue(a, b.postes.map { Triple(it.nom, it.ttc, it.estime) }, W.couleurSource("Privé")))
            col.addView(g)
        }
        col.addView(optimisation())
        col.addView(payerAuMieux())
        col.addView(kilometres())

        val ex = W.carte(a, "Pour le comptable")
        ex.addView(W.bouton(a, "Exporter le mois (tableur)", true) {
            a.exporter(String.format("bonne-course-%04d-%02d.csv", a.vueAnnee, a.vueMois)) { csvMois() }
        })
        ex.addView(W.aide(a, "Courses (heures, lieux, km, plateforme, factures), km par jour, frais et synthèse. S'ouvre dans Excel."))
        ex.addView(W.bouton(a, "Rapprocher un relevé Uber / Bolt (CSV)") { a.importerReleve() })
        ex.addView(W.aide(a, "Exporte ton relevé de gains depuis le site chauffeur : chaque paiement est comparé aux courses enregistrées."))
        col.addView(ex)
        col.addView(W.aide(a, "Estimation 2026, à valider avec ton comptable."))
    }

    /** Encaissé des 6 derniers mois par source. */
    private fun graphiqueRevenus(): View {
        val c = W.carte(a, "Encaissé sur 6 mois")
        val rides = store.rides()
        val mois = (5 downTo 0).map { k ->
            val cal = Calendar.getInstance().apply { set(a.vueAnnee, a.vueMois - 1, 1); add(Calendar.MONTH, -k) }
            cal.get(Calendar.YEAR) to cal.get(Calendar.MONTH) + 1
        }
        val valeurs = mois.map { (an, m) -> rides.filter { a.duMois(it.debut, an, m) }.groupBy { it.source }.mapValues { (_, l) -> l.sumOf { it.prix } } }
        val ordre = listOf("Uber", "Bolt", "Heetch", "FreeNow", "Plateforme", "Privé")
        val sources = ordre.filter { s -> valeurs.any { (it[s] ?: 0.0) > 0 } }
        if (sources.isEmpty()) { c.addView(W.aide(a, "Pas encore de course enregistrée sur ces mois.")); return c }
        val etiq = mois.map { (_, m) -> W.MOIS[m - 1].take(4).replaceFirstChar { it.uppercase() } }
        c.addView(ColonnesEmpilees(a, etiq, sources, valeurs, 5) { i -> a.allerAuMois(mois[i].first, mois[i].second) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 200)))
        // Légende (toujours là dès 2 sources) avec le montant du mois choisi
        val leg = Ui.vertical(a, 4)
        sources.forEach { s -> leg.addView(W.pastille(a, W.couleurSource(s), "$s  ${W.eur(valeurs[5][s] ?: 0.0)}", 14f)) }
        c.addView(leg)
        c.addView(W.aide(a, "Touche une colonne pour voir ce mois."))
        return c
    }

    /** Où et quand rouler : €/h net par créneau, jour, ville de prise en charge et plateforme (90 derniers jours). */
    private fun optimisation(): View {
        val c = W.carte(a, "Où et quand rouler")
        val rides = Stats.base(store.rides(), System.currentTimeMillis() - 90L * 24 * 3600_000)
        if (rides.size < 6) {
            c.addView(W.aide(a, "Encore ${6 - rides.size} course${if (6 - rides.size > 1) "s" else ""} à enregistrer pour voir tes créneaux, jours et zones les plus rentables."))
            return c
        }
        fun eurH(x: Double) = "${x.roundToInt()} €/h"
        fun bloc(titre: String, l: List<Stats.Ligne>, couleur: Int) {
            if (l.isEmpty()) return
            val tri = l.sortedByDescending { it.parHeure }
            c.addView(Ui.text(a, titre, 14f, Ui.FG, true).apply { setPadding(0, Ui.dp(a, 6), 0, 0) })
            c.addView(Barres.vue(a, tri.take(6).map { Triple("${it.nom} · ${it.courses}", it.parHeure, false) }, couleur) { eurH(it) })
        }
        val creneaux = Stats.parCreneau(rides, p)
        val meilleur = creneaux.maxByOrNull { it.parHeure }
        if (meilleur != null) c.addView(Ui.text(a, "Ton meilleur créneau : ${meilleur.nom.substringBefore(" (")} — ${eurH(meilleur.parHeure)} net", 16f, Ui.ACCENT, true))
        bloc("Par créneau horaire", creneaux, Ui.ACCENT)
        bloc("Par jour de la semaine", Stats.parJour(rides, p), W.couleurSource("Uber"))
        bloc("Par ville de prise en charge", Stats.parVille(rides, p), W.couleurSource("Bolt"))
        val plats = Stats.parPlateforme(rides, p)
        if (plats.size >= 2) {
            c.addView(Ui.text(a, "Par plateforme", 14f, Ui.FG, true).apply { setPadding(0, Ui.dp(a, 6), 0, 0) })
            plats.sortedByDescending { it.parHeure }.forEach {
                c.addView(W.ligne(a, "${it.nom} · ${it.courses} courses", "${eurH(it.parHeure)} · ${Analyzer.fmt2(it.parKm)} €/km", couleur = W.couleurSource(it.nom)))
            }
        }
        c.addView(W.aide(a, "Net = encaissé − TVA − recharge, usure, loyer et assurance au km. Temps = approche + client à bord. " +
            "Sur les 90 derniers jours ; le nombre après le nom = courses."))
        return c
    }

    private fun payerAuMieux(): View {
        val c = W.carte(a, "Te payer au mieux")
        val act = activiteAnnee()
        if (act == null) {
            c.addView(W.aide(a, "Pas encore assez de courses cette année. Mets une prévision dans Réglages → Impôts."))
            return c
        }
        val s = store.situation
        val o = Optimiseur.optimiser(act, p, s, p.regime)
        val pl = o.recommande
        c.addView(W.hero(a, "${W.eur(pl.net / 12)} par mois", "net pour toi sur l'année, en te payant de la meilleure façon", Ui.GO))
        c.addView(Ui.text(a, (if (pl.salaireBrut < 1) "Pas de salaire. " else "Salaire : ${W.eur(pl.salaireBrut / 12)} brut par mois. ") +
            "Dividendes : ${W.eur(pl.dividendes)} par an" + (if (pl.dividendesAuBareme) ", en cochant la case 2OP." else "."), 15f, Ui.FG, true))
        val leviers = Optimiseur.leviers(o, p, s)
        val det = Ui.vertical(a, 8)
        listOfNotNull(o.toutDividendes, o.toutSalaire, o.optimal.takeIf { abs(it.coutSalaire - o.toutDividendes.coutSalaire) >= 1 }, o.optimalRetraite).forEach {
            val moi = abs(it.net - pl.net) < 1 && abs(it.coutSalaire - pl.coutSalaire) < 1
            det.addView(W.ligne(a, it.nom + (if (moi) " ✓" else ""), W.eur(it.net), moi, if (moi) Ui.GO else Ui.FG))
        }
        det.addView(W.ligne(a, "Bénéfice de la SASU sur l'année", W.eur(o.annuel.resultat)))
        det.addView(W.ligne(a, "Impôts et cotisations sur l'année", W.eur(pl.totalPrelevements), true))
        leviers.forEach { det.addView(Ui.text(a, "• $it", 14f)) }
        c.addView(Ui.details(a, "Voir le détail et les conseils", det))
        return c
    }

    private fun kilometres(): View {
        val c = W.carte(a, "Carnet kilométrique")
        val r = Reports.mois(store.rides(), store.service(), a.vueAnnee, a.vueMois, p.cv, p.electrique, p.coutKm(), a.moisEcoules(), store.perso())
        val dom = store.segments().filter { a.duMois(it.debut) }.sumOf { it.km }
        c.addView(W.hero(a, "${Analyzer.fmt1(r.kmPro)} km", "professionnels ce mois · ${r.courses} course${if (r.courses > 1) "s" else ""}"))
        c.addView(Ui.buttonRow(a,
            W.chiffreKm(a, "Approche", r.kmApproche, Ui.WARN),
            W.chiffreKm(a, "Client", r.kmCourse, Ui.GO),
            W.chiffreKm(a, "Domicile", dom, Ui.ACCENT)))
        c.addView(W.ligne(a, "À vide entre courses", "${Analyzer.fmt1(maxOf(0.0, r.kmVide - dom))} km"))
        c.addView(W.ligne(a, "Trajets perso (exclus)", "${Analyzer.fmt1(r.kmPerso)} km"))
        if (r.kmPerso > 0) c.addView(W.ligne(a, "Part professionnelle", "${(r.partPro * 100).roundToInt()} %"))
        c.addView(W.ligne(a, "Valeur au barème kilométrique 2026", W.eur(r.bareme), true, Ui.ACCENT))
        // Compteur de la Tesla (Teslemetry) : la preuve « officielle » à côté du GPS
        TeslaAuto.bilanMois(store, a.vueAnnee, a.vueMois)?.let { b ->
            val f = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
            fun k(x: Double) = String.format(Locale.FRANCE, "%,.1f km", x)
            c.addView(Ui.text(a, "Compteur de la Tesla", 15f, Ui.ACCENT, true).apply { setPadding(0, Ui.dp(a, 8), 0, 0) })
            c.addView(W.ligne(a, "Premier relevé (${f.format(Date(b.premier.t))})", k(b.premier.odoKm)))
            c.addView(W.ligne(a, "Dernier relevé (${f.format(Date(b.dernier.t))})", k(b.dernier.odoKm)))
            c.addView(W.ligne(a, "Km au compteur sur la période", k(b.total), true))
            if (b.service > 0) {
                c.addView(W.ligne(a, "dont en service (bulle lancée)", k(b.service)))
                c.addView(W.ligne(a, "dont hors service", k(b.horsService)))
                if (r.kmPro > 0) {
                    val ecart = (r.kmPro - b.service) / b.service * 100
                    c.addView(W.aide(a, "GPS du téléphone ${Analyzer.fmt1(r.kmPro)} km pro contre ${Analyzer.fmt1(b.service)} km au compteur en service " +
                        "(écart ${String.format(Locale.FRANCE, "%+.1f", ecart)} %)."))
                }
            }
            c.addView(W.aide(a, "${b.releves} relevés horodatés envoyés par la voiture, détaillés dans l'export."))
        }
        c.addView(W.aide(a, "Barème électrique (+20 %), calculé sur le cumul de l'année. Chaque km est justifié : heure, lieux et tracé GPS " +
            "dans la boîte noire et dans l'export. Voiture à ton nom et non à celui du chauffeur : fais valider par le comptable " +
            "si ces indemnités sont applicables, ou si la société paie plutôt un loyer."))
        return c
    }

    /** Relevé complet du mois pour le comptable. */
    fun csvMois(): String {
        val rides = store.rides()
        val r = Reports.mois(rides, store.service(), a.vueAnnee, a.vueMois, p.cv, p.electrique, p.coutKm(), a.moisEcoules(), store.perso())
        val sb = StringBuilder(Reports.csv(rides, store.service(), a.vueAnnee, a.vueMois, r, p, store.perso()))
        fun x(v: Double) = String.format(Locale.FRANCE, "%.2f", v)
        val f = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)
        // Carnet kilométrique : chaque trajet pro du mois, dans l'ordre, au mètre près
        val hh = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
        fun km(v: Double) = String.format(Locale.FRANCE, "%.3f", v)
        fun l(x: String) = x.replace(';', ',')
        val journal = rides.filter { a.duMois(it.debut) }.map { r ->
            r.debut to listOf(f.format(Date(r.debut)), hh.format(Date(r.debut)), hh.format(Date(r.priseEnCharge)), hh.format(Date(r.fin)),
                "Course ${r.source}", l(r.lieuDepart), l(r.lieuPrise), l(r.lieuArrivee), km(r.kmApproche), km(r.kmCourse), km(r.kmTotal),
                if (r.manuelle) "saisie à la main" else "GPS")
        } + store.segments().filter { a.duMois(it.debut) }.map { sg ->
            sg.debut to listOf(f.format(Date(sg.debut)), hh.format(Date(sg.debut)), "", hh.format(Date(sg.fin)),
                sg.nom, l(sg.lieuDepart), "", l(sg.lieuArrivee), "", "", km(sg.km), "GPS")
        }
        sb.append("\nCarnet kilométrique;Début;Client à bord;Fin;Trajet;Départ;Prise en charge;Arrivée;Km approche;Km client à bord;Km total;Relevé;Compteur Tesla acceptation;Compteur Tesla prise en charge;Compteur Tesla dépose\n")
        journal.sortedBy { it.first }.forEach { (t, l0) ->
            val rr = rides.find { it.debut == t }
            fun o(v: Double?) = if (v != null && v > 0) String.format(Locale.FRANCE, "%.1f", v) else ""
            sb.append((l0 + listOf(o(rr?.odoDebut), o(rr?.odoPrise), o(rr?.odoFin))).joinToString(";")).append('\n')
        }
        // Relevés du compteur de la Tesla (Teslemetry)
        val rel = store.releves().filter { a.duMois(it.t) }
        if (rel.isNotEmpty()) {
            sb.append("\nRelevés compteur Tesla;Heure;Événement;Compteur (km);Batterie (%);Autonomie (km);Envoyé par la voiture à;Position;Note\n")
            rel.sortedBy { it.t }.forEach {
                sb.append(listOf(f.format(Date(it.t)), hh.format(Date(it.t)), it.libelle, String.format(Locale.FRANCE, "%.1f", it.odoKm),
                    if (it.batterie >= 0) String.format(Locale.FRANCE, "%.0f", it.batterie) else "",
                    if (it.autonomieKm >= 0) String.format(Locale.FRANCE, "%.0f", it.autonomieKm) else "",
                    if (it.majVoiture > 0) hh.format(Date(it.majVoiture)) else "",
                    if (it.lat != 0.0) String.format(Locale.US, "%.5f %.5f", it.lat, it.lon) else "", l(it.note)).joinToString(";")).append('\n')
            }
            TeslaAuto.bilanMois(store, a.vueAnnee, a.vueMois)?.let { b ->
                sb.append("Km au compteur sur la période;;;${String.format(Locale.FRANCE, "%.1f", b.total)}\n")
                    .append("dont en service;;;${String.format(Locale.FRANCE, "%.1f", b.service)}\n")
            }
        }
        val frais = store.fraisDuMois(a.vueAnnee, a.vueMois).sortedBy { it.date }
        sb.append("\nFrais;Date;Montant TTC;TVA;Montant HT;Note;Justificatif\n")
        frais.forEach {
            sb.append(listOf(it.categorie.nom, if (it.mensuel) "chaque mois" else f.format(Date(it.date)), x(it.ttc), x(it.tva()), x(it.ht()),
                it.note.replace(';', ','), if (it.photo.isNotBlank()) "photo" else "").joinToString(";")).append('\n')
        }
        val (n, net) = net()
        val b = n.base
        sb.append("\nSynthèse financière (estimation);€\n")
        b.parSource.entries.sortedByDescending { it.value }.forEach { (s, v) -> sb.append("Encaissé $s;${x(v)}\n") }
        if (p.tva) sb.append("Prix payés par les clients;${x(b.prixClients)}\n").append("TVA collectée (10 %);${x(b.tvaCollectee)}\n")
            .append("TVA déductible;${x(b.tvaDeductible)}\n")
        b.postes.forEach { sb.append("Frais ${it.nom}${if (it.estime) " (estimé)" else ""};${x(it.ttc)}\n") }
        sb.append("Bénéfice avant impôt;${x(n.resultat)}\n").append("Impôt sur les sociétés du mois;${x(n.impotSocietes)}\n")
            .append("Net dans la poche (meilleure option);${x(net)}\n")
        return sb.toString()
    }

    // ---------------------------------------------------------------- Rapprochement

    fun afficherRapprochement(texte: String) {
        val box = Ui.vertical(a, 8).apply { val pd = Ui.dp(a, 18); setPadding(pd, pd, pd, pd) }
        val table = Rapprochement.lireCsv(texte)
        val cols = Rapprochement.detecter(table)
        fun t(s: String, c: Int = Ui.FG, sp: Float = 14f, bold: Boolean = false) = Ui.text(a, s, sp, c, bold)
        var dialogue: AlertDialog? = null
        if (cols == null) {
            box.addView(t("Je n'ai pas reconnu les colonnes date et montant de ce fichier. Colonnes trouvées : " +
                table.entetes.joinToString(", ").ifBlank { "aucune" } + ".", Ui.WARN))
        } else {
            val lignes = Rapprochement.lignes(table, cols)
            val res = Rapprochement.rapprocher(store.rides(), lignes)
            val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
            fun m(x: Double) = W.eur2(x)
            fun pl(n: Int, un: String, plusieurs: String) = "$n ${if (n > 1) plusieurs else un}"
            box.addView(t("Relevé : ${m(res.totalReleve)} · Appli : ${m(res.totalAppli)} · Écart : ${m(res.totalReleve - res.totalAppli)}", Ui.FG, 15f, true))
            box.addView(t("✓ ${pl(res.identiques.size, "course identique", "courses identiques")}", Ui.GO))
            if (res.ecarts.isNotEmpty()) {
                box.addView(t("~ ${pl(res.ecarts.size, "montant différent", "montants différents")} (pourboire, majoration…)", Ui.WARN))
                res.ecarts.take(30).forEach { (r, l) -> box.addView(t("   ${fmt.format(Date(r.debut))} : appli ${m(r.prix)} → relevé ${m(l.montant)}", Ui.MUTED, 13f)) }
                box.addView(W.bouton(a, "Corriger avec les montants du relevé", true) {
                    res.ecarts.forEach { (r, l) -> store.setRidePrice(r.debut, l.montant) }
                    a.toast("${res.ecarts.size} montants corrigés"); dialogue?.dismiss(); a.afficher()
                })
            }
            if (res.absentesAppli.isNotEmpty()) {
                box.addView(t("✕ ${pl(res.absentesAppli.size, "course payée mais pas suivie", "courses payées mais pas suivies")}", Ui.STOP))
                res.absentesAppli.take(30).forEach { box.addView(t("   ${fmt.format(Date(it.t))} : ${m(it.montant)}", Ui.MUTED, 13f)) }
                box.addView(W.bouton(a, "Les ajouter au chiffre d'affaires") {
                    val plat = store.dernierePlateforme
                    res.absentesAppli.forEach { store.addRide(Ride(it.t, it.t, it.t, 0.0, 0.0, it.montant, lieuArrivee = "Ajoutée depuis le relevé", plateforme = plat, manuelle = true)) }
                    a.toast("${res.absentesAppli.size} courses ajoutées"); dialogue?.dismiss(); a.afficher()
                })
            }
            if (res.absentesReleve.isNotEmpty()) {
                box.addView(t("? ${pl(res.absentesReleve.size, "course suivie mais absente", "courses suivies mais absentes")} du relevé (annulée ? autre plateforme ?)", Ui.WARN))
                res.absentesReleve.take(30).forEach { box.addView(t("   ${fmt.format(Date(it.debut))} : ${m(it.prix)} · ${it.source}", Ui.MUTED, 13f)) }
            }
        }
        AlertDialog.Builder(a).setTitle("Rapprochement").setView(ScrollView(a).apply { addView(box) })
            .setPositiveButton("Fermer", null).create().also { dialogue = it }.show()
    }
}
