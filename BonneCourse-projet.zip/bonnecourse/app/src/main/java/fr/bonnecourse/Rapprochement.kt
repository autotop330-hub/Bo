package fr.bonnecourse

import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Rapprochement entre les courses suivies par l'appli et le relevé de la plateforme
 * (fichier CSV exporté depuis Uber, Bolt, Heetch…).
 *
 * Le format des fichiers change selon la plateforme et le pays : les colonnes sont donc
 * reconnues par leur nom (date, heure, montant, identifiant de course) et leur contenu.
 */
object Rapprochement {

    data class Table(val entetes: List<String>, val lignes: List<List<String>>)
    data class Colonnes(val date: Int, val heure: Int?, val montant: Int, val id: Int?)
    data class Ligne(val t: Long, val montant: Double, val ref: String)

    data class Resultat(
        val identiques: List<Pair<Ride, Ligne>>,
        val ecarts: List<Pair<Ride, Ligne>>,     // même course, montant différent (pourboire, majoration…)
        val absentesAppli: List<Ligne>,          // payées par la plateforme mais pas suivies dans l'appli
        val absentesReleve: List<Ride>,          // suivies dans l'appli mais pas dans le relevé
        val totalReleve: Double,
        val totalAppli: Double
    )

    // ------------------------------------------------------------ Lecture CSV

    fun lireCsv(texte: String): Table {
        val t = texte.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n')
        val premiere = t.lineSequence().firstOrNull { it.isNotBlank() } ?: return Table(emptyList(), emptyList())
        val sep = listOf(';', ',', '\t').maxByOrNull { c -> premiere.count { it == c } } ?: ','
        val lignes = mutableListOf<List<String>>()
        var champ = StringBuilder(); var ligne = mutableListOf<String>(); var guillemets = false
        var i = 0
        while (i < t.length) {
            val ch = t[i]
            when {
                guillemets && ch == '"' && i + 1 < t.length && t[i + 1] == '"' -> { champ.append('"'); i++ }
                ch == '"' -> guillemets = !guillemets
                !guillemets && ch == sep -> { ligne.add(champ.toString().trim()); champ = StringBuilder() }
                !guillemets && ch == '\n' -> {
                    ligne.add(champ.toString().trim()); champ = StringBuilder()
                    if (ligne.any { it.isNotEmpty() }) lignes.add(ligne)
                    ligne = mutableListOf()
                }
                else -> champ.append(ch)
            }
            i++
        }
        ligne.add(champ.toString().trim())
        if (ligne.any { it.isNotEmpty() }) lignes.add(ligne)
        if (lignes.isEmpty()) return Table(emptyList(), emptyList())
        return Table(lignes.first(), lignes.drop(1))
    }

    // ------------------------------------------------------------ Dates et montants

    private val FORMATS = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm",
        "yyyy-MM-dd HH:mm:ss Z", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
        "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy HH:mm", "dd/MM/yyyy 'à' HH:mm", "dd/MM/yyyy HH'h'mm",
        "dd.MM.yyyy HH:mm:ss", "dd.MM.yyyy HH:mm", "dd-MM-yyyy HH:mm",
        "d MMM yyyy HH:mm", "d MMMM yyyy HH:mm", "d MMM yyyy 'à' HH:mm", "d MMMM yyyy 'à' HH:mm",
        "MM/dd/yyyy hh:mm a", "MMM d, yyyy h:mm a", "MMM d, yyyy, h:mm a",
        "yyyy-MM-dd", "dd/MM/yyyy", "dd.MM.yyyy"
    )

    fun parseDate(s0: String): Long? {
        val s = s0.trim().replace(Regex("\\s+"), " ").replace(" UTC", "Z").replace("+0000", "Z")
        if (s.isEmpty()) return null
        for (f in FORMATS) {
            for (loc in listOf(Locale.FRANCE, Locale.US)) {
                try {
                    val fmt = SimpleDateFormat(f, loc).apply { isLenient = false }
                    if (f.endsWith("'Z'")) fmt.timeZone = java.util.TimeZone.getTimeZone("UTC")
                    val pos = java.text.ParsePosition(0)
                    val d = fmt.parse(s, pos) ?: continue
                    if (pos.index == s.length) return d.time
                } catch (_: Exception) {}
            }
        }
        return null
    }

    fun parseMontant(s0: String): Double? {
        var s = s0.replace(" ", "").replace(" ", "").replace(" ", "")
            .replace("€", "").replace("EUR", "").replace("CHF", "").trim()
        if (s.isEmpty()) return null
        val negatif = s.startsWith("(") && s.endsWith(")")
        s = s.trim('(', ')')
        // 1.234,56 → 1234.56 ; 1,234.56 → 1234.56 ; 14,20 → 14.20
        s = when {
            s.contains(',') && s.contains('.') ->
                if (s.lastIndexOf(',') > s.lastIndexOf('.')) s.replace(".", "").replace(',', '.') else s.replace(",", "")
            s.contains(',') -> s.replace(',', '.')
            else -> s
        }
        val v = s.toDoubleOrNull() ?: return null
        return if (negatif) -v else v
    }

    // ------------------------------------------------------------ Colonnes

    private fun norm(h: String) = java.text.Normalizer.normalize(h.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{M}"), "")

    /** Mots qui désignent ce que le chauffeur touche, du plus fiable au moins fiable. */
    private val MOTS_MONTANT = listOf(
        "paid to you", "vos gains", "gains nets", "net earnings", "driver earnings", "revenus nets", "montant net",
        "verse", "earnings", "gain", "net", "payout", "revenu", "montant", "total", "amount", "prix", "fare"
    )

    fun detecter(t: Table): Colonnes? {
        if (t.entetes.isEmpty() || t.lignes.isEmpty()) return null
        val ech = t.lignes.take(30)
        fun taux(col: Int, f: (String) -> Boolean) =
            ech.count { it.getOrNull(col)?.let { v -> v.isNotBlank() && f(v) } == true }.toDouble() / ech.size

        val h = t.entetes.map { norm(it) }
        // Date (avec heure si possible)
        val dates = h.indices.filter { taux(it) { v -> parseDate(v) != null } > 0.6 }
        val dateCol = dates.maxByOrNull { c ->
            (if (Regex("date|time|heure|horodat|debut|start|request|demande").containsMatchIn(h[c])) 2 else 0) +
                (if (ech.any { (it.getOrNull(c) ?: "").contains(':') }) 3 else 0) -
                (if (Regex("fin|end|drop").containsMatchIn(h[c])) 1 else 0)
        } ?: return null
        val dateAvecHeure = ech.any { (it.getOrNull(dateCol) ?: "").contains(':') }
        val heureCol = if (dateAvecHeure) null else h.indices.firstOrNull { c ->
            c != dateCol && Regex("heure|time|hour").containsMatchIn(h[c]) &&
                taux(c) { v -> Regex("^\\d{1,2}[:h]\\d{2}").containsMatchIn(v.trim()) } > 0.6
        }
        // Montant : colonne numérique dont le nom ressemble le plus à « ce que tu touches »
        val numeriques = h.indices.filter { it != dateCol && it != heureCol && taux(it) { v -> parseMontant(v) != null } > 0.6 }
        val montantCol = numeriques.minByOrNull { c ->
            val i = MOTS_MONTANT.indexOfFirst { h[c].contains(it) }
            if (i < 0) 999 else i
        }?.takeIf { c -> MOTS_MONTANT.any { h[c].contains(it) } } ?: return null
        val idCol = h.indices.firstOrNull { Regex("uuid|trip id|ride id|id du trajet|id de la course|reference|référence|course id").containsMatchIn(it.let { c -> h[c] }) }
        return Colonnes(dateCol, heureCol, montantCol, idCol)
    }

    /** Lignes du relevé, regroupées par course quand le fichier a un identifiant (tarif + pourboire + bonus). */
    fun lignes(t: Table, c: Colonnes): List<Ligne> {
        val brutes = t.lignes.mapNotNull { row ->
            val d = row.getOrNull(c.date) ?: return@mapNotNull null
            val txt = if (c.heure != null) "$d ${row.getOrNull(c.heure) ?: ""}".trim() else d
            val time = parseDate(txt) ?: parseDate(d) ?: return@mapNotNull null
            val m = parseMontant(row.getOrNull(c.montant) ?: "") ?: return@mapNotNull null
            Ligne(time, m, c.id?.let { row.getOrNull(it) } ?: "")
        }
        if (c.id == null) return brutes
        return brutes.groupBy { it.ref.ifEmpty { "${it.t}-${it.montant}" } }
            .map { (ref, ls) -> Ligne(ls.minOf { it.t }, ls.sumOf { it.montant }, ref) }
            .sortedBy { it.t }
    }

    // ------------------------------------------------------------ Rapprochement

    fun rapprocher(rides: List<Ride>, lignes: List<Ligne>, toleranceMin: Int = 45): Resultat {
        val courses = lignes.filter { it.montant > 0 }
        if (courses.isEmpty()) return Resultat(emptyList(), emptyList(), emptyList(), emptyList(), 0.0, 0.0)
        // Courses de l'appli prises en compte : tous les jours couverts par le relevé
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = courses.minOf { it.t }
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        val debut = cal.timeInMillis
        cal.timeInMillis = courses.maxOf { it.t }
        cal.set(java.util.Calendar.HOUR_OF_DAY, 23); cal.set(java.util.Calendar.MINUTE, 59); cal.set(java.util.Calendar.SECOND, 59)
        val fin = cal.timeInMillis
        val candidates = rides.filter { !it.prive && it.debut in debut..fin }.toMutableList()
        val tol = toleranceMin * 60_000L

        val identiques = mutableListOf<Pair<Ride, Ligne>>()
        val ecarts = mutableListOf<Pair<Ride, Ligne>>()
        val absentesAppli = mutableListOf<Ligne>()
        // On rapproche d'abord les paires les plus proches dans le temps
        val paires = courses.flatMap { l ->
            candidates.map { r -> Triple(l, r, minOf(abs(r.debut - l.t), abs(r.priseEnCharge - l.t), abs(r.fin - l.t))) }
        }.filter { it.third <= tol }.sortedWith(compareBy({ it.third }, { abs(it.second.prix - it.first.montant) }))
        val lUsees = mutableSetOf<Ligne>(); val rUsees = mutableSetOf<Ride>()
        for ((l, r, _) in paires) {
            if (l in lUsees || r in rUsees) continue
            lUsees += l; rUsees += r
            if (abs(r.prix - l.montant) <= 0.05) identiques += r to l else ecarts += r to l
        }
        courses.filter { it !in lUsees }.forEach { absentesAppli += it }
        return Resultat(identiques, ecarts, absentesAppli, candidates.filter { it !in rUsees },
            totalReleve = lignes.sumOf { it.montant }, totalAppli = candidates.sumOf { it.prix })
    }
}
