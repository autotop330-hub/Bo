package fr.bonnecourse

import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Barème kilométrique fiscal « voitures », imposition des revenus 2025 (déclaration 2026),
 * identique aux deux années précédentes. d = km professionnels sur l'année.
 *   d ≤ 5 000 : a × d     5 001 à 20 000 : b × d + c     > 20 000 : e × d
 * Le barème électrique ne concerne que les voitures 100 % électriques (pas les hybrides).
 */
object Bareme {
    const val ANNEE = "barème 2026 (revenus 2025)"

    // [3 CV et moins, 4, 5, 6, 7 et plus] → (a, b, c, e)
    private val THERMIQUE = arrayOf(
        doubleArrayOf(0.529, 0.316, 1065.0, 0.370),
        doubleArrayOf(0.606, 0.340, 1330.0, 0.407),
        doubleArrayOf(0.636, 0.357, 1395.0, 0.427),
        doubleArrayOf(0.665, 0.374, 1457.0, 0.447),
        doubleArrayOf(0.697, 0.394, 1515.0, 0.470)
    )
    private val ELECTRIQUE = arrayOf(
        doubleArrayOf(0.635, 0.379, 1278.0, 0.444),
        doubleArrayOf(0.727, 0.408, 1596.0, 0.488),
        doubleArrayOf(0.763, 0.428, 1674.0, 0.512),
        doubleArrayOf(0.798, 0.449, 1748.0, 0.536),
        doubleArrayOf(0.836, 0.473, 1818.0, 0.564)
    )

    private fun ligne(cv: Int, electrique: Boolean): DoubleArray {
        val i = (cv.coerceIn(3, 7)) - 3
        return if (electrique) ELECTRIQUE[i] else THERMIQUE[i]
    }

    /** Texte du barème appliqué, ex. « Électrique · 7 CV et plus · au-delà de 20 000 km : d × 0,564 ». */
    fun description(kmAnnee: Double, cv: Int, electrique: Boolean): String {
        val l = ligne(cv, electrique)
        val f = { x: Double -> String.format(java.util.Locale.FRANCE, "%.3f", x) }
        val cvTxt = when { cv <= 3 -> "3 CV et moins"; cv >= 7 -> "7 CV et plus"; else -> "$cv CV" }
        val tranche = when {
            kmAnnee <= 5000 -> "jusqu'à 5 000 km : d × ${f(l[0])}"
            kmAnnee <= 20000 -> "de 5 001 à 20 000 km : d × ${f(l[1])} + ${l[2].toInt()} €"
            else -> "au-delà de 20 000 km : d × ${f(l[3])}"
        }
        return "${if (electrique) "Électrique (majoration de 20 % incluse)" else "Thermique"} · $cvTxt · $tranche"
    }

    /** Montant pour l'année entière. */
    fun annuel(km: Double, cv: Int, electrique: Boolean): Double {
        if (km <= 0) return 0.0
        val (a, b, c, e) = ligne(cv, electrique).let { listOf(it[0], it[1], it[2], it[3]) }
        return when {
            km <= 5000 -> a * km
            km <= 20000 -> b * km + c
            else -> e * km
        }
    }

    /**
     * Part d'une période (un mois) : le barème est annuel et dégressif,
     * donc on calcule « cumul jusqu'à la fin du mois » moins « cumul avant le mois ».
     */
    fun periode(kmAvant: Double, kmPeriode: Double, cv: Int, electrique: Boolean): Double =
        max(0.0, annuel(kmAvant + kmPeriode, cv, electrique) - annuel(kmAvant, cv, electrique))
}

/**
 * Compteur kilométrique à partir des positions GPS.
 * Écarte les points imprécis, les sauts impossibles et le « tremblement » à l'arrêt.
 */
class Odometer {
    var totalM = 0.0
        private set
    private var lat = Double.NaN
    private var lon = Double.NaN
    private var t = 0L

    /** Dernière position connue (pour noter les lieux de départ et d'arrivée). */
    var position: Pair<Double, Double>? = null
        private set

    /**
     * Ajoute une position, renvoie les mètres ajoutés.
     * @param speedMs vitesse mesurée par le GPS (effet Doppler, fiable même quand la position tremble), null si inconnue
     */
    fun add(newLat: Double, newLon: Double, accuracyM: Float, timeMs: Long, speedMs: Float? = null): Double {
        if (accuracyM <= 60f) position = newLat to newLon
        if (accuracyM > 30f) return 0.0
        if (lat.isNaN()) { lat = newLat; lon = newLon; t = timeMs; return 0.0 }
        val d = distanceM(lat, lon, newLat, newLon)
        val dt = (timeMs - t).coerceAtLeast(1) / 1000.0
        if (d / dt > 70.0 && (speedMs == null || speedMs < 60f)) {   // > 250 km/h : saut GPS, on repart de ce point
            lat = newLat; lon = newLon; t = timeMs; return 0.0
        }
        // À l'arrêt (feu, bouchon, attente client) : on garde le point d'arrêt, la position qui tremble ne compte pas
        if (speedMs != null && speedMs < 1.0f) return 0.0
        // Sans vitesse : on ne compte que les déplacements nettement plus grands que l'imprécision
        if (speedMs == null && d < max(30.0, accuracyM * 3.0)) return 0.0
        // En mouvement (vitesse mesurée) : segments d'au moins 8 m ou 1,5 × l'imprécision, pour suivre les virages
        // sans additionner le tremblement latéral du GPS en zigzag
        if (d < max(8.0, accuracyM * 1.5)) return 0.0
        lat = newLat; lon = newLon; t = timeMs
        totalM += d
        return d
    }

    /** Coupure (tunnel, GPS perdu longtemps) : on ne relie pas deux points trop éloignés dans le temps. */
    fun reset() { lat = Double.NaN; lon = Double.NaN }

    companion object {
        fun distanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
            val r = 6371000.0
            val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
            val dp = p2 - p1; val dl = Math.toRadians(lon2 - lon1)
            val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
            return 2 * r * asin(sqrt(h))
        }
    }
}

enum class Phase { AUCUNE, APPROCHE, COURSE }

/** Un point du tracé GPS d'une course (boîte noire). phase : 0 = approche, 1 = client à bord. */
data class Point(val lat: Double, val lon: Double, val t: Long, val phase: Int)

/** Une course enregistrée, à la minute et au mètre près. */
data class Ride(
    val debut: Long,        // acceptation
    val priseEnCharge: Long,// client à bord (= debut si non renseigné)
    val fin: Long,
    val kmApproche: Double,
    val kmCourse: Double,
    val prix: Double,
    val lieuDepart: String = "",   // où la course a été acceptée
    val lieuPrise: String = "",    // où le client est monté
    val lieuArrivee: String = "",  // où le client est descendu
    val type: String = "plateforme",// "plateforme" (Uber, Bolt…) ou "prive" (client en direct)
    val plateforme: String = "",   // "Uber", "Bolt", "Heetch" ; vide = inconnue
    val verdict: String = "",      // verdict affiché sur l'offre acceptée (ACCEPTER, A_VOIR, REFUSER)
    val score: Double = -1.0,
    val offreKm: Double = 0.0,     // ce que l'offre annonçait (approche + course)
    val offreMin: Double = 0.0,
    val manuelle: Boolean = false, // saisie à la main (pas de GPS)
    val facture: String = ""       // numéro de facture (course privée signée)
) {
    val prive get() = type == "prive"
    /** Uber, Bolt, Heetch, Privé, ou Plateforme si inconnue. */
    val source get() = if (prive) "Privé" else plateforme.ifBlank { "Plateforme" }
    val minApproche get() = (priseEnCharge - debut) / 60000.0
    val minCourse get() = (fin - priseEnCharge) / 60000.0
    val kmTotal get() = kmApproche + kmCourse
    val minTotal get() = (fin - debut) / 60000.0
}

/** Suivi de la course en cours : approche → client à bord → terminée. */
class RideTracker(private val odo: Odometer, private val now: () -> Long = System::currentTimeMillis) {
    var phase = Phase.AUCUNE
        private set
    private var tDebut = 0L
    private var tPrise = 0L
    private var mDebut = 0.0
    private var mPrise = 0.0
    private var prix = 0.0
    private var pDebut = ""
    private var pPrise = ""
    private var type = "plateforme"

    private fun ici() = odo.position?.let { String.format(java.util.Locale.US, "%.5f,%.5f", it.first, it.second) } ?: ""

    fun accepter(prixCourse: Double, typeCourse: String = "plateforme") {
        phase = Phase.APPROCHE; tDebut = now(); tPrise = 0L; mDebut = odo.totalM; prix = prixCourse; pDebut = ici(); pPrise = ""
        type = typeCourse
    }

    val typeEnCours get() = type

    fun clientABord() {
        if (phase != Phase.APPROCHE) return
        phase = Phase.COURSE; tPrise = now(); mPrise = odo.totalM; pPrise = ici()
    }

    /** Termine et renvoie la course à enregistrer. */
    fun terminer(): Ride? {
        if (phase == Phase.AUCUNE) return null
        val t = now(); val m = odo.totalM
        val prise = if (phase == Phase.COURSE) tPrise else t
        val mp = if (phase == Phase.COURSE) mPrise else m
        phase = Phase.AUCUNE
        val fin = ici()
        return Ride(tDebut, prise, t, (mp - mDebut) / 1000.0, (m - mp) / 1000.0, prix,
            pDebut, pPrise.ifEmpty { fin }, fin, type)
    }

    fun annuler() { phase = Phase.AUCUNE }

    /** Compteur de la phase en cours : (minutes, km). */
    fun compteur(): Pair<Double, Double> = when (phase) {
        Phase.AUCUNE -> 0.0 to 0.0
        Phase.APPROCHE -> (now() - tDebut) / 60000.0 to (odo.totalM - mDebut) / 1000.0
        Phase.COURSE -> (now() - tPrise) / 60000.0 to (odo.totalM - mPrise) / 1000.0
    }
}

/** Bilan d'un mois pour la déclaration. */
data class MonthReport(
    val courses: Int,
    val kmApproche: Double,
    val kmCourse: Double,
    val kmService: Double,     // tout ce qui a été roulé bulle active, hors mode perso
    val kmPerso: Double,       // trajets perso (mode perso) : exclus des indemnités
    val coursesPrivees: Int,   // courses clients en direct
    val minutes: Double,
    val chiffre: Double,
    val kmAnneeAvant: Double,  // km pro de l'année avant ce mois
    val bareme: Double,        // part du mois au barème
    val baremeAnnee: Double,   // projection : montant de l'année si le rythme continue
    val coutReel: Double       // coût estimé avec le profil véhicule
) {
    val kmPro get() = max(kmService, kmApproche + kmCourse)
    val kmVide get() = max(0.0, kmPro - kmApproche - kmCourse)
    val partPro get() = if (kmPro + kmPerso > 0) kmPro / (kmPro + kmPerso) else 1.0
}

object Reports {
    /**
     * @param rides  toutes les courses
     * @param service km roulés bulle active, par jour "aaaa-mm-jj"
     * @param annee, mois (1-12)
     */
    fun mois(rides: List<Ride>, service: Map<String, Double>, annee: Int, mois: Int,
             cv: Int, electrique: Boolean, coutKm: Double, moisEcoules: Double,
             perso: Map<String, Double> = emptyMap()): MonthReport {
        val cal = java.util.Calendar.getInstance()
        fun ym(t: Long): Pair<Int, Int> { cal.timeInMillis = t; return cal.get(java.util.Calendar.YEAR) to cal.get(java.util.Calendar.MONTH) + 1 }

        fun kmProDuMois(m: Int): Double {
            val rs = rides.filter { ym(it.debut) == (annee to m) }
            val svc = service.filterKeys { it.startsWith(String.format("%04d-%02d", annee, m)) }.values.sum()
            return max(svc, rs.sumOf { it.kmTotal })
        }

        val rs = rides.filter { ym(it.debut) == (annee to mois) }
        val svc = service.filterKeys { it.startsWith(String.format("%04d-%02d", annee, mois)) }.values.sum()
        val avant = (1 until mois).sumOf { kmProDuMois(it) }
        val kmPro = max(svc, rs.sumOf { it.kmTotal })
        // Projection annuelle : km de l'année jusqu'à aujourd'hui (ou jusqu'à la fin du mois affiché), ramenés à 12 mois
        val cumulAnnee = (1..12).sumOf { kmProDuMois(it) }
        val projection = if (moisEcoules >= 1) cumulAnnee / moisEcoules * 12 else cumulAnnee
        return MonthReport(
            courses = rs.size,
            kmApproche = rs.sumOf { it.kmApproche },
            kmCourse = rs.sumOf { it.kmCourse },
            kmService = svc,
            kmPerso = perso.filterKeys { it.startsWith(String.format("%04d-%02d", annee, mois)) }.values.sum(),
            coursesPrivees = rs.count { it.prive },
            minutes = rs.sumOf { it.minTotal },
            chiffre = rs.sumOf { it.prix },
            kmAnneeAvant = avant,
            bareme = Bareme.periode(avant, kmPro, cv, electrique),
            baremeAnnee = Bareme.annuel(projection, cv, electrique),
            coutReel = kmPro * coutKm
        )
    }

    /** Relevé du mois au format tableur (séparateur « ; », lisible directement par Excel en français). */
    fun csv(rides: List<Ride>, service: Map<String, Double>, annee: Int, mois: Int, r: MonthReport, p: Profile,
            perso: Map<String, Double> = emptyMap()): String {
        val loc = java.util.Locale.FRANCE
        val jour = java.text.SimpleDateFormat("dd/MM/yyyy", loc)
        val heure = java.text.SimpleDateFormat("HH:mm", loc)
        val cal = java.util.Calendar.getInstance()
        fun n1(x: Double) = String.format(loc, "%.1f", x)
        fun n2(x: Double) = String.format(loc, "%.2f", x)
        fun n3(x: Double) = String.format(loc, "%.3f", x)
        val sb = StringBuilder("﻿")   // BOM : accents corrects dans Excel
        val elec = if (p.electrique) "100 % électrique" else p.energy
        val cvTxt = if (p.cv <= 3) "3 CV et moins" else if (p.cv >= 7) "7 CV et plus" else "${p.cv} CV"
        sb.append(if (p.regime == "ik") "État des indemnités kilométriques" else "Relevé kilométrique")
            .append(";${String.format("%02d/%04d", mois, annee)}\n")
        sb.append(if (p.regime == "location") "Véhicule loué à la société;Tesla Model Y Grande Autonomie Propulsion;$elec\n" else "Véhicule personnel;$elec;$cvTxt\n")
        sb.append("Motif des déplacements;Courses VTC (approche, transport de clients, déplacements entre courses)\n")
        sb.append("Trajets personnels;exclus (mode perso de l'application)\n\n")
        sb.append("Date;Plateforme;Acceptation;Client à bord;Fin;Lieu d'acceptation;Lieu de prise en charge;Lieu d'arrivée;Approche (min);Approche (km);Course (min);Course (km);Total (min);Total (km);Montant course (${p.devise});Facture;Saisie\n")
        rides.filter { cal.timeInMillis = it.debut; cal.get(java.util.Calendar.YEAR) == annee && cal.get(java.util.Calendar.MONTH) + 1 == mois }
            .sortedBy { it.debut }
            .forEach {
                sb.append(listOf(
                    jour.format(java.util.Date(it.debut)), it.source,
                    heure.format(java.util.Date(it.debut)),
                    heure.format(java.util.Date(it.priseEnCharge)), heure.format(java.util.Date(it.fin)),
                    it.lieuDepart.replace(';', ','), it.lieuPrise.replace(';', ','), it.lieuArrivee.replace(';', ','),
                    n1(it.minApproche), n3(it.kmApproche), n1(it.minCourse), n3(it.kmCourse),
                    n1(it.minTotal), n3(it.kmTotal), if (it.prix > 0) n2(it.prix) else "", it.facture,
                    if (it.manuelle) "à la main" else "GPS"
                ).joinToString(";")).append('\n')
            }
        sb.append("\nJour;Km professionnels (en service);Km personnels (exclus)\n")
        val pre = String.format("%04d-%02d", annee, mois)
        (service.keys + perso.keys).filter { it.startsWith(pre) }.toSortedSet().forEach { k ->
            sb.append("${k.substring(8, 10)}/${k.substring(5, 7)}/${k.substring(0, 4)};${n3(service[k] ?: 0.0)};${n3(perso[k] ?: 0.0)}\n")
        }
        sb.append("\nSynthèse\n")
        sb.append("Courses;${r.courses} (dont ${r.coursesPrivees} clients privés)\n")
        sb.append("Km professionnels;${n1(r.kmPro)}\n")
        sb.append("dont client à bord;${n1(r.kmCourse)}\n")
        sb.append("dont approche;${n1(r.kmApproche)}\n")
        sb.append("dont à vide entre courses;${n1(r.kmVide)}\n")
        sb.append("Km personnels (exclus);${n1(r.kmPerso)}\n")
        sb.append("Km pro de l'année avant ce mois;${n1(r.kmAnneeAvant)}\n")
        if (p.regime == "ik") {
            sb.append("Indemnités kilométriques du mois (${Bareme.ANNEE});${n2(r.bareme)}\n")
            sb.append("Calcul;barème annuel appliqué au cumul de l'année : barème(${n1(r.kmAnneeAvant + r.kmPro)} km) − barème(${n1(r.kmAnneeAvant)} km)\n")
            sb.append("Barème appliqué;${Bareme.description(r.kmAnneeAvant + r.kmPro, p.cv, p.electrique)}\n")
        } else if (p.regime == "location") {
            sb.append("Note;Voiture louée à la société : frais réels (loyer, assurance, recharge, entretien), pas d'indemnités kilométriques\n")
        } else {
            sb.append("Valeur au barème pour ce mois (${Bareme.ANNEE});${n2(r.bareme)}\n")
            sb.append("Note;Micro-entreprise : frais non déductibles (abattement forfaitaire de 50 %)\n")
        }
        return sb.toString()
    }
}
