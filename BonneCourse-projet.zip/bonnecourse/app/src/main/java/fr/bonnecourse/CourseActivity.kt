package fr.bonnecourse

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt

/** Boîte noire : tout ce qui a été enregistré pour une course, avec son tracé GPS. */
class CourseActivity : AppCompatActivity() {

    companion object { const val EXTRA_COURSE = "course"; const val EXTRA_SEGMENT = "segment" }

    private lateinit var store: Store
    private var id = 0L
    private var segment = 0L
    private lateinit var racine: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        id = intent.getLongExtra(EXTRA_COURSE, 0L)
        segment = intent.getLongExtra(EXTRA_SEGMENT, 0L)
        racine = Ui.vertical(this, 16).apply { val p = Ui.dp(this@CourseActivity, 18); setPadding(p, p, p, p * 3) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(racine) })
    }

    override fun onResume() {
        super.onResume()
        construire()
    }

    private fun construire() {
        racine.removeAllViews()
        if (segment > 0) { construireSegment(); return }
        val r = store.ride(id) ?: run { finish(); return }
        val pts = store.trace(r.debut)
        val d = store.profile.devise
        val h = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)

        racine.addView(barreHaut { supprimer(r) })
        val tete = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        tete.addView(Ui.vertical(this, 6).apply {
            addView(W.puce(this@CourseActivity, r.source, W.couleurSource(r.source)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(Ui.text(this@CourseActivity, SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(r.debut)).replaceFirstChar { it.uppercase() } +
                " · " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(r.debut)), 15f, Ui.MUTED))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tete.addView(Ui.text(this, if (r.prix > 0) "${Analyzer.fmt2(r.prix)} $d" else "—", 36f, Ui.FG).apply { typeface = Ui.LEGER })
        racine.addView(tete)

        // Les km, au mètre près : approche, client à bord, total
        val avecApproche = !r.manuelle && (r.kmApproche > 0 || r.minApproche > 0.5)
        racine.addView(Ui.buttonRow(this, *listOfNotNull(
            if (avecApproche) tuile("APPROCHE", android.graphics.Color.parseColor("#B9C7D8"), r.kmApproche, r.minApproche) else null,
            tuile("CLIENT À BORD", android.graphics.Color.parseColor("#3FA0FF"), r.kmCourse, r.minCourse),
            tuile("TOTAL PRO", Ui.ACCENT, r.kmTotal, r.minTotal)).toTypedArray()))

        // Carte
        val carteTrace = W.carte(this, "Trajet GPS")
        if (pts.size >= 2) {
            val carte = Carte.vue(this, r, pts)
            carteTrace.addView(cadreCarte(carte, pts))
            Carte.recalerPuisAfficher(carte, store, "r${r.debut}", pts)
            carteTrace.addView(Ui.buttonRow(this,
                W.bouton(this, "Google Maps", true) { googleMaps(pts) },
                W.bouton(this, "Partager (GPX)") { partagerGpx(r.debut, "course", r.source, pts) }))
            carteTrace.addView(W.aide(this, "${pts.size} positions GPS horodatées · précision ${precision(pts)}" +
                if (store.cleTomTom.isBlank()) "\nPour un tracé qui suit parfaitement les rues : Réglages → Trafic en temps réel." else ""))
        } else {
            carteTrace.addView(W.aide(this, if (r.manuelle) "Course saisie à la main : pas de tracé GPS." else "Pas de tracé GPS pour cette course (GPS coupé ou course ajoutée depuis un relevé)."))
        }
        racine.addView(carteTrace)

        // Chronologie
        val chrono = W.carte(this, "Chronologie")
        if (avecApproche && r.priseEnCharge > r.debut) etape(chrono, Ui.WARN, "Course acceptée", h.format(Date(r.debut)), r.lieuDepart)
        etape(chrono, Ui.GO, "Client à bord", h.format(Date(r.priseEnCharge)), r.lieuPrise)
        etape(chrono, Ui.FG, "Client déposé", h.format(Date(r.fin)), r.lieuArrivee)
        racine.addView(chrono)

        // Rentabilité
        val ch = W.carte(this, "Rentabilité")
        if (r.prix > 0 && r.kmTotal > 0) ch.addView(W.ligne(this, "Par km roulé", "${Analyzer.fmt2(r.prix / r.kmTotal)} $d"))
        if (r.prix > 0 && r.minTotal > 1) ch.addView(W.ligne(this, "Par heure", "${(r.prix / r.minTotal * 60).roundToInt()} $d"))
        if (r.offreKm > 0) {
            ch.addView(W.ligne(this, "Annoncé par l'offre", "${r.offreMin.roundToInt()} min · ${Analyzer.fmt1(r.offreKm)} km"))
            ch.addView(W.ligne(this, "Réellement roulé", "${r.minTotal.roundToInt()} min · ${Analyzer.fmt2(r.kmTotal)} km"))
            val v = runCatching { Verdict.valueOf(r.verdict) }.getOrNull()
            if (v != null) ch.addView(W.ligne(this, "Verdict de la bulle", "${v.mot} · ${Analyzer.fmt1(r.score)}/10", couleur = Ui.color(v)))
        }
        if (ch.childCount > 1) racine.addView(ch)

        // Actions
        val act = W.carte(this, "Actions")
        if (r.prive) {
            act.addView(W.bouton(this, if (r.facture.isNotBlank()) "Facture ${r.facture}" else "Faire signer et facturer", true, if (r.facture.isNotBlank()) Ui.ACCENT else Ui.GO) {
                startActivity(Intent(this, FactureActivity::class.java).putExtra(FactureActivity.EXTRA_COURSE, r.debut))
            })
        } else {
            act.addView(W.bouton(this, "Plateforme : ${r.source}") { choisirPlateforme(r) })
        }
        if (r.facture.isBlank()) act.addView(W.bouton(this, "Corriger le montant") { montant(r) })
        racine.addView(act)
        racine.addView(W.boutonDanger(this, if (r.facture.isBlank()) "Supprimer cette course" else "Supprimer la course et sa facture") { supprimer(r) })
    }

    /** Trajet domicile ↔ service (carnet kilométrique). */
    private fun construireSegment() {
        val sg = store.segments().find { it.debut == segment } ?: run { finish(); return }
        val pts = store.traceSegment(sg.debut)
        val h = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
        racine.addView(barreHaut { supprimerSegment(sg) })
        racine.addView(Ui.vertical(this, 6).apply {
            addView(W.puce(this@CourseActivity, "Carnet kilométrique", Ui.ACCENT), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(Ui.text(this@CourseActivity, sg.nom, 28f, Ui.FG).apply { typeface = Ui.MEDIUM })
            addView(Ui.text(this@CourseActivity, SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(sg.debut)).replaceFirstChar { it.uppercase() }, 15f, Ui.MUTED))
        })
        racine.addView(Ui.buttonRow(this, tuile("KM PRO", Ui.ACCENT, sg.km, sg.minutes)))
        val carteTrace = W.carte(this, "Trajet GPS")
        if (pts.size >= 2) {
            val carte = Carte.vueSegment(this, sg, pts)
            carteTrace.addView(cadreCarte(carte, pts))
            Carte.recalerPuisAfficher(carte, store, "s${sg.debut}", pts)
            carteTrace.addView(Ui.buttonRow(this,
                W.bouton(this, "Google Maps", true) { googleMaps(pts) },
                W.bouton(this, "Partager (GPX)") { partagerGpx(sg.debut, sg.type, sg.nom, pts) }))
            carteTrace.addView(W.aide(this, "${pts.size} positions GPS horodatées · précision ${precision(pts)}"))
        } else carteTrace.addView(W.aide(this, "Pas de tracé GPS enregistré pour ce trajet."))
        racine.addView(carteTrace)
        val chrono = W.carte(this, "Chronologie")
        etape(chrono, Ui.ACCENT, "Départ", h.format(Date(sg.debut)), sg.lieuDepart)
        etape(chrono, Ui.FG, "Arrivée", h.format(Date(sg.fin)), sg.lieuArrivee)
        racine.addView(chrono)
        racine.addView(W.aide(this, "Ces km font partie des km professionnels du jour ; ils sont détaillés ici pour le justificatif."))
        racine.addView(W.boutonDanger(this, "Supprimer ce trajet") { supprimerSegment(sg) })
    }

    /** « ‹ Boîte noire » à gauche, corbeille à droite. */
    private fun barreHaut(onSupprimer: (() -> Unit)?): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
        addView(Ui.text(this@CourseActivity, "‹  Boîte noire", 15f, Ui.ACCENT, true).apply {
            val p = Ui.dp(this@CourseActivity, 8); setPadding(0, p, p, p); setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (onSupprimer != null) addView(android.widget.FrameLayout(this@CourseActivity).apply {
            background = Ui.box(this@CourseActivity, Ui.SURFACE, Color.parseColor("#4A2421"), 1, 22)
            addView(W.icone(this@CourseActivity, R.drawable.ic_supprimer, Ui.STOP, 22),
                android.widget.FrameLayout.LayoutParams(Ui.dp(this@CourseActivity, 22), Ui.dp(this@CourseActivity, 22), android.view.Gravity.CENTER))
            setOnClickListener { onSupprimer() }
        }, LinearLayout.LayoutParams(Ui.dp(this@CourseActivity, 44), Ui.dp(this@CourseActivity, 44)))
    }

    /** Petite tuile chiffrée : libellé, km au mètre près, minutes. */
    private fun tuile(titre: String, couleur: Int, km: Double, min: Double): View = Ui.vertical(this, 4).apply {
        background = Ui.box(this@CourseActivity, Ui.SURFACE, Ui.LINE, 1, 18)
        val p = Ui.dp(this@CourseActivity, 12); setPadding(p, p, p, p)
        addView(LinearLayout(this@CourseActivity).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
            addView(View(this@CourseActivity).apply { background = Ui.box(this@CourseActivity, couleur, couleur, 0, 4) },
                LinearLayout.LayoutParams(Ui.dp(this@CourseActivity, 8), Ui.dp(this@CourseActivity, 8)).apply { marginEnd = Ui.dp(this@CourseActivity, 6) })
            addView(Ui.text(this@CourseActivity, titre, 10f, Ui.MUTED, true).apply { letterSpacing = 0.1f; maxLines = 1 })
        })
        addView(Ui.text(this@CourseActivity, String.format(Locale.FRANCE, "%.3f", km), 22f, Ui.FG).apply { typeface = Ui.LEGER; maxLines = 1 })
        addView(Ui.text(this@CourseActivity, "km · ${min.roundToInt()} min", 12f, Ui.MUTED))
    }

    private fun cadreCarte(vue: View, pts: List<Point>): View = android.widget.FrameLayout(this).apply {
        background = Ui.box(this@CourseActivity, Ui.RAISE, Ui.LINE, 1, 16)
        clipToOutline = true; outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        addView(vue)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this@CourseActivity, 380))
        if (pts.isEmpty()) visibility = View.GONE
    }

    /** Étape de la chronologie : pastille, libellé, heure à la seconde, lieu. */
    private fun etape(c: LinearLayout, couleur: Int, titre: String, heure: String, lieu: String) {
        c.addView(Ui.vertical(this, 2).apply {
            addView(LinearLayout(this@CourseActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
                addView(View(this@CourseActivity).apply { background = Ui.box(this@CourseActivity, couleur, couleur, 0, 5) },
                    LinearLayout.LayoutParams(Ui.dp(this@CourseActivity, 10), Ui.dp(this@CourseActivity, 10)).apply { marginEnd = Ui.dp(this@CourseActivity, 10) })
                addView(Ui.text(this@CourseActivity, titre, 15f, Ui.FG, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                addView(Ui.text(this@CourseActivity, heure, 15f, Ui.FG, true))
            })
            if (lieu.isNotBlank()) addView(W.aide(this@CourseActivity, lieu).apply { setPadding(Ui.dp(this@CourseActivity, 20), 0, 0, 0) })
        })
    }

    private fun precision(pts: List<Point>): String {
        if (pts.size < 2) return "—"
        val km = (1 until pts.size).sumOf { Odometer.distanceM(pts[it - 1].lat, pts[it - 1].lon, pts[it].lat, pts[it].lon) } / 1000
        return "1 point tous les ${(km * 1000 / (pts.size - 1)).roundToInt()} m en moyenne"
    }

    private fun supprimerSegment(sg: Segment) {
        W.confirmer(this, "Supprimer ce trajet ?", "${sg.nom} · ${Analyzer.fmt2(sg.km)} km\n\nIl disparaît du carnet kilométrique (les km du jour ne changent pas). C'est définitif.", "Supprimer") {
            store.deleteSegment(sg.debut)
            Toast.makeText(this, "Trajet supprimé", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun choisirPlateforme(r: Ride) {
        val l = Plateforme.TOUTES
        AlertDialog.Builder(this).setTitle("Plateforme")
            .setItems(l.map { it as CharSequence }.toTypedArray()) { _, i -> store.updateRide(r.copy(plateforme = l[i])); construire() }
            .setNegativeButton("Annuler", null).show()
    }

    private fun montant(r: Ride) {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (r.prix > 0) setText(W.n(r.prix))
            hint = "Montant encaissé"
        }
        AlertDialog.Builder(this).setTitle("Montant de la course").setView(e)
            .setPositiveButton("Enregistrer") { _, _ -> W.nombre(e)?.takeIf { it >= 0 }?.let { store.setRidePrice(r.debut, it); construire() } }
            .setNegativeButton("Annuler", null).show()
    }

    private fun supprimer(r: Ride) = Suppression.course(this, store, r) { finish() }

    /** Ouvre Google Maps avec le départ, l'arrivée et quelques points de passage du tracé. */
    private fun googleMaps(pts: List<Point>) {
        fun c(p: Point) = String.format(Locale.US, "%.5f,%.5f", p.lat, p.lon)
        val milieu = pts.drop(1).dropLast(1)
        val etapes = if (milieu.isEmpty()) emptyList() else (1..8).map { milieu[(it * milieu.size / 9).coerceIn(0, milieu.size - 1)] }.distinct()
        val url = "https://www.google.com/maps/dir/?api=1&travelmode=driving&origin=${c(pts.first())}&destination=${c(pts.last())}" +
            (if (etapes.isNotEmpty()) "&waypoints=" + etapes.joinToString("%7C") { c(it) } else "")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {
            Toast.makeText(this, "Aucune appli de carte", Toast.LENGTH_SHORT).show()
        }
    }

    /** Tracé au format GPX (lisible par Google Earth, Strava, les logiciels de cartographie). */
    private fun partagerGpx(debut: Long, prefixe: String, titre: String, pts: List<Point>) {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val nom = "$prefixe-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.FRANCE).format(Date(debut))
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"Bonne Course\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        sb.append("<trk><name>$nom · $titre</name>\n")
        listOf(0 to "Approche", 1 to "Client à bord", 2 to "Trajet domicile").forEach { (ph, lab) ->
            val seg = pts.filter { it.phase == ph }
            if (seg.isNotEmpty()) {
                sb.append("<trkseg><!-- $lab -->\n")
                seg.forEach { sb.append(String.format(Locale.US, "<trkpt lat=\"%.6f\" lon=\"%.6f\"><time>%s</time></trkpt>\n", it.lat, it.lon, iso.format(Date(it.t)))) }
                sb.append("</trkseg>\n")
            }
        }
        sb.append("</trk>\n</gpx>\n")
        val f = File(File(filesDir, "export").apply { mkdirs() }, "$nom.gpx")
        f.writeText(sb.toString())
        val u = FacturePdf.uri(this, f)
        val i = Intent(Intent.ACTION_SEND).setType("application/gpx+xml").putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Partager le tracé"))
    }
}

/** Dessin du tracé (sans carte de fond) : orange pendant l'approche, vert client à bord. */
class TraceView(ctx: Context, private val pts: List<Point>) : View(ctx) {
    private val trait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 4).toFloat(); strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val point = Paint(Paint.ANTI_ALIAS_FLAG)
    private val texte = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.FG; textSize = Ui.dp(ctx, 12).toFloat() }

    init { background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 12) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (pts.size < 2) return
        val m = Ui.dp(context, 22).toFloat()
        val kx = cos(Math.toRadians(pts.map { it.lat }.average()))
        val xs = pts.map { it.lon * kx }; val ys = pts.map { it.lat }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        val sx = (width - 2 * m) / max(1e-9, x1 - x0); val sy = (height - 2 * m) / max(1e-9, y1 - y0)
        val k = minOf(sx, sy)
        val ox = (width - (x1 - x0) * k) / 2; val oy = (height - (y1 - y0) * k) / 2
        fun px(i: Int) = (ox + (xs[i] - x0) * k).toFloat()
        fun py(i: Int) = (height - oy - (ys[i] - y0) * k).toFloat()

        // Un tracé par phase, sans trou entre les deux
        for (ph in 0..1) {
            val path = Path(); var ouvert = false
            for (i in pts.indices) {
                val dans = pts[i].phase == ph || (i > 0 && pts[i - 1].phase == ph)
                if (dans) { if (!ouvert) { path.moveTo(px(i), py(i)); ouvert = true } else path.lineTo(px(i), py(i)) } else ouvert = false
            }
            trait.color = if (ph == 0) Ui.WARN else Ui.GO
            c.drawPath(path, trait)
        }
        val r = Ui.dp(context, 6).toFloat()
        fun marque(i: Int, coul: Int, lab: String) {
            point.color = Ui.BG; c.drawCircle(px(i), py(i), r + Ui.dp(context, 2), point)
            point.color = coul; c.drawCircle(px(i), py(i), r, point)
            c.drawText(lab, px(i) + r + 6, py(i) - r, texte)
        }
        marque(0, Ui.WARN, "acceptée")
        pts.indexOfFirst { it.phase == 1 }.takeIf { it > 0 }?.let { marque(it, Ui.GO, "client") }
        marque(pts.size - 1, Color.WHITE, "arrivée")
    }
}
