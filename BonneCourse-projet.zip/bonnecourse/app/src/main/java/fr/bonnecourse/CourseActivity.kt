package fr.bonnecourse

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt

/** Boîte noire : tout ce qui a été enregistré pour une course, avec son tracé GPS. */
class CourseActivity : AppCompatActivity() {

    companion object { const val EXTRA_COURSE = "course" }

    private lateinit var store: Store
    private var id = 0L
    private lateinit var racine: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        id = intent.getLongExtra(EXTRA_COURSE, 0L)
        racine = Ui.vertical(this, 16).apply { val p = Ui.dp(this@CourseActivity, 18); setPadding(p, p, p, p * 3) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(racine) })
    }

    override fun onResume() {
        super.onResume()
        construire()
    }

    private fun construire() {
        val r = store.ride(id) ?: run { finish(); return }
        val pts = store.trace(r.debut)
        val d = store.profile.devise
        val h = SimpleDateFormat("HH:mm:ss", Locale.FRANCE)
        racine.removeAllViews()

        // En-tête : retour, plateforme, date, montant
        racine.addView(Ui.text(this, "‹  Boîte noire", 15f, Ui.ACCENT, true).apply {
            setPadding(0, Ui.dp(this@CourseActivity, 6), 0, Ui.dp(this@CourseActivity, 4)); setOnClickListener { finish() }
        })
        val tete = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        tete.addView(Ui.vertical(this, 6).apply {
            addView(W.puce(this@CourseActivity, r.source, W.couleurSource(r.source)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(Ui.text(this@CourseActivity, SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(r.debut)).replaceFirstChar { it.uppercase() } +
                " · " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(r.debut)), 15f, Ui.MUTED))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tete.addView(Ui.text(this, if (r.prix > 0) "${Analyzer.fmt2(r.prix)} $d" else "—", 36f, Ui.FG).apply { typeface = Ui.LEGER })
        racine.addView(tete)

        // Carte du trajet
        val carteTrace = W.carte(this, "Trajet")
        if (pts.size >= 2) {
            val cadre = android.widget.FrameLayout(this).apply {
                background = Ui.box(this@CourseActivity, Ui.RAISE, Ui.LINE, 1, 16)
                clipToOutline = true; outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
                addView(try { Carte.vue(this@CourseActivity, r, pts) } catch (_: Exception) { TraceView(this@CourseActivity, pts) })
            }
            carteTrace.addView(cadre, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 340)))
            carteTrace.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(W.pastille(this@CourseActivity, Ui.WARN, "approche"), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(this@CourseActivity, 18) })
                addView(W.pastille(this@CourseActivity, Ui.GO, "client à bord"))
            })
            carteTrace.addView(Ui.buttonRow(this,
                W.bouton(this, "Google Maps", true) { carte(r, pts) },
                W.bouton(this, "Partager (GPX)") { partagerGpx(r, pts) }))
        } else {
            carteTrace.addView(W.aide(this, if (r.manuelle) "Course saisie à la main : pas de tracé GPS." else "Pas de tracé GPS pour cette course (GPS coupé ou course ajoutée depuis un relevé)."))
        }
        racine.addView(carteTrace)

        // Chronologie
        val chrono = W.carte(this, "Chronologie")
        if (!r.manuelle && r.priseEnCharge > r.debut) {
            chrono.addView(W.ligne(this, "Course acceptée", h.format(Date(r.debut))))
            if (r.lieuDepart.isNotBlank()) chrono.addView(W.aide(this, r.lieuDepart))
        }
        chrono.addView(W.ligne(this, "Client à bord", h.format(Date(r.priseEnCharge))))
        if (r.lieuPrise.isNotBlank()) chrono.addView(W.aide(this, r.lieuPrise))
        chrono.addView(W.ligne(this, "Client déposé", h.format(Date(r.fin))))
        if (r.lieuArrivee.isNotBlank()) chrono.addView(W.aide(this, r.lieuArrivee))
        racine.addView(chrono)

        // Chiffres
        val ch = W.carte(this, "Kilomètres et temps")
        if (r.kmApproche > 0 || r.minApproche > 0) ch.addView(W.ligne(this, "Approche", "${r.minApproche.roundToInt()} min · ${Analyzer.fmt2(r.kmApproche)} km"))
        ch.addView(W.ligne(this, "Client à bord", "${r.minCourse.roundToInt()} min · ${Analyzer.fmt2(r.kmCourse)} km"))
        ch.addView(W.ligne(this, "Total", "${r.minTotal.roundToInt()} min · ${Analyzer.fmt2(r.kmTotal)} km", true))
        if (r.prix > 0 && r.kmTotal > 0) ch.addView(W.ligne(this, "Par km roulé", "${Analyzer.fmt2(r.prix / r.kmTotal)} $d"))
        if (r.prix > 0 && r.minTotal > 1) ch.addView(W.ligne(this, "Par heure", "${(r.prix / r.minTotal * 60).roundToInt()} $d"))
        if (r.offreKm > 0) {
            ch.addView(W.ligne(this, "Annoncé par l'offre", "${r.offreMin.roundToInt()} min · ${Analyzer.fmt1(r.offreKm)} km"))
            val v = runCatching { Verdict.valueOf(r.verdict) }.getOrNull()
            if (v != null) ch.addView(W.ligne(this, "Verdict de la bulle", "${v.mot} · ${Analyzer.fmt1(r.score)}/10", couleur = Ui.color(v)))
        }
        ch.addView(W.ligne(this, "Points GPS enregistrés", "${pts.size}"))
        racine.addView(ch)

        // Actions
        val act = W.carte(this, "Modifier")
        if (r.prive) {
            act.addView(W.bouton(this, if (r.facture.isNotBlank()) "Facture ${r.facture}" else "Faire signer et facturer", true, if (r.facture.isNotBlank()) Ui.ACCENT else Ui.GO) {
                startActivity(Intent(this, FactureActivity::class.java).putExtra(FactureActivity.EXTRA_COURSE, r.debut))
            })
        } else {
            act.addView(W.bouton(this, "Plateforme : ${r.source}") { choisirPlateforme(r) })
        }
        if (r.facture.isBlank()) act.addView(W.bouton(this, "Corriger le montant") { montant(r) })
        racine.addView(act)
        if (r.facture.isBlank()) racine.addView(W.boutonDanger(this, "Supprimer cette course") { supprimer(r) })
        else racine.addView(W.aide(this, "Course facturée : elle est conservée (une facture ne se supprime pas)."))
    }

    private fun choisirPlateforme(r: Ride) {
        val l = Plateforme.TOUTES
        AlertDialog.Builder(this).setTitle("Plateforme")
            .setItems(l.map { it as CharSequence }.toTypedArray()) { _, i -> store.updateRide(r.copy(plateforme = l[i])); construire() }
            .setNegativeButton("Annuler", null).show()
    }

    private fun montant(r: Ride) {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (r.prix > 0) setText(W.n(r.prix))
            hint = "Montant encaissé"
        }
        AlertDialog.Builder(this).setTitle("Montant de la course").setView(e)
            .setPositiveButton("Enregistrer") { _, _ -> W.nombre(e)?.takeIf { it >= 0 }?.let { store.setRidePrice(r.debut, it); construire() } }
            .setNegativeButton("Annuler", null).show()
    }

    private fun supprimer(r: Ride) {
        if (r.facture.isNotBlank()) {
            Toast.makeText(this, "Course facturée (${r.facture}) : elle ne peut pas être supprimée.", Toast.LENGTH_LONG).show()
            return
        }
        W.confirmer(this, "Supprimer cette course ?",
            "Elle disparaît de la boîte noire, avec son tracé GPS, et du chiffre d'affaires. C'est définitif.", "Supprimer") {
            store.deleteRide(r.debut); store.supprimerBrouillon(r.debut)
            Toast.makeText(this, "Course supprimée", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    /** Ouvre Google Maps avec le départ, l'arrivée et quelques points de passage du tracé. */
    private fun carte(r: Ride, pts: List<Point>) {
        fun c(p: Point) = String.format(Locale.US, "%.5f,%.5f", p.lat, p.lon)
        val milieu = pts.drop(1).dropLast(1)
        val etapes = if (milieu.isEmpty()) emptyList() else (1..8).map { milieu[(it * milieu.size / 9).coerceIn(0, milieu.size - 1)] }.distinct()
        val url = "https://www.google.com/maps/dir/?api=1&travelmode=driving&origin=${c(pts.first())}&destination=${c(pts.last())}" +
            (if (etapes.isNotEmpty()) "&waypoints=" + etapes.joinToString("%7C") { c(it) } else "")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {
            Toast.makeText(this, "Aucune appli de carte", Toast.LENGTH_SHORT).show()
        }
    }

    /** Tracé au format GPX (lisible par Google Earth, Strava, les logiciels de cartographie). */
    private fun partagerGpx(r: Ride, pts: List<Point>) {
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val nom = "course-" + SimpleDateFormat("yyyy-MM-dd-HHmm", Locale.FRANCE).format(Date(r.debut))
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"Bonne Course\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        sb.append("<trk><name>$nom · ${r.source}</name>\n")
        listOf(0 to "Approche", 1 to "Client à bord").forEach { (ph, lab) ->
            val seg = pts.filter { it.phase == ph }
            if (seg.isNotEmpty()) {
                sb.append("<trkseg><!-- $lab -->\n")
                seg.forEach { sb.append(String.format(Locale.US, "<trkpt lat=\"%.6f\" lon=\"%.6f\"><time>%s</time></trkpt>\n", it.lat, it.lon, iso.format(Date(it.t)))) }
                sb.append("</trkseg>\n")
            }
        }
        sb.append("</trk>\n</gpx>\n")
        val f = File(File(filesDir, "export").apply { mkdirs() }, "$nom.gpx")
        f.writeText(sb.toString())
        val u = FacturePdf.uri(this, f)
        val i = Intent(Intent.ACTION_SEND).setType("application/gpx+xml").putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Partager le tracé"))
    }
}

/** Dessin du tracé (sans carte de fond) : orange pendant l'approche, vert client à bord. */
class TraceView(ctx: Context, private val pts: List<Point>) : View(ctx) {
    private val trait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 4).toFloat(); strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val point = Paint(Paint.ANTI_ALIAS_FLAG)
    private val texte = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.FG; textSize = Ui.dp(ctx, 12).toFloat() }

    init { background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 12) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (pts.size < 2) return
        val m = Ui.dp(context, 22).toFloat()
        val kx = cos(Math.toRadians(pts.map { it.lat }.average()))
        val xs = pts.map { it.lon * kx }; val ys = pts.map { it.lat }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        val sx = (width - 2 * m) / max(1e-9, x1 - x0); val sy = (height - 2 * m) / max(1e-9, y1 - y0)
        val k = minOf(sx, sy)
        val ox = (width - (x1 - x0) * k) / 2; val oy = (height - (y1 - y0) * k) / 2
        fun px(i: Int) = (ox + (xs[i] - x0) * k).toFloat()
        fun py(i: Int) = (height - oy - (ys[i] - y0) * k).toFloat()

        // Un tracé par phase, sans trou entre les deux
        for (ph in 0..1) {
            val path = Path(); var ouvert = false
            for (i in pts.indices) {
                val dans = pts[i].phase == ph || (i > 0 && pts[i - 1].phase == ph)
                if (dans) { if (!ouvert) { path.moveTo(px(i), py(i)); ouvert = true } else path.lineTo(px(i), py(i)) } else ouvert = false
            }
            trait.color = if (ph == 0) Ui.WARN else Ui.GO
            c.drawPath(path, trait)
        }
        val r = Ui.dp(context, 6).toFloat()
        fun marque(i: Int, coul: Int, lab: String) {
            point.color = Ui.BG; c.drawCircle(px(i), py(i), r + Ui.dp(context, 2), point)
            point.color = coul; c.drawCircle(px(i), py(i), r, point)
            c.drawText(lab, px(i) + r + 6, py(i) - r, texte)
        }
        marque(0, Ui.WARN, "acceptée")
        pts.indexOfFirst { it.phase == 1 }.takeIf { it > 0 }?.let { marque(it, Ui.GO, "client") }
        marque(pts.size - 1, Color.WHITE, "arrivée")
    }
}
