package fr.bonnecourse

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.graphics.Typeface
import android.widget.TextView
import android.widget.ImageView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Briques d'écran communes (cartes, champs, lignes, boutons), style noir et or, pour des écrans courts et homogènes. */
object W {
    fun carte(ctx: Context, titre: String? = null) = Ui.vertical(ctx, 12).apply {
        background = Ui.box(ctx, Ui.SURFACE, Ui.LINE, 1, 22)
        val p = Ui.dp(ctx, 18); setPadding(p, p, p, p)
        if (titre != null) addView(Ui.text(ctx, titre.uppercase(), 12f, Ui.MUTED, true).apply { letterSpacing = 0.14f })
    }

    /** Bouton : principal = plein (or par défaut), sinon contour discret. */
    fun bouton(ctx: Context, s: String, principal: Boolean = false, couleur: Int = Ui.ACCENT, onClick: () -> Unit) = TextView(ctx).apply {
        text = s; textSize = 16f; typeface = Ui.MEDIUM; gravity = Gravity.CENTER
        setTextColor(if (principal) Ui.BG else Ui.FG)
        minHeight = Ui.dp(ctx, 52)
        val ph = Ui.dp(ctx, 16); val pv = Ui.dp(ctx, 12); setPadding(ph, pv, ph, pv)
        background = Ui.box(ctx, if (principal) couleur else Ui.RAISE, if (principal) couleur else Ui.LINE, 1, 16)
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    /** Bouton rouge discret pour les suppressions. */
    fun boutonDanger(ctx: Context, s: String, onClick: () -> Unit) = bouton(ctx, s) { onClick() }.apply {
        setTextColor(Ui.STOP)
        background = Ui.box(ctx, Ui.SURFACE, Color.parseColor("#4A2421"), 1, 16)
    }

    /** Champ de saisie avec son intitulé au-dessus. */
    fun champ(ctx: Context, parent: LinearLayout, label: String, valeur: String = "", type: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES,
              indice: String = "", lignes: Int = 1): EditText {
        parent.addView(Ui.text(ctx, label, 13f, Ui.MUTED))
        val e = EditText(ctx).apply {
            inputType = type; setText(valeur); hint = indice
            setTextColor(Ui.FG); setHintTextColor(Color.parseColor("#4A4F58")); textSize = 17f
            background = Ui.box(ctx, Ui.RAISE, Ui.LINE, 1, 14)
            val ph = Ui.dp(ctx, 14); val pv = Ui.dp(ctx, 12); setPadding(ph, pv, ph, pv)
            if (lignes > 1) { minLines = lignes; inputType = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE; gravity = Gravity.TOP }
        }
        parent.addView(e)
        return e
    }

    const val NOMBRE = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    const val EMAIL = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    const val TEL = InputType.TYPE_CLASS_PHONE
    const val NOM = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS

    fun nombre(e: EditText) = e.text.toString().replace(',', '.').replace(" ", "").replace("€", "").toDoubleOrNull()
    fun txt(e: EditText) = e.text.toString().trim()

    fun n(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.FRANCE, "%.2f", v).trimEnd('0').trimEnd(',')

    /** Ligne « libellé ............ valeur ». */
    fun ligne(ctx: Context, a: String, b: String, fort: Boolean = false, couleur: Int = Ui.FG) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(Ui.text(ctx, a, 15f, if (fort) Ui.FG else Ui.MUTED, fort), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(Ui.text(ctx, b, 15f, couleur, true))
    }

    /** Gros chiffre élégant avec sa légende. */
    fun hero(ctx: Context, valeur: String, legende: String, couleur: Int = Ui.FG) = Ui.vertical(ctx, 2).apply {
        addView(Ui.text(ctx, valeur, 42f, couleur).apply { typeface = Ui.LEGER; letterSpacing = -0.01f })
        addView(Ui.text(ctx, legende, 13f, Ui.MUTED))
    }

    /** Pastille de couleur + texte (légende ou plateforme). */
    fun pastille(ctx: Context, couleur: Int, s: String, sp: Float = 13f) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(View(ctx).apply { background = Ui.box(ctx, couleur, couleur, 0, 5) },
            LinearLayout.LayoutParams(Ui.dp(ctx, 10), Ui.dp(ctx, 10)).apply { marginEnd = Ui.dp(ctx, 8) })
        addView(Ui.text(ctx, s, sp, Ui.FG))
    }

    /** Étiquette arrondie (plateforme, statut). */
    fun puce(ctx: Context, s: String, couleur: Int) = Ui.text(ctx, s, 12f, couleur, true).apply {
        val ph = Ui.dp(ctx, 10); val pv = Ui.dp(ctx, 4); setPadding(ph, pv, ph, pv)
        background = Ui.box(ctx, Color.argb(38, Color.red(couleur), Color.green(couleur), Color.blue(couleur)), Color.TRANSPARENT, 0, 20)
    }

    /** Icône vectorielle teintée. */
    fun icone(ctx: Context, res: Int, couleur: Int, tailleDp: Int = 24) = ImageView(ctx).apply {
        setImageResource(res); setColorFilter(couleur)
        layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, tailleDp), Ui.dp(ctx, tailleDp))
    }

    /** Couleur de chaque source de revenu (palette vérifiée pour le daltonisme sur fond sombre). */
    fun couleurSource(s: String): Int = when (s) {
        "Uber" -> Color.parseColor("#3987E5")
        "Bolt" -> Color.parseColor("#199E70")
        "Privé" -> Color.parseColor("#D95926")
        "Heetch" -> Color.parseColor("#D55181")
        "FreeNow" -> Color.parseColor("#9085E9")
        else -> Color.parseColor("#8A96A1")
    }

    /** Navigation de mois « ‹  Novembre 2026  › ». */
    fun navMois(ctx: Context, titre: String, onPrev: () -> Unit, onNext: () -> Unit) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = Ui.box(ctx, Ui.SURFACE, Ui.LINE, 1, 30)
        val p = Ui.dp(ctx, 4); setPadding(p, p, p, p)
        fun fleche(s: String, f: () -> Unit) = Ui.text(ctx, s, 22f, Ui.ACCENT).apply {
            gravity = Gravity.CENTER
            background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 30)
            setOnClickListener { f() }
        }
        val d = Ui.dp(ctx, 44)
        addView(fleche("‹", onPrev), LinearLayout.LayoutParams(d, d))
        addView(Ui.text(ctx, titre, 17f, Ui.FG, true).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(fleche("›", onNext), LinearLayout.LayoutParams(d, d))
    }

    val MOIS = listOf("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre")

    fun nomMois(annee: Int, mois: Int) = "${MOIS[mois - 1].replaceFirstChar { it.uppercase() }} $annee"

    fun eur(x: Double) = String.format(Locale.FRANCE, "%,.0f €", x)
    fun eur2(x: Double) = String.format(Locale.FRANCE, "%,.2f €", x)

    /** Texte d'aide discret. */
    fun aide(ctx: Context, s: String) = Ui.text(ctx, s, 13f, Ui.MUTED).apply { setLineSpacing(0f, 1.15f) }

    fun titreEcran(ctx: Context, s: String) = Ui.text(ctx, s, 30f).apply {
        typeface = Ui.MEDIUM; letterSpacing = -0.01f
        setPadding(0, Ui.dp(ctx, 8), 0, 0)
    }

    /** En-tête de marque : « La Bonne Course » en or, filet doré, « VTC · CHAUFFEUR PRIVÉ ». */
    fun marque(ctx: Context) = Ui.vertical(ctx, 6).apply {
        setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 4))
        addView(Ui.text(ctx, "La Bonne Course", 30f, Ui.ACCENT).apply { typeface = Typeface.create("serif", Typeface.ITALIC); letterSpacing = -0.01f })
        addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(View(ctx).apply { setBackgroundColor(Ui.ACCENT) }, LinearLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 1)).apply { marginEnd = Ui.dp(ctx, 10) })
            addView(Ui.text(ctx, "VTC · CHAUFFEUR PRIVÉ", 11f, Ui.MUTED, true).apply { letterSpacing = 0.22f })
        })
    }

    /** Demande de confirmation avant une action définitive. */
    fun confirmer(ctx: Context, titre: String, message: String?, action: String, onOui: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(ctx).setTitle(titre).setMessage(message)
            .setPositiveButton(action) { _, _ -> onOui() }
            .setNegativeButton("Annuler", null).show()
    }
}

/**
 * Zone de signature au doigt (fond blanc, trait noir), comme sur un terminal de livraison.
 * Empêche le défilement de l'écran pendant que le client signe.
 */
class SignaturePad(ctx: Context) : View(ctx) {
    private val path = Path()
    private val trait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 3).toFloat()
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private var minX = Float.MAX_VALUE; private var minY = Float.MAX_VALUE
    private var maxX = 0f; private var maxY = 0f
    private var longueur = 0f
    private var lx = 0f; private var ly = 0f
    var onChange: (() -> Unit)? = null

    /** Vide tant que le tracé est trop court pour être une vraie signature. */
    val vide get() = longueur < Ui.dp(context, 60)

    init { background = Ui.box(ctx, Color.WHITE, Ui.LINE, 1, 12) }

    fun effacer() {
        path.reset(); longueur = 0f
        minX = Float.MAX_VALUE; minY = Float.MAX_VALUE; maxX = 0f; maxY = 0f
        invalidate(); onChange?.invoke()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); path.moveTo(x, y); path.lineTo(x + 0.1f, y) }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.historySize) { path.lineTo(e.getHistoricalX(i), e.getHistoricalY(i)) }
                path.lineTo(x, y)
                longueur += kotlin.math.hypot(x - lx, y - ly)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); onChange?.invoke() }
        }
        lx = x; ly = y
        minX = min(minX, x); minY = min(minY, y); maxX = max(maxX, x); maxY = max(maxY, y)
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawPath(path, trait)
        if (longueur == 0f) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9AA3AB"); textSize = Ui.dp(context, 15).toFloat(); textAlign = Paint.Align.CENTER }
            c.drawText("Le client signe ici avec le doigt", width / 2f, height / 2f, p)
        }
    }

    /** Image de la signature, recadrée, fond blanc. */
    fun image(): Bitmap {
        val m = Ui.dp(context, 12).toFloat()
        val l = max(0f, minX - m); val t = max(0f, minY - m)
        val r = min(width.toFloat(), maxX + m); val b = min(height.toFloat(), maxY + m)
        val w = max(1, (r - l).toInt()); val h = max(1, (b - t).toInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.translate(-l, -t)
        c.drawPath(path, trait)
        return bmp
    }
}
