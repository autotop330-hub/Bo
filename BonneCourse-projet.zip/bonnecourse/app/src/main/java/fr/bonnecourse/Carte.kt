package fr.bonnecourse

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vraie carte du trajet (plan OpenStreetMap, sans clé ni compte), dessinée par Leaflet dans une WebView.
 * Leaflet est fourni avec l'appli ; seul le fond de plan vient d'internet.
 */
object Carte {
    @Volatile private var modele: String? = null

    private fun modele(ctx: Context): String = modele ?: run {
        fun lire(n: String) = ctx.assets.open(n).bufferedReader().use { it.readText() }
        lire("carte.html").replace("/*LEAFLET_CSS*/", lire("leaflet.css")).replace("/*LEAFLET_JS*/", lire("leaflet.js"))
            .also { modele = it }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    fun vue(ctx: Context, r: Ride, pts: List<Point>): WebView {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        fun ll(p: Point) = JSONArray().put(p.lat).put(p.lon)
        val app = pts.filter { it.phase == 0 }
        val cou = pts.filter { it.phase == 1 }
        // L'approche rejoint le premier point « client à bord » pour un tracé continu
        val appArr = JSONArray().apply { app.forEach { put(ll(it)) }; cou.firstOrNull()?.let { if (app.isNotEmpty()) put(ll(it)) } }
        val couArr = JSONArray().apply { cou.forEach { put(ll(it)) } }
        val d = JSONObject()
            .put("approche", appArr).put("course", couArr)
            .put("depart", app.firstOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("client", cou.firstOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("arrivee", pts.lastOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("lDepart", "Acceptée " + h.format(Date(r.debut)))
            .put("lClient", "Client " + h.format(Date(r.priseEnCharge)))
            .put("lArrivee", "Arrivée " + h.format(Date(r.fin)))
        val html = modele(ctx).replace("/*DONNEES*/", d.toString())
        return WebView(ctx).apply {
            setBackgroundColor(Color.parseColor("#16181D"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()   // les liens restent dans la carte
            isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
            // La carte se déplace au doigt sans faire défiler l'écran
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
            // Adresse https fictive : le serveur de cartes exige une page d'origine
            loadDataWithBaseURL("https://bonnecourse.app/", html, "text/html", "utf-8", null)
        }
    }
}
