package fr.bonnecourse

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vraie carte du trajet (plan OpenStreetMap, sans clé ni compte), dessinée par Leaflet dans une WebView.
 * Leaflet est fourni avec l'appli ; seul le fond de plan vient d'internet.
 */
object Carte {
    /** Retient le script à lancer quand la page est prête (tracé recalé arrivé avant la fin du chargement). */
    private class Client : WebViewClient() {
        var pret = false
        var enAttente: String? = null
        override fun onPageFinished(view: WebView, url: String?) {
            pret = true
            enAttente?.let { view.evaluateJavascript(it, null) }
            enAttente = null
        }
    }

    /** Affiche le tracé recalé sur les routes : {"approche":[[lat,lon]…],"course":[…],"domicile":[…]}. */
    fun afficherRoute(w: WebView, json: String) {
        val js = "window.routeRecalee && routeRecalee($json)"
        val c = w.webViewClient as? Client
        if (c == null || c.pret) w.evaluateJavascript(js, null) else c.enAttente = js
    }

    /** Calcule (ou reprend du cache) le tracé recalé d'une course ou d'un trajet domicile, puis l'affiche. */
    fun recalerPuisAfficher(w: WebView, store: Store, cleCache: String, pts: List<Point>) {
        val cle = store.cleTomTom
        store.routeRecalee(cleCache)?.let { afficherRoute(w, it); return }
        if (cle.isBlank() || pts.size < 2) return
        Thread {
            val o = JSONObject()
            listOf(0 to "approche", 1 to "course", 2 to "domicile").forEach { (ph, nom) ->
                var seg = pts.filter { it.phase == ph }
                // L'approche rejoint le 1er point « client à bord » pour un tracé continu
                if (ph == 0) pts.firstOrNull { it.phase == 1 }?.let { seg = seg + it }
                if (seg.size >= 2) Trafic.recaler(cle, seg)?.let { r -> o.put(nom, JSONArray().apply { r.forEach { put(JSONArray().put(it.first).put(it.second)) } }) }
            }
            if (o.length() == 0) return@Thread
            val json = o.toString()
            store.saveRouteRecalee(cleCache, json)
            w.post { afficherRoute(w, json) }
        }.start()
    }

    @Volatile private var modele: String? = null

    private fun modele(ctx: Context): String = modele ?: run {
        fun lire(n: String) = ctx.assets.open(n).bufferedReader().use { it.readText() }
        lire("carte.html").replace("/*LEAFLET_CSS*/", lire("leaflet.css")).replace("/*LEAFLET_JS*/", lire("leaflet.js"))
            .also { modele = it }
    }

    fun vue(ctx: Context, r: Ride, pts: List<Point>): WebView {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        fun ll(p: Point) = JSONArray().put(p.lat).put(p.lon)
        val app = pts.filter { it.phase == 0 }
        val cou = pts.filter { it.phase == 1 }
        // L'approche rejoint le premier point « client à bord » pour un tracé continu
        val appArr = JSONArray().apply { app.forEach { put(ll(it)) }; cou.firstOrNull()?.let { if (app.isNotEmpty()) put(ll(it)) } }
        val couArr = JSONArray().apply { cou.forEach { put(ll(it)) } }
        val d = JSONObject()
            .put("approche", appArr).put("course", couArr)
            .put("depart", app.firstOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("client", cou.firstOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("arrivee", pts.lastOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("lDepart", "Acceptée " + h.format(Date(r.debut)))
            .put("lClient", "Client " + h.format(Date(r.priseEnCharge)))
            .put("lArrivee", "Arrivée " + h.format(Date(r.fin)))
        return webView(ctx, d)
    }

    /** Trajet domicile ↔ service. */
    fun vueSegment(ctx: Context, sg: Segment, pts: List<Point>): WebView {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        fun ll(p: Point) = JSONArray().put(p.lat).put(p.lon)
        val d = JSONObject()
            .put("approche", JSONArray()).put("course", JSONArray())
            .put("domicile", JSONArray().apply { pts.forEach { put(ll(it)) } })
            .put("depart", pts.firstOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("client", JSONObject.NULL)
            .put("arrivee", pts.lastOrNull()?.let { ll(it) } ?: JSONObject.NULL)
            .put("lDepart", (if (sg.type == Segment.DEPART) "Domicile " else "Départ ") + h.format(Date(sg.debut)))
            .put("lClient", "")
            .put("lArrivee", (if (sg.type == Segment.RETOUR) "Domicile " else "1re course ") + h.format(Date(sg.fin)))
        return webView(ctx, d)
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun webView(ctx: Context, d: JSONObject): WebView {
        val html = modele(ctx).replace("/*DONNEES*/", d.toString())
        return WebView(ctx).apply {
            setBackgroundColor(Color.parseColor("#171B23"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = Client()   // les liens restent dans la carte
            isVerticalScrollBarEnabled = false; isHorizontalScrollBarEnabled = false
            // La carte se déplace au doigt sans faire défiler l'écran
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
            // Adresse https fictive : le serveur de cartes exige une page d'origine
            loadDataWithBaseURL("https://bonnecourse.app/", html, "text/html", "utf-8", null)
        }
    }
}
