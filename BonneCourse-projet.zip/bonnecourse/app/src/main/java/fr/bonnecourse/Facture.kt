package fr.bonnecourse

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Facture PDF d'une course privée et envoi par Outlook.
 *
 * Mentions : vendeur (dénomination, forme, capital, siège, SIRET, RCS, TVA intracommunautaire),
 * n° d'inscription au registre VTC, client (et son SIREN s'il est professionnel), numéro unique
 * chronologique, dates d'émission et de la prestation, désignation, quantité, prix unitaire HT,
 * taux et montant de TVA, totaux HT et TTC, date et mode de paiement, catégorie de l'opération
 * (prestation de services), pénalités de retard et indemnité de 40 € pour un client professionnel,
 * réservation préalable (date et heure de réservation, de prise en charge et lieu).
 */
object FacturePdf {
    const val AUTORITE = "fr.bonnecourse.fichiers"
    const val OUTLOOK = "com.microsoft.office.outlook"
    const val TVA_VTC = 10.0

    private val loc = Locale.FRANCE
    private val jour = SimpleDateFormat("dd/MM/yyyy", loc)
    private val heure = SimpleDateFormat("HH:mm", loc)

    fun dossier(ctx: Context) = File(ctx.filesDir, "factures").apply { mkdirs() }

    /** Logo choisi dans les Réglages, sinon le logo La Bonne Course fourni avec l'appli. */
    fun fichierLogo(ctx: Context) = File(ctx.filesDir, "logo.png")

    fun logo(ctx: Context): android.graphics.Bitmap? = try {
        val f = fichierLogo(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)
        else BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_facture)
    } catch (_: Exception) { null }
    fun fichier(ctx: Context, numero: String) = File(dossier(ctx), "Facture-$numero.pdf")

    private fun eur(x: Double) = String.format(loc, "%,.2f €", x)
    private fun lieu(s: String) = s.substringBefore(" (").ifBlank { s }

    /** Montants : (HT, TVA, TTC) à partir du prix TTC encaissé. */
    fun montants(ttc: Double, tva: Boolean): Triple<Double, Double, Double> {
        if (!tva) return Triple(ttc, 0.0, ttc)
        val ht = Math.round(ttc / (1 + TVA_VTC / 100) * 100) / 100.0
        return Triple(ht, Math.round((ttc - ht) * 100) / 100.0, ttc)
    }

    /** Crée (ou recrée, après modification du client) le PDF de la facture. */
    fun creer(ctx: Context, e: Entreprise, p: Profile, r: Ride, f: Facture): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        dessiner(page.canvas, e, p, r, f, logo(ctx))
        doc.finishPage(page)
        val out = fichier(ctx, f.numero)
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
        return out
    }

    private fun dessiner(c: Canvas, e: Entreprise, p: Profile, r: Ride, f: Facture, logo: android.graphics.Bitmap?) {
        val noir = Color.parseColor("#111418")
        val gris = Color.parseColor("#5C6670")
        val trait = Color.parseColor("#D5DADF")
        val fond = Color.parseColor("#F2F4F6")
        val accent = Color.parseColor("#1F5FA8")
        fun tp(size: Float, bold: Boolean = false, color: Int = noir) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        /** Texte sur plusieurs lignes ; renvoie la hauteur occupée. */
        fun bloc(t: String, x: Float, y: Float, w: Float, paint: TextPaint, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): Float {
            val l = StaticLayout.Builder.obtain(t, 0, t.length, paint, w.toInt()).setAlignment(align).setLineSpacing(1.5f, 1f).build()
            c.save(); c.translate(x, y); l.draw(c); c.restore()
            return l.height.toFloat()
        }
        val ligne = Paint().apply { color = trait; strokeWidth = 0.8f }
        val m = 40f
        val w = 595f - 2 * m
        var y = m

        // --- Logo (gauche) et titre (droite)
        bloc("FACTURE", m + w * 0.55f, y, w * 0.45f, tp(22f, true, accent), Layout.Alignment.ALIGN_OPPOSITE)
        bloc("N° ${f.numero}\nDate d'émission : ${jour.format(Date(f.emission))}", m + w * 0.55f, y + 30, w * 0.45f,
            tp(9.5f, true), Layout.Alignment.ALIGN_OPPOSITE)
        if (logo != null) {
            val k = minOf(140f / logo.width, 90f / logo.height)
            val lw = logo.width * k; val lh = logo.height * k
            c.drawBitmap(logo, null, RectF(m, y, m + lw, y + lh), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            y += maxOf(lh, 62f) + 10
        }

        // --- Vendeur
        val vendeur = buildString {
            append(e.raisonSociale.ifBlank { "(raison sociale)" })
            append("\n").append(listOf(e.forme, e.capital.takeIf { it.isNotBlank() }?.let { "au capital de $it €" }).filterNotNull().joinToString(" "))
            if (e.adresse.isNotBlank()) append("\n").append(e.adresse)
            append("\nSIRET ").append(e.siret.ifBlank { "—" })
            if (e.rcs.isNotBlank()) append(" · RCS ").append(e.rcs)
            if (e.tvaIntra.isNotBlank()) append("\nTVA intracommunautaire ").append(e.tvaIntra)
            append("\nExploitant VTC n° ").append(e.evtc.ifBlank { "—" })
            listOf(e.tel, e.email).filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { append("\n").append(it.joinToString(" · ")) }
        }
        val hv = bloc(vendeur.substringBefore("\n"), m, y, w * 0.6f, tp(14f, true))
        val hv2 = bloc(vendeur.substringAfter("\n", ""), m, y + hv + 2, w * 0.6f, tp(8.5f, color = gris))
        y +=(if (logo == null) maxOf(hv + hv2 + 2, 62f) else hv + hv2 + 2) + 16

        // --- Client
        val cl = f.client
        val client = buildString {
            if (cl.societe.isNotBlank()) append(cl.societe).append("\n")
            append(cl.nom.ifBlank { "—" })
            if (cl.siren.isNotBlank()) append("\nSIREN ").append(cl.siren)
            if (cl.adresse.isNotBlank()) append("\n").append(cl.adresse)
            listOf(cl.email, cl.tel).filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { append("\n").append(it.joinToString(" · ")) }
        }
        val boxL = w * 0.48f
        val hc = bloc(client, m + 10, y + 22, boxL - 20, tp(9.5f))
        // --- Réservation préalable
        val resa = buildString {
            if (f.reservation > 0) append("Réservée le ${jour.format(Date(f.reservation))} à ${heure.format(Date(f.reservation))}\n")
            append("Prise en charge le ${jour.format(Date(r.priseEnCharge))} à ${heure.format(Date(r.priseEnCharge))}\n")
            append(lieu(r.lieuPrise).ifBlank { "—" }).append("\n")
            append("Dépose à ${heure.format(Date(r.fin))}\n")
            append(lieu(r.lieuArrivee).ifBlank { "—" })
            if (r.kmCourse > 0) append("\nDistance : ${Analyzer.fmt1(r.kmCourse)} km · durée : ${Math.round(r.minCourse)} min")
        }
        val hr = bloc(resa, m + boxL + 20, y + 22, w - boxL - 30, tp(9.5f))
        val hBox = maxOf(hc, hr) + 32
        val pBox = Paint().apply { color = fond }
        c.drawRoundRect(RectF(m, y, m + boxL, y + hBox), 6f, 6f, pBox)
        c.drawRoundRect(RectF(m + boxL + 10, y, m + w, y + hBox), 6f, 6f, pBox)
        bloc("FACTURÉ À", m + 10, y + 7, boxL, tp(8f, true, gris))
        bloc("COURSE SUR RÉSERVATION PRÉALABLE", m + boxL + 20, y + 7, w - boxL - 30, tp(8f, true, gris))
        // Redessine les textes par-dessus les fonds
        bloc(client, m + 10, y + 22, boxL - 20, tp(9.5f))
        bloc(resa, m + boxL + 20, y + 22, w - boxL - 30, tp(9.5f))
        y += hBox + 22

        // --- Tableau
        val (ht, tva, ttc) = montants(r.prix, p.tva)
        val cols = floatArrayOf(m, m + w * 0.50f, m + w * 0.60f, m + w * 0.77f, m + w * 0.86f)
        val enTete = listOf("Désignation", "Qté", "P.U. HT", "TVA", "Total HT")
        c.drawRect(m, y, m + w, y + 22, Paint().apply { color = accent })
        enTete.forEachIndexed { i, t ->
            val right = i > 0
            val x0 = cols[i]; val x1 = if (i < 4) cols[i + 1] else m + w
            bloc(t, x0 + 6, y + 6, x1 - x0 - 12, tp(8.5f, true, Color.WHITE), if (right) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL)
        }
        y += 22
        val designation = "Transport de personne en VTC (voiture de transport avec chauffeur)\n" +
            "Le ${jour.format(Date(r.priseEnCharge))} : ${lieu(r.lieuPrise).substringAfterLast(", ").ifBlank { "départ" }} → " +
            lieu(r.lieuArrivee).substringAfterLast(", ").ifBlank { "arrivée" }
        val hd = bloc(designation, cols[0] + 6, y + 8, cols[1] - cols[0] - 12, tp(9f))
        val valeurs = listOf("1", eur(ht), if (p.tva) "10 %" else "—", eur(ht))
        valeurs.forEachIndexed { i, t ->
            val x0 = cols[i + 1]; val x1 = if (i + 1 < 4) cols[i + 2] else m + w
            bloc(t, x0 + 6, y + 8, x1 - x0 - 12, tp(9f), Layout.Alignment.ALIGN_OPPOSITE)
        }
        y += hd + 16
        c.drawLine(m, y, m + w, y, ligne)
        y += 10

        // --- Totaux
        val xt = m + w * 0.55f
        fun total(lab: String, v: String, fort: Boolean = false) {
            bloc(lab, xt, y, w * 0.25f, tp(if (fort) 11f else 9.5f, fort))
            bloc(v, xt + w * 0.25f, y, w * 0.20f, tp(if (fort) 11f else 9.5f, fort), Layout.Alignment.ALIGN_OPPOSITE)
            y += if (fort) 20 else 16
        }
        total("Total HT", eur(ht))
        if (p.tva) total("TVA 10 %", eur(tva)) else total("TVA", "0,00 €")
        c.drawLine(xt, y, m + w, y, ligne); y += 6
        total("Total TTC", eur(ttc), true)
        y += 10

        // --- Paiement et mentions
        val mentions = buildString {
            append("Payée le ${jour.format(Date(r.fin))}" + (if (f.paiement.isNotBlank()) " par ${f.paiement.lowercase()}" else "") + ". ")
            append("Catégorie de l'opération : prestation de services. Pas d'escompte pour paiement anticipé.")
            if (!p.tva) append("\nTVA non applicable, art. 293 B du CGI.")
            if (cl.pro) append("\nEn cas de retard de paiement : pénalités au taux de 3 fois le taux d'intérêt légal " +
                "et indemnité forfaitaire de 40 € pour frais de recouvrement (art. L441-10 du code de commerce).")
        }
        y += bloc(mentions, m, y, w, tp(8.5f, color = gris)) + 18

        // --- Signature du client
        bloc("SIGNATURE DU CLIENT · course effectuée", m, y, w * 0.6f, tp(8f, true, gris))
        y += 14
        val cadre = RectF(m, y, m + 220f, y + 90f)
        c.drawRoundRect(cadre, 6f, 6f, Paint().apply { style = Paint.Style.STROKE; color = trait; strokeWidth = 1f })
        if (f.signature.isNotBlank()) BitmapFactory.decodeFile(f.signature)?.let { b ->
            val k = minOf((cadre.width() - 10) / b.width, (cadre.height() - 10) / b.height)
            val bw = b.width * k; val bh = b.height * k
            val x0 = cadre.centerX() - bw / 2; val y0 = cadre.centerY() - bh / 2
            c.drawBitmap(b, null, RectF(x0, y0, x0 + bw, y0 + bh), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        if (f.signeLe > 0) bloc("Signé le ${jour.format(Date(f.signeLe))} à ${heure.format(Date(f.signeLe))}", m + 232, y + 72, w - 232, tp(8.5f, color = gris))

        // --- Pied de page
        val pied = listOf(e.raisonSociale, e.forme + (if (e.capital.isNotBlank()) " au capital de ${e.capital} €" else ""),
            e.adresse, "SIRET ${e.siret}").filter { it.isNotBlank() }.joinToString(" · ")
        c.drawLine(m, 842f - m - 14, m + w, 842f - m - 14, ligne)
        bloc(pied, m, 842f - m - 8, w, tp(7.5f, color = gris), Layout.Alignment.ALIGN_CENTER)
    }

    /** Facture d'exemple (fausse course), pour vérifier le logo et les infos de la société. */
    fun exemple(ctx: Context, e: Entreprise, p: Profile): File {
        val t = System.currentTimeMillis()
        val r = Ride(t - 50 * 60000, t - 40 * 60000, t - 5 * 60000, 1.2, 18.4, 45.0,
            lieuPrise = "Gare Saint-Roch, Montpellier", lieuArrivee = "Aéroport Montpellier Méditerranée, Mauguio", type = "prive")
        val f = Facture("EXEMPLE", r.debut, t, Client("Marie Exemple", adresse = "1 place de la Comédie, 34000 Montpellier", email = "marie@exemple.fr"),
            "Carte bancaire", t - 24 * 3600_000L, "", 0L)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        dessiner(page.canvas, e, p, r, f, logo(ctx))
        doc.finishPage(page)
        val out = File(dossier(ctx), "Facture-EXEMPLE.pdf")
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
        return out
    }

    // ------------------------------------------------------------------ Envoi

    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, AUTORITE, f)

    fun outlookInstalle(ctx: Context) = try { ctx.packageManager.getPackageInfo(OUTLOOK, 0); true } catch (_: Exception) { false }

    /** Le message de sympathie, à partir du modèle de la société. */
    fun message(e: Entreprise, r: Ride, f: Facture): String = e.message
        .replace("{client}", f.client.appel.ifBlank { "Madame, Monsieur" })
        .replace("{numero}", f.numero)
        .replace("{date}", jour.format(Date(r.priseEnCharge)))
        .replace("{depart}", lieu(r.lieuPrise).substringAfterLast(", ").ifBlank { "départ" })
        .replace("{arrivee}", lieu(r.lieuArrivee).substringAfterLast(", ").ifBlank { "arrivée" })
        .replace("{chauffeur}", e.chauffeur)
        .replace("{societe}", e.raisonSociale)
        .replace("{telephone}", e.tel)
        .replace(Regex("\n{3,}"), "\n\n").trim()

    fun objet(r: Ride, f: Facture) = "Votre facture ${f.numero} · course du ${jour.format(Date(r.priseEnCharge))}"

    /** Ouvre Outlook avec le PDF déjà joint, l'adresse du client, l'objet et le message. Sinon, le choix de l'appli. */
    fun envoyer(a: Activity, pdf: File, e: Entreprise, r: Ride, f: Facture) {
        val u = uri(a, pdf)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, u)
            if (f.client.email.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(f.client.email.trim()))
            putExtra(Intent.EXTRA_SUBJECT, objet(r, f))
            putExtra(Intent.EXTRA_TEXT, message(e, r, f))
            clipData = ClipData.newRawUri("Facture", u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            a.startActivity(Intent(base).setPackage(OUTLOOK))
        } catch (_: ActivityNotFoundException) {
            a.startActivity(Intent.createChooser(base, "Envoyer la facture"))
        }
    }

    fun ouvrir(a: Activity, pdf: File) {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri(a, pdf), "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { a.startActivity(i) } catch (_: ActivityNotFoundException) {
            android.widget.Toast.makeText(a, "Aucune appli pour lire les PDF sur ce téléphone", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
