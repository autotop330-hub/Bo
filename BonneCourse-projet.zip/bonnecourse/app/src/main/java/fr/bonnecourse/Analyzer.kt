package fr.bonnecourse

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Réglages du véhicule et seuils du chauffeur. */
data class Profile(
    val energy: String = "electrique",   // essence, diesel, hybride, electrique
    val conso: Double = 16.0,            // L/100 km ou kWh/100 km
    val prixEnergie: Double = 0.25,      // €/L ou €/kWh
    val usure: Double = 0.06,            // entretien + pneus, €/km
    val commission: Double = 0.0,        // % à déduire du montant lu (0 pour Uber : montant déjà net)
    val fixesMois: Double = 900.0,       // LLD, assurance, etc.
    val kmMois: Double = 4000.0,
    val inclureFixes: Boolean = true,
    val objectifHeure: Double = 25.0,    // € net / heure
    val minimumKm: Double = 1.0,         // € brut / km roulé
    val devise: String = "€",
    val cv: Int = 7,                     // puissance fiscale (carte grise, case P.6) ; Model Y : 7 CV et plus
    // "location" : voiture louée à la SASU (loyer + frais payés par la SASU)
    // "ik"       : voiture au nom du chauffeur, la SASU lui verse des indemnités kilométriques
    // "micro"    : micro-entreprise
    val regime: String = "location",
    val tva: Boolean = true,             // société assujettie à la TVA (obligatoire au-delà de 37 500 € de CA)
    val commissionPlateforme: Double = 25.0, // part du prix client gardée par Uber/Bolt (pour la TVA sur le prix client)
    val autresFrais: Double = 150.0,     // frais fixes de la société par mois : comptable, banque, téléphone, RC pro…
    val tmi: Double = 11.0,              // tranche marginale d'impôt du chauffeur (pour comparer avec un salaire)
    val tauxMicro: Double = 21.2         // cotisations URSSAF micro-entreprise (prestations de services BIC)
) {
    val electrique get() = energy == "electrique"

    fun coutKm(): Double =
        conso / 100.0 * prixEnergie + usure + (if (inclureFixes && kmMois > 0) fixesMois / kmMois else 0.0)
}

/** Ce qui a été lu (ou saisi) sur l'offre. */
data class Offer(
    val prix: Double,
    val approcheKm: Double,
    val approcheMin: Double,
    val courseKm: Double,
    val courseMin: Double,
    val approcheLue: Boolean = true
)

enum class Verdict(val mot: String, val signe: String) {
    ACCEPTER("ACCEPTER", "✓"), A_VOIR("À VOIR", "~"), REFUSER("REFUSER", "✕")
}

data class Reason(val niveau: Verdict, val texte: String)

data class Result(
    val offer: Offer,
    val gain: Double,
    val kmTotal: Double,
    val minTotal: Double,
    val coutEnergie: Double,
    val coutUsure: Double,
    val coutFixes: Double,
    val net: Double,
    val parHeure: Double,
    val brutKm: Double,
    val score: Double,
    val verdict: Verdict,
    val raisons: List<Reason>
)

object Analyzer {

    /** Ratio par rapport à l'objectif → points. 0,5× = 0 ; 1× = 7 ; 1,5× et plus = 10. */
    private fun points(r: Double): Double = when {
        r <= 0.5 -> 0.0
        r <= 1.0 -> (r - 0.5) / 0.5 * 7.0
        else -> min(10.0, 7.0 + (r - 1.0) / 0.5 * 3.0)
    }

    fun analyse(o: Offer, p: Profile, retourAVide: Boolean = false): Result {
        val rKm = if (retourAVide) o.courseKm else 0.0
        val rMin = if (retourAVide) (o.courseMin * 0.8).roundToInt().toDouble() else 0.0
        val km = max(0.1, o.approcheKm + o.courseKm + rKm)
        val minutes = max(1.0, o.approcheMin + o.courseMin + rMin)
        val heures = minutes / 60.0

        val gain = o.prix * (1 - p.commission / 100.0)
        val cEn = km * p.conso / 100.0 * p.prixEnergie
        val cUs = km * p.usure
        val cFx = if (p.inclureFixes && p.kmMois > 0) km * p.fixesMois / p.kmMois else 0.0
        val net = gain - cEn - cUs - cFx
        val parH = net / heures
        val brutKm = gain / km

        var s = 0.6 * points(parH / p.objectifHeure) + 0.4 * points(brutKm / p.minimumKm)
        val partVide = (o.approcheKm + rKm) / km
        if (partVide > 0.4) s -= 1.0
        s = s.coerceIn(0.0, 10.0)

        var v = when {
            s >= 7 -> Verdict.ACCEPTER
            s >= 5 -> Verdict.A_VOIR
            else -> Verdict.REFUSER
        }
        if (net <= 0) v = Verdict.REFUSER

        val d = p.devise
        val r = mutableListOf<Reason>()
        if (net <= 0) r += Reason(Verdict.REFUSER, "Course à perte : les frais dépassent le gain.")
        r += if (parH >= p.objectifHeure)
            Reason(Verdict.ACCEPTER, "${parH.roundToInt()} $d/h net, au-dessus de ton objectif (${p.objectifHeure.roundToInt()} $d/h).")
        else
            Reason(Verdict.REFUSER, "${parH.roundToInt()} $d/h net, sous ton objectif (${p.objectifHeure.roundToInt()} $d/h).")
        r += if (brutKm >= p.minimumKm)
            Reason(Verdict.ACCEPTER, "${fmt2(brutKm)} $d par km roulé, au-dessus de ton minimum.")
        else
            Reason(Verdict.REFUSER, "${fmt2(brutKm)} $d par km roulé, sous ton minimum de ${fmt2(p.minimumKm)} $d.")
        if (!o.approcheLue)
            r += Reason(Verdict.A_VOIR, "Approche non lue sur l'écran : comptée à 0.")
        else if (partVide > 0.4)
            r += Reason(Verdict.A_VOIR, "${fmt1(o.approcheKm + rKm)} km sans client, ${(partVide * 100).roundToInt()} % du trajet.")
        if (retourAVide) r += Reason(Verdict.A_VOIR, "Retour à vide compté : +${fmt1(rKm)} km.")
        if (o.courseMin < 10) r += Reason(Verdict.A_VOIR, "Course très courte : l'attente de la suivante pèse lourd.")
        if (o.courseKm > 40) r += Reason(Verdict.A_VOIR, "Longue distance : pense aux courses à l'arrivée.")

        return Result(o, gain, km, minutes, cEn, cUs, cFx, net, parH, brutKm, s, v, r)
    }

    fun fmt1(x: Double) = String.format(java.util.Locale.FRANCE, "%.1f", x)
    fun fmt2(x: Double) = String.format(java.util.Locale.FRANCE, "%.2f", x)
}
