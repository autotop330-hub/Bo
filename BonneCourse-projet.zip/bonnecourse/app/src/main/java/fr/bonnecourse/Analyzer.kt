package fr.bonnecourse

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Réglages du véhicule et seuils du chauffeur.
 * Valeurs par défaut : Tesla Model Y Grande Autonomie Propulsion, au nom d'un proche et louée à la SASU du chauffeur.
 */
data class Profile(
    val energy: String = "electrique",   // essence, diesel, hybride, electrique
    val conso: Double = 16.0,            // kWh/100 km réels en ville (pertes de recharge comprises)
    val prixEnergie: Double = 0.30,      // €/kWh : mélange recharge à domicile et Superchargeurs
    val usure: Double = 0.05,            // pneus, entretien, €/km
    val commission: Double = 0.0,        // % à déduire du montant lu (0 pour Uber : montant déjà net)
    val fixesMois: Double = 900.0,       // loyer de la voiture versé au propriétaire + assurance VTC
    val kmMois: Double = 5000.0,
    val inclureFixes: Boolean = true,
    val objectifHeure: Double = 25.0,    // € net / heure
    val minimumKm: Double = 1.0,         // € brut / km roulé
    val devise: String = "€",
    val cv: Int = 7,                     // puissance fiscale (carte grise, case P.6) ; Model Y : 7 CV et plus
    // "location" : voiture louée à la SASU (loyer + frais payés par la SASU)
    // "ik"       : voiture au nom du chauffeur, la SASU lui verse des indemnités kilométriques
    // "micro"    : micro-entreprise
    val regime: String = "location",
    val tva: Boolean = true,             // société assujettie à la TVA (obligatoire au-delà de 37 500 € de CA)
    val commissionPlateforme: Double = 25.0, // part du prix client gardée par Uber/Bolt (pour la TVA sur le prix client)
    val autresFrais: Double = 150.0,     // frais fixes de la société par mois : comptable, banque, téléphone, RC pro…
    val tmi: Double = 11.0,              // tranche marginale d'impôt du chauffeur (pour comparer avec un salaire)
    val tauxMicro: Double = 21.2         // cotisations URSSAF micro-entreprise (prestations de services BIC)
) {
    val electrique get() = energy == "electrique"

    fun coutKm(): Double =
        conso / 100.0 * prixEnergie + usure + (if (inclureFixes && kmMois > 0) fixesMois / kmMois else 0.0)
}

/** Ce qui a été lu (ou saisi) sur l'offre. */
data class Offer(
    val prix: Double,
    val approcheKm: Double,
    val approcheMin: Double,
    val courseKm: Double,
    val courseMin: Double,
    val approcheLue: Boolean = true,
    val dureeEstimee: Boolean = false,  // durée non affichée par l'offre, estimée d'après les km
    val prise: String = "",             // adresse du client lue sur l'offre
    val depose: String = ""             // adresse de destination lue sur l'offre
)

enum class Verdict(val mot: String, val signe: String) {
    ACCEPTER("ACCEPTER", "✓"), A_VOIR("À VOIR", "~"), REFUSER("REFUSER", "✕")
}

data class Reason(val niveau: Verdict, val texte: String)

data class Result(
    val offer: Offer,
    val gain: Double,
    val kmTotal: Double,
    val minTotal: Double,
    val coutEnergie: Double,
    val coutUsure: Double,
    val coutFixes: Double,
    val coutTva: Double,
    val net: Double,
    val parHeure: Double,
    val brutKm: Double,
    val score: Double,
    val verdict: Verdict,
    val raisons: List<Reason>,
    val trafic: String = "",            // d'où viennent les durées (trafic réel, trafic habituel, plateforme)
    val lue: Offer? = null              // l'offre telle que lue, avant correction par le trafic
) {
    /** Taux de rentabilité : part du gain qui reste après tous les frais. */
    val marge get() = if (gain > 0) net / gain else 0.0
}

object Analyzer {

    /** Ratio par rapport à l'objectif → points. 0,5× = 0 ; 1× = 7 ; 1,5× et plus = 10. */
    private fun points(r: Double): Double = when {
        r <= 0.5 -> 0.0
        r <= 1.0 -> (r - 0.5) / 0.5 * 7.0
        else -> min(10.0, 7.0 + (r - 1.0) / 0.5 * 3.0)
    }

    /**
     * @param t trafic réel (TomTom) si disponible. Les minutes affichées par la plateforme sont gardées
     *          (elles tiennent déjà compte du trafic) ; celles qui manquent viennent du trafic réel,
     *          sinon du trafic habituel à cette heure.
     */
    fun analyse(o0: Offer, p: Profile, retourAVide: Boolean = false, t: Trafic.Estimation? = null,
                quand: java.util.Calendar = java.util.Calendar.getInstance()): Result {
        var o = o0
        var noteTrafic = ""
        if (t != null) {
            if (t.approche != null && (!o.approcheLue || o.approcheMin <= 0.0))
                o = o.copy(approcheMin = t.approche.min, approcheKm = if (o.approcheKm > 0) o.approcheKm else t.approche.km, approcheLue = true)
            if (t.course != null && (o.dureeEstimee || o.courseMin <= 0.0))
                o = o.copy(courseMin = maxOf(1.0, t.course.min.roundToInt().toDouble()), courseKm = if (o.courseKm > 0) o.courseKm else t.course.km, dureeEstimee = false)
            noteTrafic = t.note
        } else if (o.dureeEstimee) {
            val f = Trafic.facteurHoraire(quand)
            o = o.copy(courseMin = maxOf(3.0, (o.courseMin * f).roundToInt().toDouble()))
            noteTrafic = "Trafic habituel à cette heure : ${Trafic.libelleHoraire(f)}" + if (f != 1.0) " (durée ×${fmt2(f)})" else ""
        } else noteTrafic = "Durées affichées par la plateforme (trafic compris)"
        val rKm = if (retourAVide) o.courseKm else 0.0
        val rMin = if (retourAVide) (o.courseMin * 0.8).roundToInt().toDouble() else 0.0
        val km = max(0.1, o.approcheKm + o.courseKm + rKm)
        val minutes = max(1.0, o.approcheMin + o.courseMin + rMin)
        val heures = minutes / 60.0

        val gain = o.prix * (1 - p.commission / 100.0)
        val cEn = km * p.conso / 100.0 * p.prixEnergie
        val cUs = km * p.usure
        val cFx = if (p.inclureFixes && p.kmMois > 0) km * p.fixesMois / p.kmMois else 0.0
        // TVA 10 % due par la société sur le prix payé par le client (commission de la plateforme comprise)
        val cTva = if (p.tva && p.regime != "micro") {
            val c = (p.commissionPlateforme / 100).coerceIn(0.0, 0.9)
            gain / (1 - c) * 0.10 / 1.10
        } else 0.0
        val net = gain - cEn - cUs - cFx - cTva
        val parH = net / heures
        val brutKm = gain / km

        var s = 0.6 * points(parH / p.objectifHeure) + 0.4 * points(brutKm / p.minimumKm)
        val partVide = (o.approcheKm + rKm) / km
        if (partVide > 0.4) s -= 1.0
        s = s.coerceIn(0.0, 10.0)

        var v = when {
            s >= 7 -> Verdict.ACCEPTER
            s >= 5 -> Verdict.A_VOIR
            else -> Verdict.REFUSER
        }
        if (net <= 0) v = Verdict.REFUSER

        val d = p.devise
        val r = mutableListOf<Reason>()
        if (net <= 0) r += Reason(Verdict.REFUSER, "Course à perte : les frais dépassent le gain.")
        if (v == Verdict.A_VOIR) r += Reason(Verdict.A_VOIR, "Rentabilité moyenne : à prendre si rien de mieux ne tombe.")
        r += if (parH >= p.objectifHeure)
            Reason(Verdict.ACCEPTER, "${parH.roundToInt()} $d/h net, au-dessus de ton objectif (${p.objectifHeure.roundToInt()} $d/h).")
        else
            Reason(Verdict.REFUSER, "${parH.roundToInt()} $d/h net, sous ton objectif (${p.objectifHeure.roundToInt()} $d/h).")
        r += if (brutKm >= p.minimumKm)
            Reason(Verdict.ACCEPTER, "${fmt2(brutKm)} $d par km roulé, au-dessus de ton minimum.")
        else
            Reason(Verdict.REFUSER, "${fmt2(brutKm)} $d par km roulé, sous ton minimum de ${fmt2(p.minimumKm)} $d.")
        if (!o.approcheLue)
            r += Reason(Verdict.A_VOIR, "Approche non lue sur l'écran : comptée à 0.")
        else if (partVide > 0.4)
            r += Reason(Verdict.A_VOIR, "${fmt1(o.approcheKm + rKm)} km sans client, ${(partVide * 100).roundToInt()} % du trajet.")
        if (o.dureeEstimee) r += Reason(Verdict.A_VOIR, "Durée non affichée sur l'offre : ${o.courseMin.roundToInt()} min estimées pour ${fmt1(o.courseKm)} km.")
        if (t?.course != null && !o0.dureeEstimee && o0.courseMin > 0 && t.course.min > o0.courseMin * 1.25)
            r += Reason(Verdict.A_VOIR, "Bouchons : ${t.course.min.roundToInt()} min selon le trafic réel, ${o0.courseMin.roundToInt()} min annoncées.")
        if (retourAVide) r += Reason(Verdict.A_VOIR, "Retour à vide compté : +${fmt1(rKm)} km.")
        if (o.courseMin < 10) r += Reason(Verdict.A_VOIR, "Course très courte : l'attente de la suivante pèse lourd.")
        if (o.courseKm > 40) r += Reason(Verdict.A_VOIR, "Longue distance : pense aux courses à l'arrivée.")

        return Result(o, gain, km, minutes, cEn, cUs, cFx, cTva, net, parH, brutKm, s, v, r, noteTrafic, o0)
    }

    fun fmt1(x: Double) = String.format(java.util.Locale.FRANCE, "%.1f", x)
    fun fmt2(x: Double) = String.format(java.util.Locale.FRANCE, "%.2f", x)
}
