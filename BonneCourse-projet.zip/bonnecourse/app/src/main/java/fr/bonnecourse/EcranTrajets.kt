package fr.bonnecourse

import android.annotation.SuppressLint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Onglet « Journal » : Courses (boîte noire) · Trajets (façon Driversnote) · Compteur. */
class EcranJournal(private val a: MainActivity) {
    fun remplir(col: LinearLayout) {
        col.addView(W.titreEcran(a, "Journal"))
        col.addView(W.segments(a, listOf("Courses", "Trajets", "Compteur"), a.vueJournal) { a.vueJournal = it; a.selection = null; a.afficher() })
        col.addView(a.navMois())
        when (a.vueJournal) {
            1 -> EcranTrajets(a).remplir(col)
            2 -> EcranCompteur(a).remplir(col)
            else -> EcranCourses(a).remplir(col)
        }
    }
}

/**
 * Journal › Trajets : tous les trajets hors bulle du mois, détectés tout seuls.
 * Boîte « à classer » : glisser à droite = pro, à gauche = perso (ou les boutons).
 * Les trajets déjà classés automatiquement affichent la raison (heures de travail, lieu favori, habitude) et se corrigent d'un toucher.
 */
class EcranTrajets(private val a: MainActivity) {
    private val store = a.store
    private val heure = SimpleDateFormat("HH:mm", Locale.FRANCE)

    fun remplir(col: LinearLayout) {
        val tous = store.trajets().filter { a.duMois(it.debut) }
        val pre = String.format("%04d-%02d", a.vueAnnee, a.vueMois)
        val kmPro = maxOf(store.service().filterKeys { it.startsWith(pre) }.values.sum(),
            store.rides().filter { a.duMois(it.debut) }.sumOf { it.kmTotal })
        val kmPerso = store.perso().filterKeys { it.startsWith(pre) }.values.sum()
        val aClasser = tous.filter { it.statut == Trajet.A_CLASSER }.sortedByDescending { it.debut }

        // Bilan du mois façon Driversnote
        val c = W.carteVedette(a, "Kilomètres du mois")
        val part = if (kmPro + kmPerso > 0) kmPro / (kmPro + kmPerso) else 0.0
        c.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(W.hero(a, Analyzer.fmt1(kmPro), "km professionnels", Ui.ACCENT), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(W.hero(a, Analyzer.fmt1(kmPerso), "km personnels", Ui.FG), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        })
        c.addView(W.progression(a, part))
        c.addView(W.ligne(a, "Part professionnelle", if (kmPro + kmPerso > 0) "${(part * 100).roundToInt()} %" else "—", true, Ui.ACCENT))
        c.addView(W.aide(a, "Km pro = bulle lancée (courses, approches, domicile ↔ service) + trajets classés pro. " +
            "${tous.size} trajet${if (tous.size > 1) "s" else ""} hors bulle ce mois" + if (aClasser.isNotEmpty()) ", dont ${aClasser.size} à classer." else "."))
        col.addView(c)

        if (!store.autoTrajets) col.addView(W.carte(a, "Détection automatique").apply {
            addView(Ui.text(a, "Désactivée : les trajets hors bulle ne sont pas enregistrés.", 15f, Ui.WARN, true))
            addView(W.bouton(a, "Activer la détection automatique", true) { a.basculerAuto(true) })
        })

        if (aClasser.isNotEmpty()) col.addView(boite(aClasser, 20))

        // Tous les trajets du mois, jour par jour
        if (tous.isEmpty()) col.addView(W.aide(a, "Aucun trajet hors bulle ce mois. Avec la détection automatique, chaque trajet en voiture " +
            "s'enregistre tout seul et se classe pro ou perso."))
        val jourF = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)
        tous.groupBy { SimpleDateFormat("yyyyMMdd", Locale.FRANCE).format(Date(it.debut)) }.toSortedMap(compareByDescending { it }).forEach { (_, l) ->
            val g = Ui.vertical(a, 8)
            val pro = l.filter { it.statut == Trajet.PRO }.sumOf { it.km }
            g.addView(W.ligne(a, jourF.format(Date(l.first().debut)).replaceFirstChar { it.uppercase() },
                "${Analyzer.fmt1(l.sumOf { it.km })} km" + if (pro > 0) " · ${Analyzer.fmt1(pro)} pro" else "", true, Ui.ACCENT).apply {
                setPadding(Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4), 0)
            })
            l.sortedBy { it.debut }.forEach { g.addView(ligne(it)) }
            col.addView(g)
        }
        col.addView(W.bouton(a, "Ajouter un trajet à la main") { ajouter() })
        col.addView(W.aide(a, "Toucher un trajet : changer pro / perso, nommer le lieu, supprimer. " +
            "Les lieux favoris et les heures de travail se règlent dans Réglages › Classement des trajets."))
    }

    /** Boîte « à classer » avec cartes à glisser (réutilisée sur l'accueil). */
    fun boite(l: List<Trajet>, max: Int): View {
        val c = W.carte(a, "À classer (${l.size})")
        c.addView(W.aide(a, "Glisse vers la droite : pro  ·  vers la gauche : perso"))
        l.take(max).forEach { t -> c.addView(carteGlissante(t)) }
        if (l.size > max) c.addView(W.aide(a, "… et ${l.size - max} autres dans Journal › Trajets"))
        if (l.size > 1) c.addView(Ui.buttonRow(a,
            W.bouton(a, "Tout en pro") { W.confirmer(a, "Classer ${l.size} trajets en pro ?", null, "Tout en pro") { l.forEach { store.classer(it.debut, Trajet.PRO) }; a.afficher() } },
            W.bouton(a, "Tout en perso") { W.confirmer(a, "Classer ${l.size} trajets en perso ?", null, "Tout en perso") { l.forEach { store.classer(it.debut, Trajet.PERSO) }; a.afficher() } }))
        return c
    }

    private fun ville(x: String) = x.substringBefore(" (").let { if (Classement.coord(it) != null) "" else it }
        .let { s -> if (store.favorisEtDomicile().any { it.nom == s }) s else s.substringAfterLast(", ", s) }

    private fun lieux(t: Trajet) = listOf(ville(t.depart), ville(t.arrivee)).filter { it.isNotBlank() }.joinToString("  →  ")

    /** Carte qui suit le doigt ; lâchée au-delà d'un tiers de largeur, elle classe le trajet. */
    @SuppressLint("ClickableViewAccessibility")
    private fun carteGlissante(t: Trajet): View {
        val cadre = FrameLayout(a).apply { setPadding(0, Ui.dp(a, 2), 0, Ui.dp(a, 2)) }
        val fond = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.box(a, Ui.OR_SOMBRE, Ui.OR_SOMBRE, 0, 18)
            val p = Ui.dp(a, 18); setPadding(p, 0, p, 0)
            addView(Ui.text(a, "PRO", 14f, Ui.ACCENT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Ui.text(a, "PERSO", 14f, Ui.FG, true))
        }
        cadre.addView(fond, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val carte = Ui.vertical(a, 6).apply {
            background = Ui.box(a, Ui.RAISE, Ui.LINE, 1, 18)
            val p = Ui.dp(a, 14); setPadding(p, p, p, p)
            addView(W.ligne(a, "${SimpleDateFormat("EEE d · HH:mm", Locale.FRANCE).format(Date(t.debut))} → ${heure.format(Date(t.fin))}",
                "${Analyzer.fmt1(t.km)} km", true))
            lieux(t).takeIf { it.isNotBlank() }?.let { addView(Ui.text(a, it, 14f, Ui.FG).apply { maxLines = 2 }) }
            addView(Ui.buttonRow(a,
                Ui.button(a, "Pro", Ui.OR_SOMBRE, Ui.ACCENT, Ui.ACCENT) { classer(t, Trajet.PRO) },
                Ui.button(a, "Perso", Ui.SURFACE, Ui.FG, Ui.LINE) { classer(t, Trajet.PERSO) }))
        }
        cadre.addView(carte, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val slop = ViewConfiguration.get(a).scaledTouchSlop
        var x0 = 0f; var y0 = 0f; var glisse = false
        carte.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; glisse = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - x0
                    if (!glisse && abs(dx) > slop && abs(dx) > abs(e.rawY - y0)) { glisse = true; v.parent?.requestDisallowInterceptTouchEvent(true) }
                    if (glisse) {
                        v.translationX = dx
                        val droite = dx > 0
                        fond.background = Ui.box(a, if (droite) Ui.OR_SOMBRE else Ui.SURFACE, if (droite) Ui.ACCENT else Ui.LINE, 1, 18)
                        fond.getChildAt(0).alpha = if (droite) 1f else 0f
                        fond.getChildAt(1).alpha = if (droite) 0f else 1f
                    }
                    glisse
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!glisse) return@setOnTouchListener false
                    v.parent?.requestDisallowInterceptTouchEvent(false)
                    val dx = v.translationX
                    if (e.actionMasked == MotionEvent.ACTION_UP && abs(dx) > v.width / 3f) {
                        val statut = if (dx > 0) Trajet.PRO else Trajet.PERSO
                        v.animate().translationX(if (dx > 0) v.width.toFloat() else -v.width.toFloat()).setDuration(160)
                            .withEndAction { classer(t, statut) }.start()
                    } else v.animate().translationX(0f).setDuration(160).start()
                    glisse = false
                    true
                }
                else -> false
            }
        }
        return cadre
    }

    private fun classer(t: Trajet, statut: String) {
        store.classer(t.debut, statut)
        a.toast("${Analyzer.fmt1(t.km)} km en ${if (statut == Trajet.PRO) "pro" else "perso"}")
        a.afficher()
    }

    /** Ligne du journal : heure, lieux, km, statut (et la raison s'il a été classé tout seul). */
    private fun ligne(t: Trajet): View {
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.box(a, Ui.RAISE, Ui.RAISE, 1, 18)
            val p = Ui.dp(a, 14); setPadding(p, Ui.dp(a, 12), p, Ui.dp(a, 12))
        }
        val (txt, coul) = when (t.statut) {
            Trajet.PRO -> "Pro" to Ui.ACCENT; Trajet.PERSO -> "Perso" to Ui.MUTED; else -> "À classer" to Ui.WARN
        }
        val g = Ui.vertical(a, 4)
        g.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(Ui.text(a, "${heure.format(Date(t.debut))} → ${heure.format(Date(t.fin))}", 15f, Ui.FG, true))
            addView(W.puce(a, txt, coul), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = Ui.dp(a, 10) })
        })
        lieux(t).takeIf { it.isNotBlank() }?.let { g.addView(Ui.text(a, it, 14f).apply { maxLines = 2 }) }
        val info = listOfNotNull(
            if (t.raison.isNotBlank()) "auto · ${t.raison}" else null,
            if (t.manuel) "ajouté à la main" else null,
            if (t.vehicule != store.vehiculeActif.id) store.vehicule(t.vehicule)?.court else null)
        if (info.isNotEmpty()) g.addView(Ui.text(a, info.joinToString(" · "), 12f, Ui.MUTED))
        l.addView(g, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, "${Analyzer.fmt1(t.km)} km", 16f, coul, true))
        l.setOnClickListener { actions(t) }
        return l
    }

    private fun actions(t: Trajet) {
        val opts = mutableListOf<Pair<String, () -> Unit>>()
        if (t.statut != Trajet.PRO) opts += "Classer en pro" to { classer(t, Trajet.PRO) }
        if (t.statut != Trajet.PERSO) opts += "Classer en perso" to { classer(t, Trajet.PERSO) }
        Classement.coord(t.arrivee)?.let { c -> opts += "Enregistrer l'arrivée comme lieu favori" to { EcranLieux.nouveau(a, c, ville(t.arrivee)) } }
        Classement.coord(t.depart)?.let { c -> opts += "Enregistrer le départ comme lieu favori" to { EcranLieux.nouveau(a, c, ville(t.depart)) } }
        opts += "Supprimer ce trajet" to {
            W.confirmer(a, "Supprimer ce trajet ?", "${Analyzer.fmt1(t.km)} km. Ses km sont retirés du mois.", "Supprimer") {
                store.supprimerTrajet(t.debut); a.afficher()
            }
        }
        AlertDialog.Builder(a).setTitle("${heure.format(Date(t.debut))} · ${Analyzer.fmt1(t.km)} km")
            .setItems(opts.map { it.first as CharSequence }.toTypedArray()) { _, i -> opts[i].second() }
            .setNegativeButton("Fermer", null).show()
    }

    /** Trajet oublié (téléphone éteint, détection coupée) : saisi à la main, comme dans Driversnote. */
    private fun ajouter() {
        val col = Ui.vertical(a, 8).apply { val p = Ui.dp(a, 20); setPadding(p, p, p, p); setBackgroundColor(Ui.BG) }
        col.addView(Ui.text(a, "Trajet à la main", 20f, Ui.FG, true))
        val maint = Calendar.getInstance()
        val eJour = W.champ(a, col, "Date (jj/mm/aaaa)", SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(maint.time), android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_DATE)
        val eH = W.champ(a, col, "Heure de départ (hh:mm)", heure.format(maint.time), android.text.InputType.TYPE_CLASS_DATETIME)
        val eMin = W.champ(a, col, "Durée (minutes)", "", W.NOMBRE, "ex. 25")
        val eDe = W.champ(a, col, "Départ", "", indice = "ex. Domicile, Balaruc-les-Bains")
        val eA = W.champ(a, col, "Arrivée", "", indice = "ex. Gare Saint-Roch, Montpellier")
        val eKm = W.champ(a, col, "Distance (km)", "", W.NOMBRE, "ex. 28,4")
        val pro = SwitchCompat(a).apply { text = "Trajet professionnel"; setTextColor(Ui.FG); isChecked = true }
        col.addView(pro)
        AlertDialog.Builder(a).setView(ScrollView(a).apply { addView(col) })
            .setPositiveButton("Ajouter") { _, _ ->
                val debut = try { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).apply { isLenient = false }.parse("${W.txt(eJour)} ${W.txt(eH)}")?.time } catch (_: Exception) { null }
                val km = W.nombre(eKm)
                if (debut == null || km == null || km <= 0) { a.toast("Date, heure ou distance invalide"); return@setPositiveButton }
                val min = W.nombre(eMin)?.takeIf { it > 0 } ?: (km / 40.0 * 60)          // à défaut : 40 km/h de moyenne
                store.addTrajet(Trajet(debut, debut + (min * 60_000).toLong(), km, W.txt(eDe), W.txt(eA),
                    if (pro.isChecked) Trajet.PRO else Trajet.PERSO, manuel = true))
                a.toast("Trajet ajouté"); a.afficher()
            }.setNegativeButton("Annuler", null).show()
    }
}

/** Réglages › Classement des trajets : lieux favoris, heures de travail, classement automatique. */
object EcranLieux {
    fun reglages(a: MainActivity): LinearLayout {
        val store = a.store
        val c = W.carte(a, "Classement des trajets")
        val auto = SwitchCompat(a).apply { text = "Classer mes trajets tout seul"; setTextColor(Ui.FG); isChecked = store.classementAuto }
        auto.setOnCheckedChangeListener { _, on -> store.classementAuto = on }
        c.addView(auto)
        c.addView(W.aide(a, "Comme Driversnote : un trajet vers un lieu favori pro, un trajet déjà classé 2 fois de la même façon, " +
            "ou un trajet dans tes heures de travail est classé tout seul. Tu peux toujours corriger d'un toucher."))
        val h = store.heuresTravail
        c.addView(W.ligne(a, "Heures de travail", if (h.actif) h.texte() else "non réglées"))
        c.addView(Ui.details(a, "Régler les heures de travail", heures(a)))
        val f = store.favoris()
        c.addView(Ui.text(a, "Lieux favoris (${f.size})", 15f, Ui.ACCENT, true).apply { setPadding(0, Ui.dp(a, 8), 0, 0) })
        if (f.isEmpty()) c.addView(W.aide(a, "Ajoute les lieux où tu vas souvent : gare, aéroport, Superchargeur, base… " +
            "Ils nomment tes trajets et les classent pro (ou perso)."))
        f.forEach { fav ->
            c.addView(W.ligne(a, fav.nom, if (fav.type == Favori.PRO) "pro" else "perso", couleur = if (fav.type == Favori.PRO) Ui.ACCENT else Ui.MUTED).apply {
                setOnClickListener {
                    W.confirmer(a, "Supprimer « ${fav.nom} » ?", "Les trajets déjà enregistrés gardent leur nom.", "Supprimer") { store.supprimerFavori(fav.id); a.afficher() }
                }
            })
        }
        c.addView(W.bouton(a, "Je suis sur place : ajouter ce lieu") { a.positionActuelle { p -> if (p != null) nouveau(a, p, "") } })
        val form = Ui.vertical(a, 6)
        val adr = W.champ(a, form, "Adresse", "", indice = "ex. Gare Saint-Roch, Montpellier")
        form.addView(W.bouton(a, "Chercher et ajouter") { a.chercherAdresse(W.txt(adr)) { p -> if (p != null) nouveau(a, p, W.txt(adr).substringBefore(",")) } })
        c.addView(Ui.details(a, "Ajouter par l'adresse", form))
        if (f.isNotEmpty()) c.addView(W.aide(a, "Toucher un lieu pour le supprimer."))
        return c
    }

    private fun heures(a: MainActivity): LinearLayout {
        val store = a.store
        val h = store.heuresTravail
        val form = Ui.vertical(a, 6)
        val actif = SwitchCompat(a).apply { text = "Utiliser mes heures de travail"; setTextColor(Ui.FG); isChecked = h.actif }
        form.addView(actif)
        val noms = listOf("Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
        val choisis = h.jours.toMutableSet()
        val rang = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        noms.forEachIndexed { i, n ->
            val j = i + 1
            rang.addView(Ui.text(a, n, 13f, if (j in choisis) Ui.BG else Ui.FG, true).apply {
                gravity = Gravity.CENTER; val p = Ui.dp(a, 8); setPadding(0, p, 0, p)
                fun peindre() { setTextColor(if (j in choisis) Ui.BG else Ui.FG); background = Ui.box(a, if (j in choisis) Ui.ACCENT else Ui.RAISE, Ui.LINE, 1, 18) }
                peindre()
                setOnClickListener { if (!choisis.remove(j)) choisis += j; peindre() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = Ui.dp(a, 4) })
        }
        form.addView(rang)
        fun hm(x: Int) = String.format("%02d:%02d", x / 60, x % 60)
        fun lire(s: String): Int? = Regex("^(\\d{1,2})[:h.]?(\\d{2})?$").find(s.trim())?.let {
            val hh = it.groupValues[1].toInt(); val mm = it.groupValues[2].ifBlank { "0" }.toInt()
            if (hh in 0..24 && mm in 0..59) (hh * 60 + mm).coerceAtMost(24 * 60) else null }
        val eD = W.champ(a, form, "Début (hh:mm)", hm(h.debut), android.text.InputType.TYPE_CLASS_DATETIME)
        val eF = W.champ(a, form, "Fin (hh:mm) · avant le début = jusqu'au lendemain", hm(h.fin), android.text.InputType.TYPE_CLASS_DATETIME)
        form.addView(W.bouton(a, "Enregistrer", true) {
            val d = lire(W.txt(eD)); val f = lire(W.txt(eF))
            if (d == null || f == null || choisis.isEmpty()) { a.toast("Heures ou jours invalides"); return@bouton }
            store.heuresTravail = HeuresTravail(actif.isChecked, choisis.toSet(), d, f)
            a.toast("Heures de travail enregistrées"); a.afficher()
        })
        return form
    }

    /** Fenêtre « Nommer ce lieu » (pro ou perso). */
    fun nouveau(a: MainActivity, c: Pair<Double, Double>, nomPropose: String) {
        val col = Ui.vertical(a, 8).apply { val p = Ui.dp(a, 20); setPadding(p, p, p, p); setBackgroundColor(Ui.BG) }
        col.addView(Ui.text(a, "Nouveau lieu favori", 20f, Ui.FG, true))
        val eNom = W.champ(a, col, "Nom", nomPropose, W.NOM, "ex. Gare Saint-Roch")
        col.addView(Ui.text(a, "Un trajet vers ou depuis ce lieu est…", 13f, Ui.MUTED))
        val sp = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, listOf("professionnel", "personnel")) }
        col.addView(sp)
        AlertDialog.Builder(a).setView(col)
            .setPositiveButton("Enregistrer") { _, _ ->
                val nom = W.txt(eNom)
                if (nom.isBlank()) { a.toast("Donne un nom au lieu"); return@setPositiveButton }
                a.store.saveFavori(Favori("f${System.currentTimeMillis()}", nom, c.first, c.second,
                    if (sp.selectedItemPosition == 0) Favori.PRO else Favori.PERSO))
                a.toast("« $nom » enregistré"); a.afficher()
            }.setNegativeButton("Annuler", null).show()
    }
}
