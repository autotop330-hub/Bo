package fr.bonnecourse

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.graphics.Typeface
import android.widget.TextView
import android.widget.ImageView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Briques d'écran communes (cartes, champs, lignes, boutons), style noir et or, pour des écrans courts et homogènes. */
object W {
    fun carte(ctx: Context, titre: String? = null) = Ui.vertical(ctx, 14).apply {
        background = Ui.box(ctx, Ui.SURFACE, Ui.LINE, 1, 24)
        val p = Ui.dp(ctx, 19); setPadding(p, p, p, p)
        if (titre != null) addView(Ui.text(ctx, titre.uppercase(Locale.FRANCE), 11f, Ui.ACCENT, true).apply { letterSpacing = 0.15f })
    }

    /** Carte vedette : dégradé or → graphite, pour le chiffre clé de l'écran. */
    fun carteVedette(ctx: Context, titre: String? = null) = Ui.vertical(ctx, 12).apply {
        background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#313A48"), Color.parseColor("#1B2530"), Color.parseColor("#141B25"))).apply {
            cornerRadius = Ui.dp(ctx, 28).toFloat(); setStroke(Ui.dp(ctx, 1), Color.parseColor("#555041"))
        }
        val p = Ui.dp(ctx, 22); setPadding(p, p, p, p)
        if (titre != null) addView(Ui.text(ctx, titre.uppercase(), 12f, Ui.ACCENT, true).apply { letterSpacing = 0.14f })
    }

    /** Barre de progression arrondie (objectif du jour…). */
    fun progression(ctx: Context, part: Double, couleur: Int = Ui.ACCENT) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        background = Ui.box(ctx, Color.parseColor("#45505C"), Color.TRANSPARENT, 0, 6)
        val f = part.coerceIn(0.0, 1.0).toFloat()
        if (f > 0f) addView(View(ctx).apply { background = Ui.box(ctx, couleur, couleur, 0, 6) }, LinearLayout.LayoutParams(0, Ui.dp(ctx, 7), f))
        if (f < 1f) addView(View(ctx), LinearLayout.LayoutParams(0, Ui.dp(ctx, 7), 1f - f))
    }

    /** Bonjour / Bonsoir + prénom. */
    fun salutation(ctx: Context, prenom: String) = Ui.vertical(ctx, 2).apply {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        addView(Ui.text(ctx, (if (h in 5..17) "Bonjour" else "Bonsoir") + if (prenom.isNotBlank()) ", $prenom" else "", 26f, Ui.FG).apply { typeface = Ui.MEDIUM })
        addView(Ui.text(ctx, java.text.SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(java.util.Date()).replaceFirstChar { it.uppercase() }, 14f, Ui.MUTED))
    }

    /** Commande tactile premium : hiérarchie claire + effet d'appui + accessibilité. */
    fun bouton(ctx: Context, s: String, principal: Boolean = false, couleur: Int = Ui.ACCENT, onClick: () -> Unit) = TextView(ctx).apply {
        text = s; textSize = 14.5f; typeface = Ui.MEDIUM; gravity = Gravity.CENTER
        letterSpacing = 0.02f; includeFontPadding = true
        setTextColor(if (principal) Ui.BG else Ui.FG)
        minHeight = Ui.dp(ctx, 54)
        setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 12), Ui.dp(ctx, 14), Ui.dp(ctx, 12))
        background = Ui.touch(ctx, if (principal) couleur else Ui.RAISE, if (principal) couleur else Ui.LINE, 17)
        isClickable = true; isFocusable = true
        contentDescription = s
        setOnClickListener { onClick() }
    }

    /** Bouton rouge discret pour les suppressions. */
    fun boutonDanger(ctx: Context, s: String, onClick: () -> Unit) = bouton(ctx, s) { onClick() }.apply {
        setTextColor(Ui.STOP)
        background = Ui.touch(ctx, Ui.SURFACE, Color.parseColor("#704047"), 16)
    }

    /** Champ de saisie avec son intitulé au-dessus. */
    fun champ(ctx: Context, parent: LinearLayout, label: String, valeur: String = "", type: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES,
              indice: String = "", lignes: Int = 1): EditText {
        parent.addView(Ui.text(ctx, label, 13f, Ui.MUTED))
        val e = EditText(ctx).apply {
            inputType = type; setText(valeur); hint = indice
            setTextColor(Ui.FG); setHintTextColor(Color.parseColor("#4A4F58")); textSize = 17f
            background = Ui.box(ctx, Ui.RAISE, Ui.LINE, 1, 16)
            val ph = Ui.dp(ctx, 14); val pv = Ui.dp(ctx, 12); setPadding(ph, pv, ph, pv)
            if (lignes > 1) { minLines = lignes; inputType = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE; gravity = Gravity.TOP }
        }
        parent.addView(e)
        return e
    }

    const val NOMBRE = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    const val EMAIL = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    const val TEL = InputType.TYPE_CLASS_PHONE
    const val NOM = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS

    fun nombre(e: EditText) = e.text.toString().replace(',', '.').replace(" ", "").replace("€", "").toDoubleOrNull()
    fun txt(e: EditText) = e.text.toString().trim()

    fun n(v: Double) = if (v % 1.0 == 0.0) v.toLong().toString() else String.format(Locale.FRANCE, "%.2f", v).trimEnd('0').trimEnd(',')

    /** Ligne « libellé ............ valeur ». */
    fun ligne(ctx: Context, a: String, b: String, fort: Boolean = false, couleur: Int = Ui.FG) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(Ui.text(ctx, a, 15f, if (fort) Ui.FG else Ui.MUTED, fort), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(Ui.text(ctx, b, 15f, couleur, true))
    }

    /** Gros chiffre élégant avec sa légende. */
    fun hero(ctx: Context, valeur: String, legende: String, couleur: Int = Ui.FG) = Ui.vertical(ctx, 2).apply {
        addView(Ui.text(ctx, valeur, 40f, couleur).apply { typeface = Ui.LEGER; letterSpacing = -0.025f })
        addView(Ui.text(ctx, legende, 13f, Ui.MUTED))
    }

    /** Pastille de couleur + texte (légende ou plateforme). */
    fun pastille(ctx: Context, couleur: Int, s: String, sp: Float = 13f) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(View(ctx).apply { background = Ui.box(ctx, couleur, couleur, 0, 5) },
            LinearLayout.LayoutParams(Ui.dp(ctx, 10), Ui.dp(ctx, 10)).apply { marginEnd = Ui.dp(ctx, 8) })
        addView(Ui.text(ctx, s, sp, Ui.FG))
    }

    /** Étiquette arrondie (plateforme, statut). */
    fun puce(ctx: Context, s: String, couleur: Int) = Ui.text(ctx, s, 12f, couleur, true).apply {
        val ph = Ui.dp(ctx, 10); val pv = Ui.dp(ctx, 4); setPadding(ph, pv, ph, pv)
        background = Ui.box(ctx, Color.argb(38, Color.red(couleur), Color.green(couleur), Color.blue(couleur)), Color.TRANSPARENT, 0, 20)
    }

    /** Icône vectorielle teintée. */
    fun icone(ctx: Context, res: Int, couleur: Int, tailleDp: Int = 24) = ImageView(ctx).apply {
        setImageResource(res); setColorFilter(couleur)
        layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, tailleDp), Ui.dp(ctx, tailleDp))
    }

    /** Couleur de chaque source de revenu (palette vérifiée pour le daltonisme sur fond sombre). */
    fun couleurSource(s: String): Int = when (s) {
        "Uber" -> Color.parseColor("#3987E5")
        "Bolt" -> Color.parseColor("#199E70")
        "Privé" -> Color.parseColor("#D95926")
        "Heetch" -> Color.parseColor("#D55181")
        "FreeNow" -> Color.parseColor("#9085E9")
        else -> Color.parseColor("#8A96A1")
    }

    /** Navigation de mois « ‹  Novembre 2026  › ». */
    fun navMois(ctx: Context, titre: String, onPrev: () -> Unit, onNext: () -> Unit, onSelect: () -> Unit) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        background = Ui.box(ctx, Ui.SURFACE, Ui.LINE, 1, 20)
        val p = Ui.dp(ctx, 4); setPadding(p, p, p, p)
        fun fleche(s: String, f: () -> Unit) = Ui.text(ctx, s, 22f, Ui.ACCENT).apply {
            gravity = Gravity.CENTER
            background = Ui.touch(ctx, Ui.RAISE, Ui.LINE, 16)
            isClickable = true; isFocusable = true
            contentDescription = if (s == "‹") "Mois précédent" else "Mois suivant"
            setOnClickListener { f() }
        }
        val d = Ui.dp(ctx, 44)
        addView(fleche("‹", onPrev), LinearLayout.LayoutParams(d, d))
        addView(Ui.text(ctx, "$titre  ⌄", 15f, Ui.FG, true).apply {
            gravity = Gravity.CENTER
            isClickable = true; isFocusable = true
            contentDescription = "Choisir un mois, actuellement $titre"
            setOnClickListener { onSelect() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(fleche("›", onNext), LinearLayout.LayoutParams(d, d))
    }

    val MOIS = listOf("janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre")

    fun nomMois(annee: Int, mois: Int) = "${MOIS[mois - 1].replaceFirstChar { it.uppercase() }} $annee"

    fun eur(x: Double) = String.format(Locale.FRANCE, "%,.0f €", x)
    fun eur2(x: Double) = String.format(Locale.FRANCE, "%,.2f €", x)

    /** Texte d'aide discret. */
    fun aide(ctx: Context, s: String) = Ui.text(ctx, s, 13f, Ui.MUTED).apply { setLineSpacing(0f, 1.15f) }

    /** État vide lisible, avec une seule indication actionnable. */
    fun etatVide(ctx: Context, titre: String, explication: String) = carte(ctx).apply {
        addView(puce(ctx, "POUR COMMENCER", Ui.ACCENT))
        addView(Ui.text(ctx, titre, 20f, Ui.FG, true))
        addView(aide(ctx, explication))
    }

    /** En-tête éditorial commun : remplace les gros titres isolés. */
    fun entete(ctx: Context, titre: String, legende: String) = Ui.vertical(ctx, 6).apply {
        addView(Ui.text(ctx, "LA BONNE COURSE  /  ESPACE CHAUFFEUR", 10f, Ui.ACCENT, true).apply { letterSpacing = 0.13f })
        addView(Ui.text(ctx, titre, 31f, Ui.FG, true).apply { letterSpacing = -0.025f })
        addView(Ui.text(ctx, legende, 13f, Ui.MUTED))
    }

    fun titreEcran(ctx: Context, s: String) = Ui.text(ctx, s, 30f).apply {
        typeface = Ui.MEDIUM; letterSpacing = -0.02f
    }

    /** Signature compacte, à la place d'un logo pleine largeur occupant l'écran. */
    fun cockpit(ctx: Context, prenom: String, actif: Boolean) = Ui.vertical(ctx, 13).apply {
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val monogramme = Ui.text(ctx, "BC", 19f, Ui.ACCENT, true).apply {
            gravity = Gravity.CENTER; typeface = Typeface.create("serif", Typeface.BOLD)
            background = Ui.box(ctx, Ui.OR_SOMBRE, Color.parseColor("#85704A"), 1, 18)
            contentDescription = "La Bonne Course"
        }
        bar.addView(monogramme, LinearLayout.LayoutParams(Ui.dp(ctx, 49), Ui.dp(ctx, 49)).apply { marginEnd = Ui.dp(ctx, 12) })
        val marque = Ui.vertical(ctx, 3).apply {
            addView(Ui.text(ctx, "LA BONNE COURSE", 15f, Ui.FG, true).apply { letterSpacing = 0.10f })
            addView(Ui.text(ctx, "COCKPIT  /  VTC", 10f, Ui.ACCENT, true).apply { letterSpacing = 0.16f })
        }
        bar.addView(marque, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(puce(ctx, if (actif) "EN LIGNE" else "HORS LIGNE", if (actif) Ui.GO else Ui.MUTED))
        addView(bar)
        val heure = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val bonjour = if (heure in 5..17) "Bonjour" else "Bonsoir"
        addView(Ui.text(ctx, bonjour + if (prenom.isNotBlank()) ", $prenom" else "", 29f, Ui.FG, true).apply { letterSpacing = -0.02f })
        addView(Ui.text(ctx, java.text.SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(java.util.Date()).replaceFirstChar { it.uppercase() }, 13f, Ui.MUTED))
    }

    /** En-tête de marque : « La Bonne Course » en or, filet doré, « VTC · CHAUFFEUR PRIVÉ ». */
    fun marque(ctx: Context) = Ui.vertical(ctx, 6).apply {
        setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 4))
        addView(Ui.text(ctx, "La Bonne Course", 30f, Ui.ACCENT).apply { typeface = Typeface.create("serif", Typeface.ITALIC); letterSpacing = -0.01f })
        addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(View(ctx).apply { setBackgroundColor(Ui.ACCENT) }, LinearLayout.LayoutParams(Ui.dp(ctx, 28), Ui.dp(ctx, 1)).apply { marginEnd = Ui.dp(ctx, 10) })
            addView(Ui.text(ctx, "VTC · CHAUFFEUR PRIVÉ", 11f, Ui.MUTED, true).apply { letterSpacing = 0.22f })
        })
    }

    /** Petit bloc chiffré « ● Approche / 12,4 / km ». */
    fun chiffreKm(ctx: Context, lab: String, km: Double, couleur: Int) = Ui.vertical(ctx, 2).apply {
        background = Ui.box(ctx, Ui.RAISE, Ui.RAISE, 0, 16)
        val p = Ui.dp(ctx, 10); setPadding(p, p, p, p)
        addView(pastille(ctx, couleur, lab, 11f))
        addView(Ui.text(ctx, String.format(Locale.FRANCE, "%.1f", km), 19f, Ui.FG).apply { typeface = Ui.MEDIUM })
        addView(Ui.text(ctx, "km", 11f, Ui.MUTED))
    }

    /** Logo La Bonne Course dans ses couleurs d'origine (voitures noires, arcs dorés), sur une carte blanche arrondie. */
    fun logo(ctx: Context) = android.widget.FrameLayout(ctx).apply {
        background = Ui.box(ctx, Color.WHITE, Color.parseColor("#E8DCC0"), 1, 24)
        clipToOutline = true; outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        val p = Ui.dp(ctx, 10); setPadding(p, p, p, p)
        addView(ImageView(ctx).apply {
            setImageResource(R.drawable.logo_facture); adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 150)))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    /** Demande de confirmation avant une action définitive. */
    fun confirmer(ctx: Context, titre: String, message: String?, action: String, onOui: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(ctx).setTitle(titre).setMessage(message)
            .setPositiveButton(action) { _, _ -> onOui() }
            .setNegativeButton("Annuler", null).show()
    }
}

/**
 * Zone de signature au doigt (fond blanc, trait noir), comme sur un terminal de livraison.
 * Empêche le défilement de l'écran pendant que le client signe.
 */
class SignaturePad(ctx: Context) : View(ctx) {
    private val path = Path()
    private val trait = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = Ui.dp(ctx, 3).toFloat()
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private var minX = Float.MAX_VALUE; private var minY = Float.MAX_VALUE
    private var maxX = 0f; private var maxY = 0f
    private var longueur = 0f
    private var lx = 0f; private var ly = 0f
    var onChange: (() -> Unit)? = null

    /** Vide tant que le tracé est trop court pour être une vraie signature. */
    val vide get() = longueur < Ui.dp(context, 60)

    init { background = Ui.box(ctx, Color.WHITE, Ui.LINE, 1, 12) }

    fun effacer() {
        path.reset(); longueur = 0f
        minX = Float.MAX_VALUE; minY = Float.MAX_VALUE; maxX = 0f; maxY = 0f
        invalidate(); onChange?.invoke()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x; val y = e.y
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); path.moveTo(x, y); path.lineTo(x + 0.1f, y) }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.historySize) { path.lineTo(e.getHistoricalX(i), e.getHistoricalY(i)) }
                path.lineTo(x, y)
                longueur += kotlin.math.hypot(x - lx, y - ly)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); onChange?.invoke() }
        }
        lx = x; ly = y
        minX = min(minX, x); minY = min(minY, y); maxX = max(maxX, x); maxY = max(maxY, y)
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawPath(path, trait)
        if (longueur == 0f) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9AA3AB"); textSize = Ui.dp(context, 15).toFloat(); textAlign = Paint.Align.CENTER }
            c.drawText("Le client signe ici avec le doigt", width / 2f, height / 2f, p)
        }
    }

    /** Image de la signature, recadrée, fond blanc. */
    fun image(): Bitmap {
        val m = Ui.dp(context, 12).toFloat()
        val l = max(0f, minX - m); val t = max(0f, minY - m)
        val r = min(width.toFloat(), maxX + m); val b = min(height.toFloat(), maxY + m)
        val w = max(1, (r - l).toInt()); val h = max(1, (b - t).toInt())
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.translate(-l, -t)
        c.drawPath(path, trait)
        return bmp
    }
}
