package fr.bonnecourse

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.LinearLayout

/** Mise en route du trafic en direct (clé TomTom gratuite), en 3 gestes : ouvrir, copier, coller. */
object TraficDirect {
    fun carte(a: MainActivity): LinearLayout {
        val store = a.store
        val c = W.carte(a, "Trafic en direct")
        c.addView(Ui.text(a, "À activer une fois : la bulle calculera chaque offre avec les bouchons du moment.", 15f, Ui.WARN, true))
        c.addView(W.aide(a, "1. « Créer mon compte TomTom » : compte gratuit, sans carte bancaire.\n" +
            "2. Sur le site, ouvre « Keys » et copie ta clé (API Key).\n" +
            "3. Reviens ici et touche « Coller ma clé »."))
        c.addView(W.bouton(a, "1. Créer mon compte TomTom") {
            try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.tomtom.com/user/register"))) } catch (_: Exception) {}
        })
        c.addView(W.bouton(a, "3. Coller ma clé", true) {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val k = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(a)?.toString()?.trim().orEmpty()
            if (k.length < 20 || ' ' in k) { a.toast("Copie d'abord ta clé TomTom (API Key), puis touche ce bouton."); return@bouton }
            essayer(a, k)
        })
        return c
    }

    /** Teste la clé ; enregistrée seulement si TomTom répond. */
    fun essayer(a: MainActivity, k: String) {
        a.toast("Vérification de la clé…")
        Thread {
            val ok = Trafic.tester(k)
            a.runOnUiThread {
                if (ok) { a.store.cleTomTom = k; a.toast("Trafic en direct activé ✓") }
                else a.toast("La clé ne répond pas : vérifie-la, et la connexion internet.")
                a.afficher()
            }
        }.start()
    }
}
