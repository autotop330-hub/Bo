package fr.bonnecourse

import android.content.Context
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Suppression d'une course, toujours après confirmation.
 * Une course facturée peut être supprimée (course d'essai, erreur) : la facture, son PDF et la signature partent avec elle.
 * Si c'était la dernière facture émise, le numéro est rendu (pas de trou dans la numérotation).
 */
object Suppression {
    fun course(ctx: Context, store: Store, r: Ride, apres: () -> Unit) {
        val h = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        val quoi = "${h.format(Date(r.debut))} · ${r.source} · ${if (r.prix > 0) W.eur2(r.prix) else "sans montant"}"
        if (r.facture.isBlank()) {
            W.confirmer(ctx, "Supprimer cette course ?",
                "$quoi\n\nElle disparaît de la boîte noire, avec son tracé GPS, et du chiffre d'affaires. C'est définitif.", "Supprimer") {
                effacer(ctx, store, r); apres()
            }
        } else {
            W.confirmer(ctx, "Supprimer la course et sa facture ${r.facture} ?",
                "$quoi\n\nÀ faire seulement pour une course d'essai ou une erreur. Pour une vraie facture déjà envoyée au client, " +
                    "le comptable doit plutôt faire un avoir.\n\nLa facture, son PDF et la signature seront supprimés. C'est définitif.",
                "Supprimer la course et la facture") {
                effacer(ctx, store, r); apres()
            }
        }
    }

    /** Plusieurs courses et trajets domicile (clés « r<debut> » et « s<debut> »). */
    fun plusieurs(ctx: Context, store: Store, cles: Set<String>, apres: () -> Unit) {
        val factures = cles.filter { it[0] == 'r' }.mapNotNull { store.ride(it.drop(1).toLong()) }.count { it.facture.isNotBlank() }
        W.confirmer(ctx, "Supprimer ${cles.size} élément${if (cles.size > 1) "s" else ""} ?",
            "Les courses disparaissent de la boîte noire, avec leur tracé GPS, et du chiffre d'affaires." +
                (if (factures > 0) "\n\n$factures course${if (factures > 1) "s ont" else " a"} une facture : elle${if (factures > 1) "s" else ""} sera aussi supprimée " +
                    "(à faire seulement pour des essais ; sinon, avoir par le comptable)." else "") + "\n\nC'est définitif.", "Supprimer") {
            // Factures les plus récentes d'abord, pour rendre les numéros dans l'ordre
            cles.sortedByDescending { it.drop(1).toLong() }.forEach { k ->
                val t = k.drop(1).toLong()
                if (k[0] == 'r') store.ride(t)?.let { effacer(ctx, store, it, false) } else store.deleteSegment(t)
            }
            Toast.makeText(ctx, "${cles.size} supprimé${if (cles.size > 1) "s" else ""}", Toast.LENGTH_SHORT).show()
            apres()
        }
    }

    private fun effacer(ctx: Context, store: Store, r: Ride, message: Boolean = true) {
        if (r.facture.isNotBlank()) {
            store.supprimerFacture(r.debut)
            FacturePdf.fichier(ctx, r.facture).delete()
        }
        store.deleteRide(r.debut)
        store.supprimerBrouillon(r.debut)
        store.routeRecalee("r${r.debut}")?.let { java.io.File(ctx.filesDir, "traces/route-r${r.debut}.json").delete() }
        if (message) Toast.makeText(ctx, if (r.facture.isNotBlank()) "Course et facture ${r.facture} supprimées" else "Course supprimée", Toast.LENGTH_SHORT).show()
    }
}
