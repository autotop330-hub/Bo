package fr.bonnecourse

/**
 * Postes de frais. « groupe » dit quelle estimation automatique le poste remplace :
 * tant qu'aucun frais réel n'est saisi dans un groupe pour le mois, l'appli l'estime.
 *  - energie   : recharge (estimée = km pro × conso × prix du kWh)
 *  - voiture   : loyer + assurance (estimés = charges fixes du profil)
 *  - entretien : entretien, pneus, lavage (estimé = km pro × usure)
 *  - societe   : frais de la société (estimés = frais fixes de la société)
 *  - autre     : toujours au réel, jamais estimé
 */
enum class Categorie(val nom: String, val tva: Double, val groupe: String) {
    RECHARGE("Recharge Tesla", 20.0, "energie"),
    LOYER("Loyer de la voiture", 0.0, "voiture"),
    ASSURANCE("Assurance", 0.0, "voiture"),
    ENTRETIEN("Entretien, pneus", 20.0, "entretien"),
    LAVAGE("Lavage", 20.0, "entretien"),
    PEAGE("Péages, parking", 20.0, "autre"),
    REPAS("Repas", 10.0, "autre"),
    TELEPHONE("Téléphone, internet", 20.0, "societe"),
    ABONNEMENT("Abonnements", 20.0, "societe"),
    BUREAU("Bureau, fournitures", 20.0, "societe"),
    COMPTABLE("Comptable, banque", 20.0, "societe"),
    AUTRE("Autre", 20.0, "autre");

    companion object {
        fun de(nom: String) = values().firstOrNull { it.name == nom } ?: AUTRE
        val GROUPES = mapOf("energie" to "Recharge", "voiture" to "Loyer et assurance de la voiture",
            "entretien" to "Entretien et lavage", "societe" to "Frais de la société", "autre" to "Autres frais")
    }
}

/** Un frais. mensuel = se répète chaque mois à partir de sa date (jusqu'à finMensuel si renseigné). */
data class Frais(
    val id: Long,
    val date: Long,
    val categorie: Categorie,
    val ttc: Double,
    val tauxTva: Double,
    val note: String = "",
    val photo: String = "",        // chemin du justificatif photographié
    val mensuel: Boolean = false,
    val finMensuel: Long = 0L      // 0 = toujours en cours
) {
    fun tva() = ttc * tauxTva / (100 + tauxTva)
    fun ht() = ttc - tva()

    /** Ce frais compte-t-il dans le mois (année, mois 1-12) ? */
    fun dansMois(annee: Int, mois: Int): Boolean {
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = date
        val a = cal.get(java.util.Calendar.YEAR); val m = cal.get(java.util.Calendar.MONTH) + 1
        if (!mensuel) return a == annee && m == mois
        val cle = annee * 12 + mois
        if (cle < a * 12 + m) return false
        if (finMensuel > 0) {
            cal.timeInMillis = finMensuel
            if (cle > cal.get(java.util.Calendar.YEAR) * 12 + cal.get(java.util.Calendar.MONTH) + 1) return false
        }
        return true
    }
}

data class Client(
    val nom: String = "",
    val societe: String = "",
    val siren: String = "",
    val adresse: String = "",
    val email: String = "",
    val tel: String = ""
) {
    val pro get() = societe.isNotBlank() || siren.isNotBlank()
    /** Prénom ou nom pour le message (« Bonjour Marie »). */
    val appel get() = nom.trim().ifBlank { societe.trim() }
}

/** Facture d'une course privée. La course (Ride) reste la source des heures, lieux, km et prix. */
data class Facture(
    val numero: String,
    val course: Long,            // Ride.debut
    val emission: Long,
    val client: Client,
    val paiement: String,        // Espèces, Carte bancaire, Virement…
    val reservation: Long,       // date et heure de la réservation préalable
    val signature: String,       // chemin de l'image de signature
    val signeLe: Long
)

/** Coordonnées de la société, imprimées sur les factures. */
data class Entreprise(
    val raisonSociale: String = "",
    val forme: String = "SASU",
    val capital: String = "",
    val adresse: String = "",
    val siret: String = "",
    val rcs: String = "",
    val tvaIntra: String = "",
    val evtc: String = "",          // numéro d'inscription au registre des VTC
    val chauffeur: String = "",
    val tel: String = "",
    val email: String = "",
    val message: String = MESSAGE_DEFAUT
) {
    val complete get() = raisonSociale.isNotBlank() && siret.isNotBlank() && adresse.isNotBlank() && evtc.isNotBlank()

    companion object {
        const val MESSAGE_DEFAUT = "Bonjour {client},\n\n" +
            "Merci d'avoir voyagé avec nous, ce fut un plaisir de vous conduire.\n" +
            "Vous trouverez ci-joint la facture {numero} de votre course du {date} ({depart} → {arrivee}).\n\n" +
            "Au plaisir de vous retrouver très bientôt pour vos prochains trajets.\n" +
            "Belle journée,\n\n{chauffeur}\n{societe}\n{telephone}"
    }
}

/**
 * Trajet professionnel hors course, pour le carnet kilométrique :
 *  - « depart » : du domicile jusqu'à la première course acceptée ;
 *  - « retour » : de la fin de service jusqu'au domicile.
 * Ces km sont déjà comptés dans les km pro du jour ; ils sont détaillés à part pour le justificatif.
 */
data class Segment(
    val debut: Long,
    val fin: Long,
    val type: String,          // depart, retour
    val km: Double,
    val lieuDepart: String = "",
    val lieuArrivee: String = ""
) {
    val minutes get() = (fin - debut) / 60000.0
    val nom get() = if (type == DEPART) "Départ du domicile" else "Retour au domicile"
    companion object {
        const val DEPART = "depart"
        const val RETOUR = "retour"
    }
}

/**
 * Relevé du compteur et de la batterie de la Tesla, horodaté (carnet kilométrique certifié par la voiture).
 * type : debut_service, fin_service, course_acceptee, client_a_bord, course_terminee,
 *        depart_domicile, arrivee_domicile, recharge, manuel.
 */
data class Releve(
    val t: Long,
    val type: String,
    val odoKm: Double,
    val batterie: Double = -1.0,
    val autonomieKm: Double = -1.0,
    val lat: Double = 0.0, val lon: Double = 0.0,
    val majVoiture: Long = 0L,      // heure à laquelle la voiture a envoyé ce compteur
    val note: String = ""
) {
    val libelle get() = when (type) {
        "debut_service" -> "Début de service"
        "fin_service" -> "Fin de service"
        "course_acceptee" -> "Course acceptée"
        "client_a_bord" -> "Client à bord"
        "course_terminee" -> "Client déposé"
        "depart_domicile" -> "Départ du domicile"
        "arrivee_domicile" -> "Arrivée au domicile"
        "recharge" -> "Recharge"
        else -> "Relevé manuel"
    }
}
