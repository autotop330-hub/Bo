package fr.bonnecourse

import android.app.DatePickerDialog
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Onglet « Frais » : recharge, loyer, assurance, repas, abonnements… avec photo du ticket. */
class EcranFrais(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        col.addView(W.entete(a, "Dépenses", "Tes charges et justificatifs, au même endroit."))
        col.addView(a.navMois())
        val l = store.fraisDuMois(a.vueAnnee, a.vueMois).sortedByDescending { it.date }
        val c = W.carteVedette(a, "Dépenses du mois")
        c.addView(W.hero(a, W.eur2(l.sumOf { it.ttc }), "charges saisies TTC · ${l.size} enregistrement${if (l.size > 1) "s" else ""}" +
            if (store.profile.tva && l.isNotEmpty()) " · dont ${W.eur2(l.sumOf { it.tva() })} de TVA récupérable" else ""))
        c.addView(W.bouton(a, "Ajouter un frais", true) { editer(null) })
        col.addView(c)

        if (l.isEmpty()) {
            col.addView(W.etatVide(a, "Aucune dépense saisie", "Ajoute une recharge, un repas ou un justificatif. En attendant, certaines charges sont estimées selon les réglages du véhicule."))
            return
        }
        val parCat = l.groupBy { it.categorie }.map { (cat, x) -> Triple(cat.nom, x.sumOf { it.ttc }, false) }.sortedByDescending { it.second }
        val g = W.carte(a, "Par poste")
        g.addView(Barres.vue(a, parCat))
        col.addView(g)

        val liste = W.carte(a, "Journal des dépenses")
        val f = SimpleDateFormat("dd/MM", Locale.FRANCE)
        l.forEach { x ->
            liste.addView(Ui.vertical(a, 2).apply {
                addView(W.ligne(a, "${if (x.mensuel) "↻ chaque mois" else f.format(Date(x.date))} · ${x.categorie.nom}", W.eur2(x.ttc)))
                val infos = listOfNotNull(x.note.takeIf { it.isNotBlank() }, if (x.photo.isNotBlank()) "📷 ticket" else null,
                    if (x.tauxTva > 0) "TVA ${W.n(x.tauxTva)} %" else "sans TVA")
                addView(W.aide(a, infos.joinToString(" · ")))
                val p = Ui.dp(a, 12); setPadding(p, p, p, p)
                background = Ui.touch(a, Ui.RAISE, Ui.LINE, 15)
                isClickable = true; isFocusable = true
                contentDescription = "Ouvrir le frais ${x.categorie.nom} de ${W.eur2(x.ttc)}"
                setOnClickListener { options(x) }
            })
        }
        col.addView(liste)
        col.addView(W.aide(a, "Touche un frais pour le modifier, voir le ticket ou le supprimer. " +
            "Repas : ton comptable n'en déduira qu'une partie."))
    }

    private fun options(x: Frais) {
        val choix = mutableListOf("Modifier")
        if (x.photo.isNotBlank()) choix += "Voir le ticket"
        if (x.mensuel) choix += "Arrêter à partir de ce mois"
        choix += "Supprimer"
        AlertDialog.Builder(a).setTitle("${x.categorie.nom} · ${W.eur2(x.ttc)}")
            .setItems(choix.map { it as CharSequence }.toTypedArray()) { _, i ->
                when (choix[i]) {
                    "Modifier" -> editer(x)
                    "Voir le ticket" -> a.voirPhoto(x.photo)
                    "Arrêter à partir de ce mois" -> {
                        // Dernier mois compté = le mois précédent celui affiché
                        val cal = Calendar.getInstance().apply { set(a.vueAnnee, a.vueMois - 1, 1, 0, 0, 0); add(Calendar.DAY_OF_MONTH, -1) }
                        if (cal.timeInMillis < x.date) store.deleteFrais(x.id) else store.addFrais(x.copy(finMensuel = cal.timeInMillis))
                        a.afficher()
                    }
                    "Supprimer" -> AlertDialog.Builder(a).setTitle("Supprimer ce frais ?")
                        .setMessage(if (x.mensuel) "Il disparaît de tous les mois." else null)
                        .setPositiveButton("Supprimer") { _, _ -> store.deleteFrais(x.id); a.afficher() }
                        .setNegativeButton("Annuler", null).show()
                }
            }.setNegativeButton("Fermer", null).show()
    }

    /** Ajout ou modification d'un frais. */
    private fun editer(x: Frais?) {
        val cats = Categorie.values().toList()
        val c = Ui.vertical(a, 6).apply { val p = Ui.dp(a, 18); setPadding(p, p, p, p) }
        // Date : aujourd'hui si le mois affiché est le mois en cours, sinon le 1er du mois affiché
        var date = x?.date ?: run {
            val now = Calendar.getInstance()
            if (a.duMois(now.timeInMillis)) now.timeInMillis
            else Calendar.getInstance().apply { set(a.vueAnnee, a.vueMois - 1, 1, 12, 0, 0) }.timeInMillis
        }
        var photo = x?.photo ?: ""

        c.addView(Ui.text(a, "Poste", 13f, Ui.MUTED))
        val sCat = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, cats.map { it.nom }) }
        c.addView(sCat)
        val eMontant = W.champ(a, c, "Montant payé (TTC, €)", x?.let { W.n(it.ttc) } ?: "", W.NOMBRE, "ex. 18,40")
        val eTva = W.champ(a, c, "TVA sur le ticket (%)", W.n(x?.tauxTva ?: cats[0].tva), W.NOMBRE)
        c.addView(Ui.text(a, "Date", 13f, Ui.MUTED))
        val fmt = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE)
        val bDate = Ui.text(a, fmt.format(Date(date)) + "  ✎", 17f, Ui.ACCENT, true).apply {
            val p = Ui.dp(a, 8); setPadding(0, p, 0, p)
        }
        bDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = date }
            DatePickerDialog(a, { _, y, m, d -> cal.set(y, m, d); date = cal.timeInMillis; bDate.text = fmt.format(Date(date)) + "  ✎" },
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        c.addView(bDate)
        val eNote = W.champ(a, c, "Note (facultatif)", x?.note ?: "", indice = "ex. Superchargeur Lattes")
        val sMensuel = SwitchCompat(a).apply { text = "Se répète chaque mois (assurance, loyer, abonnement)"; setTextColor(Ui.FG); isChecked = x?.mensuel ?: false }
        c.addView(sMensuel)
        val tPhoto = W.aide(a, if (photo.isNotBlank()) "📷 Ticket photographié" else "")
        c.addView(W.bouton(a, if (photo.isBlank()) "Photographier le ticket" else "Reprendre la photo du ticket") {
            a.prendrePhoto { chemin -> if (chemin != null) { photo = chemin; tPhoto.text = "📷 Ticket photographié" } }
        })
        c.addView(tPhoto)

        var premier = x != null
        sCat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (premier) { premier = false; return }
                eTva.setText(W.n(cats[pos].tva))
                val cat = cats[pos]
                sMensuel.isChecked = cat == Categorie.LOYER || cat == Categorie.ASSURANCE || cat == Categorie.ABONNEMENT || cat == Categorie.TELEPHONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        if (x != null) sCat.setSelection(cats.indexOf(x.categorie))

        AlertDialog.Builder(a).setTitle(if (x == null) "Nouveau frais" else "Modifier le frais")
            .setView(ScrollView(a).apply { addView(c, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) })
            .setPositiveButton("Enregistrer") { _, _ ->
                val m = W.nombre(eMontant)
                if (m == null || m <= 0) { a.toast("Montant manquant : frais non enregistré"); return@setPositiveButton }
                val cat = cats[sCat.selectedItemPosition.coerceIn(0, cats.size - 1)]
                store.addFrais(Frais(x?.id ?: System.currentTimeMillis(), date, cat, m, (W.nombre(eTva) ?: cat.tva).coerceIn(0.0, 20.0),
                    W.txt(eNote), photo, sMensuel.isChecked, if (sMensuel.isChecked) x?.finMensuel ?: 0L else 0L))
                a.allerAuMois(Calendar.getInstance().apply { timeInMillis = date }.get(Calendar.YEAR),
                    Calendar.getInstance().apply { timeInMillis = date }.get(Calendar.MONTH) + 1)
            }
            .setNegativeButton("Annuler", null).show()
    }
}
