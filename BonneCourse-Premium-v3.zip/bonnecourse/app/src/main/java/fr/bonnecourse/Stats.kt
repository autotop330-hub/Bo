package fr.bonnecourse

import java.util.Calendar

/**
 * Optimisation : où et quand il est le plus rentable de rouler, d'après les vraies courses enregistrées.
 * Net d'une course = encaissé − TVA − coût des km (recharge, usure, loyer et assurance au km).
 * €/h net = net ÷ temps passé (approche + client à bord).
 */
object Stats {
    data class Ligne(val nom: String, val courses: Int, val parHeure: Double, val parKm: Double, val net: Double)

    val CRENEAUX = listOf("Nuit (0 h–6 h)" to 0..5, "Matin (6 h–10 h)" to 6..9, "Midi (10 h–14 h)" to 10..13,
        "Après-midi (14 h–17 h)" to 14..16, "Soir (17 h–21 h)" to 17..20, "Fin de soirée (21 h–24 h)" to 21..23)
    val JOURS = listOf("Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche")

    fun net(r: Ride, p: Profile): Double {
        val tva = if (p.tva && p.regime != "micro") {
            val c = if (r.prive) 0.0 else (p.commissionPlateforme / 100).coerceIn(0.0, 0.9)
            r.prix / (1 - c) * 0.10 / 1.10
        } else 0.0
        return r.prix - tva - r.kmTotal * p.coutKm()
    }

    private fun ligne(nom: String, l: List<Ride>, p: Profile): Ligne {
        val net = l.sumOf { net(it, p) }
        val h = l.sumOf { it.minTotal } / 60.0
        val km = l.sumOf { it.kmTotal }
        return Ligne(nom, l.size, if (h > 0) net / h else 0.0, if (km > 0) l.sumOf { it.prix } / km else 0.0, net)
    }

    /** Courses utilisables pour les statistiques (montant connu, temps mesuré). */
    fun base(rides: List<Ride>, depuis: Long) = rides.filter { it.debut >= depuis && it.prix > 0 && it.minTotal >= 2 }

    fun parCreneau(rides: List<Ride>, p: Profile): List<Ligne> {
        val cal = Calendar.getInstance()
        return CRENEAUX.mapNotNull { (nom, heures) ->
            val l = rides.filter { cal.timeInMillis = it.debut; cal.get(Calendar.HOUR_OF_DAY) in heures }
            if (l.size >= 2) ligne(nom, l, p) else null
        }
    }

    fun parJour(rides: List<Ride>, p: Profile): List<Ligne> {
        val cal = Calendar.getInstance()
        return JOURS.mapIndexedNotNull { i, nom ->
            val jour = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)[i]
            val l = rides.filter { cal.timeInMillis = it.debut; cal.get(Calendar.DAY_OF_WEEK) == jour }
            if (l.size >= 2) ligne(nom, l, p) else null
        }
    }

    fun parPlateforme(rides: List<Ride>, p: Profile) = rides.groupBy { it.source }.filter { it.value.size >= 2 }.map { (s, l) -> ligne(s, l, p) }

    /** Ville de prise en charge, tirée du lieu enregistré (« Rue X, Montpellier (43.6,3.8) » → « Montpellier »). */
    fun ville(lieu: String) = lieu.substringBefore(" (").substringAfterLast(", ").trim().takeIf { it.isNotBlank() && !it[0].isDigit() }

    fun parVille(rides: List<Ride>, p: Profile) = rides.groupBy { ville(it.lieuPrise) }.filterKeys { it != null }
        .filter { it.value.size >= 2 }.map { (v, l) -> ligne(v!!, l, p) }
}
