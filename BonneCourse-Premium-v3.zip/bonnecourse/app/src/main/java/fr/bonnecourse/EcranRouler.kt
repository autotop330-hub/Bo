package fr.bonnecourse

import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Onglet « Rouler » : la bulle, la journée en cours, les courses privées. */
class EcranRouler(private val a: MainActivity) {
    private val store = a.store

    fun remplir(col: LinearLayout) {
        val prenom = store.entreprise.chauffeur.trim().substringBefore(" ")
        col.addView(W.cockpit(a, prenom, BubbleService.running))
        col.addView(aujourdhui())
        col.addView(actionsPrincipales())
        aSigner()?.let { col.addView(it) }
        EcranTesla.etat(a)?.let { col.addView(it) }
        trajets()?.let { col.addView(it) }
        // Les informations avancées restent accessibles, mais ne prennent plus le dessus
        // sur les actions du chauffeur au démarrage.
        col.addView(Ui.details(a, "Comment fonctionne l'assistant ?", modeEmploi()))
        if (store.cleTomTom.isBlank())
            col.addView(Ui.details(a, "Configurer le trafic en direct", TraficDirect.carte(a)))
    }

    /** Démarrage en un geste, avec l'état du service et les actions les plus fréquentes. */
    private fun actionsPrincipales(): View {
        val c = W.carte(a, "Actions rapides")
        val actif = BubbleService.running
        c.addView(W.puce(a, if (actif) "● Assistant actif" else "● Assistant en veille", if (actif) Ui.GO else Ui.MUTED))
        c.addView(W.aide(a, if (actif)
            "L'analyse des offres est prête pendant tes courses."
            else "Active l'assistant pour analyser les offres Uber, Bolt et autres plateformes."))
        if (actif) {
            c.addView(W.bouton(a, "Arrêter l'assistant", true, Ui.RAISE) { a.arreterBulle() }.apply { setTextColor(Ui.FG) })
        } else {
            c.addView(W.bouton(a, if (a.peutAfficherBulle()) "Activer l'assistant" else "Autoriser l'assistant", true) {
                if (a.peutAfficherBulle()) a.lancerBulle() else a.autoriserBulle()
            })
        }
        c.addView(Ui.buttonRow(a,
            W.bouton(a, "Course privée") { a.demarrerPrivee() },
            W.bouton(a, "Saisie manuelle") { a.ouvrirFacture(null) }))
        return c
    }

    private fun modeEmploi(): View = W.carte(a).apply {
        addView(W.aide(a, "Active l'assistant avant d'ouvrir Uber ou Bolt. Une demande d'autorisation de capture d'écran peut apparaître : sélectionne « Écran entier »."))
        addView(W.aide(a, "La lecture des offres est effectuée localement sur le téléphone. Un appui long sur la bulle ouvre aussi les options de course privée et de trajet."))
        addView(W.bouton(a, "Tester une capture d'offre") { a.testerCapture() })
        if (!a.peutAfficherBulle()) addView(W.bouton(a, "Autoriser la superposition") { a.autoriserBulle() })
    }

    private fun hm(min: Double) = "${(min / 60).toInt()} h ${String.format("%02d", (min % 60).roundToInt())}"

    /** La journée : encaissé, objectif, net estimé, temps de service et taux d'occupation, km. */
    private fun aujourdhui(): View {
        val c = W.carteVedette(a, "Tableau de bord  /  Aujourd'hui")
        val debutJour = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val p = store.profile
        val rs = store.rides().filter { it.debut >= debutJour }
        val total = rs.sumOf { it.prix }
        val obj = store.objectifJour
        c.addView(W.hero(a, W.eur2(total), "chiffre d'affaires · ${rs.size} course${if (rs.size > 1) "s" else ""}", Ui.FG))
        c.addView(W.progression(a, if (obj > 0) total / obj else 0.0, if (total >= obj) Ui.GO else Ui.ACCENT))
        c.addView(W.ligne(a, "Objectif du jour", if (total >= obj) "✓ atteint (${W.eur(obj)})" else "encore ${W.eur(obj - total)} sur ${W.eur(obj)}",
            couleur = if (total >= obj) Ui.GO else Ui.FG).apply {
            background = Ui.touch(a, Ui.RAISE, Ui.LINE, 13)
            setPadding(Ui.dp(a, 11), Ui.dp(a, 10), Ui.dp(a, 11), Ui.dp(a, 10))
            isClickable = true; isFocusable = true
            contentDescription = "Modifier l'objectif du jour"
            setOnClickListener { objectif() }
        })

        // Net réel estimé de la journée (TVA, recharge, usure, loyer et assurance au km déduits)
        val net = rs.sumOf { Stats.net(it, p) }
        val jour = SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(Date())
        val minCourse = rs.sumOf { it.minTotal }
        val enCours = store.serviceDebut.takeIf { it > 0 }?.let { (System.currentTimeMillis() - maxOf(it, debutJour)) / 60000.0 } ?: 0.0
        val minService = (store.minutesService()[jour] ?: 0.0) + enCours
        val occupation = if (minService > 1) (minCourse / minService).coerceAtMost(1.0) else 0.0
        c.addView(Ui.buttonRow(a,
            stat("Net après frais estimés", W.eur(net), Ui.GO),
            stat("Chiffre d'affaires / h", if (minService > 5) W.eur(total / minService * 60) else "—", Ui.ACCENT)))
        if (minService > 1) {
            c.addView(W.ligne(a, "Temps avec client", if (minService > 5) "${(occupation * 100).roundToInt()} %" else "—", couleur = Ui.FG))
            c.addView(W.progression(a, occupation, Ui.GO))
            c.addView(W.aide(a, "Service ${hm(minService)} · en course ${hm(minCourse)}"))
        }

        val km = maxOf(store.service()[jour] ?: 0.0, rs.sumOf { it.kmTotal })
        val sj = store.segments().filter { it.debut >= debutJour }
        c.addView(W.ligne(a, "Distance professionnelle", String.format(Locale.FRANCE, "%.1f km", km), true))
        val details = Ui.vertical(a, 10).apply {
            addView(Ui.buttonRow(a,
                W.chiffreKm(a, "Approche", rs.sumOf { it.kmApproche }, Ui.WARN),
                W.chiffreKm(a, "Client", rs.sumOf { it.kmCourse }, Ui.GO),
                W.chiffreKm(a, "Domicile", sj.sumOf { it.km }, Ui.ACCENT)))
            val parSource = rs.groupBy { it.source }.mapValues { (_, l) -> l.sumOf { it.prix } }.filterValues { it > 0 }
            parSource.entries.sortedByDescending { it.value }.forEach { (source, valeur) ->
                addView(W.ligne(a, source, W.eur2(valeur), couleur = W.couleurSource(source)))
            }
        }
        c.addView(Ui.details(a, "Kilomètres et plateformes", details))
        return c
    }

    private fun stat(lab: String, v: String, couleur: Int): View = Ui.vertical(a, 2).apply {
        background = Ui.box(a, android.graphics.Color.parseColor("#26FFFFFF"), android.graphics.Color.TRANSPARENT, 0, 14)
        val pd = Ui.dp(a, 12); setPadding(pd, pd, pd, pd)
        addView(Ui.text(a, lab, 11f, Ui.MUTED, true).apply { maxLines = 2; minHeight = Ui.dp(a, 31) })
        addView(Ui.text(a, v, 23f, couleur, true).apply { maxLines = 1 })
    }

    private fun objectif() {
        val e = android.widget.EditText(a).apply {
            inputType = W.NOMBRE; setText(W.n(store.objectifJour)); setTextColor(Ui.FG)
        }
        androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Objectif d'encaissement par jour (€)").setView(e)
            .setPositiveButton("Enregistrer") { _, _ -> W.nombre(e)?.takeIf { it > 0 }?.let { store.objectifJour = it; a.afficher() } }
            .setNegativeButton("Annuler", null).show()
    }

    /** Courses privées pas encore signées. */
    private fun aSigner(): View? {
        val l = store.rides().filter { it.prive && it.facture.isBlank() }.sortedByDescending { it.debut }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Factures à finir (${l.size})")
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        l.take(15).forEach { r ->
            c.addView(Ui.vertical(a, 2).apply {
                addView(Ui.text(a, "${f.format(Date(r.priseEnCharge))} · ${Analyzer.fmt1(r.kmCourse)} km" + (if (r.prix > 0) " · ${W.eur2(r.prix)}" else ""), 15f, Ui.FG, true))
                if (r.lieuArrivee.isNotBlank()) addView(W.aide(a, "${r.lieuPrise.substringBefore(" (")} → ${r.lieuArrivee.substringBefore(" (")}"))
                addView(Ui.text(a, if (store.dejaSignee(r.debut)) "✓ Signée · toucher pour finir la facture" else "Toucher pour faire signer et facturer",
                    13f, if (store.dejaSignee(r.debut)) Ui.GO else Ui.WARN))
                setOnClickListener { a.ouvrirFacture(r) }
                setOnLongClickListener { Suppression.course(a, store, r) { a.afficher() }; true }
            })
        }
        return c
    }

    /** Trajets détectés automatiquement qui attendent « pro » ou « perso ». */
    private fun trajets(): View? {
        val l = store.trajets().filter { it.statut == Trajet.A_CLASSER }
        if (l.isEmpty()) return null
        val c = W.carte(a, "Trajets à classer (${l.size})")
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE)
        val ville = { x: String -> x.substringBefore(" (").let { it.substringAfter(", ", it) } }
        l.take(10).forEach { t ->
            c.addView(Ui.vertical(a, 6).apply {
                addView(Ui.text(a, "${fmt.format(Date(t.debut))} · ${Analyzer.fmt1(t.km)} km · ${t.minutes.roundToInt()} min", 15f, Ui.FG, true))
                val lieux = listOf(ville(t.depart), ville(t.arrivee)).filter { it.isNotBlank() }.joinToString(" → ")
                if (lieux.isNotBlank()) addView(W.aide(a, lieux))
                addView(Ui.buttonRow(a,
                    Ui.button(a, "Pro", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PRO); a.afficher() },
                    Ui.button(a, "Perso", Ui.RAISE, Ui.FG, Ui.LINE) { store.classer(t.debut, Trajet.PERSO); a.afficher() }))
            })
        }
        return c
    }
}
