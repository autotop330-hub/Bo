package fr.bonnecourse

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.HorizontalScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Onglet « Courses » : la boîte noire du mois, jour par jour.
 * Chaque journée = carnet kilométrique : départ du domicile, courses (approche + client à bord), retour au domicile.
 * Suppression : appui long sur une ligne, corbeille du détail, ou « Sélectionner » pour en supprimer plusieurs.
 */
class EcranCourses(private val a: MainActivity) {
    private val store = a.store
    private val jourCle = SimpleDateFormat("yyyyMMdd", Locale.FRANCE)

    fun remplir(col: LinearLayout) {
        col.addView(W.entete(a, "Courses & trajets", "Le carnet de bord de ton activité, au kilomètre près."))
        col.addView(a.navMois())
        val tout = store.rides().filter { a.duMois(it.debut) }
        val sources = listOf("Toutes") + tout.map { it.source }.distinct().sortedBy { listOf("Uber", "Bolt", "Privé").indexOf(it).let { i -> if (i < 0) 9 else i } }
        if (a.filtreSource !in sources) a.filtreSource = "Toutes"
        if (sources.size > 2) col.addView(filtres(sources))
        val rs = tout.filter { a.filtreSource == "Toutes" || it.source == a.filtreSource }
        val sgs = if (a.filtreSource == "Toutes") store.segments().filter { a.duMois(it.debut) } else emptyList()
        val sel = a.selection

        // Résumé du mois
        val resume = W.carteVedette(a, "Activité du mois")
        resume.addView(W.hero(a, W.eur2(rs.sumOf { it.prix }), "encaissés · ${rs.size} course${if (rs.size > 1) "s" else ""}"))
        resume.addView(Ui.buttonRow(a,
            W.chiffreKm(a, "Approche", rs.sumOf { it.kmApproche }, Ui.WARN),
            W.chiffreKm(a, "Client", rs.sumOf { it.kmCourse }, Ui.GO),
            W.chiffreKm(a, "Domicile", sgs.sumOf { it.km }, Ui.ACCENT)))
        val aSigner = rs.count { it.prive && it.facture.isBlank() }
        if (aSigner > 0) resume.addView(Ui.text(a, "$aSigner course${if (aSigner > 1) "s" else ""} privée${if (aSigner > 1) "s" else ""} à faire signer", 14f, Ui.WARN, true))
        if (sel == null && (rs.isNotEmpty() || sgs.isNotEmpty()))
            resume.addView(W.bouton(a, "Gérer les enregistrements") { a.selection = mutableSetOf(); a.afficher() })
        col.addView(resume)

        // Mode sélection : barre d'action en haut de la liste
        if (sel != null) col.addView(barreSelection(sel, rs, sgs))

        if (rs.isEmpty() && sgs.isEmpty()) {
            col.addView(W.etatVide(a, "Aucune course enregistrée", "Les courses acceptées depuis l'assistant et les courses privées apparaîtront ici. Tu peux aussi en saisir une depuis l'accueil."))
        } else {
            val jourF = SimpleDateFormat("EEEE d MMMM", Locale.FRANCE)
            val jours = (rs.map { jourCle.format(Date(it.debut)) } + sgs.map { jourCle.format(Date(it.debut)) }).distinct().sortedDescending()
            jours.take(a.joursVisibles).forEach { j ->
                val rj = rs.filter { jourCle.format(Date(it.debut)) == j }
                val sj = sgs.filter { jourCle.format(Date(it.debut)) == j }
                val premier = (rj.map { it.debut } + sj.map { it.debut }).min()
                val c = Ui.vertical(a, 8)
                c.addView(W.ligne(a, jourF.format(Date(premier)).replaceFirstChar { it.uppercase() }, W.eur2(rj.sumOf { it.prix }), true, Ui.ACCENT).apply {
                    setPadding(Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4), 0)
                })
                val kmJour = rj.sumOf { it.kmTotal } + sj.sumOf { it.km }
                c.addView(W.aide(a, "${Analyzer.fmt1(kmJour)} km pro enregistrés" +
                    (if (sj.isNotEmpty()) " dont ${Analyzer.fmt1(sj.sumOf { it.km })} km domicile" else "")).apply { setPadding(Ui.dp(a, 4), 0, 0, 0) })
                // Ordre chronologique dans la journée : départ, courses, retour
                val lignes = rj.map { it.debut to ligne(it, sel) } + sj.map { it.debut to ligneSegment(it, sel) }
                lignes.sortedBy { it.first }.forEach { c.addView(it.second) }
                col.addView(c)
            }
            if (jours.size > a.joursVisibles) {
                val restant = jours.size - a.joursVisibles
                col.addView(W.bouton(a, "Afficher ${minOf(7, restant)} jour${if (minOf(7, restant) > 1) "s" else ""} de plus ($restant restants)") {
                    a.joursVisibles += 7; a.afficher()
                })
            }
        }
        col.addView(W.aide(a, "Touche une course pour voir son détail et son parcours. Appui long pour les options de suppression."))
        col.addView(W.bouton(a, "Exporter le mois (tableur)") {
            a.exporter(String.format("courses-%04d-%02d.csv", a.vueAnnee, a.vueMois)) { EcranMois(a).csvMois() }
        })
    }

    /** Filtres scrollables : pas de boutons écrasés quand plusieurs plateformes sont présentes. */
    private fun filtres(sources: List<String>): View = HorizontalScrollView(a).apply {
        isHorizontalScrollBarEnabled = false
        clipToPadding = false
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sources.forEachIndexed { i, source ->
            val actif = source == a.filtreSource
            val couleur = if (source == "Toutes") Ui.ACCENT else W.couleurSource(source)
            val chip = Ui.text(a, source, 13f, if (actif) Ui.BG else Ui.FG, true).apply {
                gravity = Gravity.CENTER
                minWidth = Ui.dp(a, 82); minHeight = Ui.dp(a, 43)
                setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10))
                background = Ui.touch(a, if (actif) couleur else Ui.SURFACE, if (actif) couleur else Ui.LINE, 20)
                isClickable = true; isFocusable = true
                setOnClickListener { a.filtreSource = source; a.joursVisibles = 7; a.selection = null; a.afficher(); a.revenirEnHaut() }
            }
            row.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                if (i > 0) marginStart = Ui.dp(a, 8)
            })
        }
        addView(row)
    }

    // ---------------------------------------------------------------- Lignes

    /** Case de sélection ronde (mode « Sélectionner »). */
    private fun caseSel(coche: Boolean, possible: Boolean): View = View(a).apply {
        background = if (!possible) Ui.box(a, Ui.RAISE, Ui.LINE, 1, 12)
        else if (coche) Ui.box(a, Ui.STOP, Ui.STOP, 0, 12) else Ui.box(a, Ui.RAISE, Ui.MUTED, 2, 12)
        layoutParams = LinearLayout.LayoutParams(Ui.dp(a, 24), Ui.dp(a, 24)).apply { marginEnd = Ui.dp(a, 12) }
    }

    private fun basculer(sel: MutableSet<String>, cle: String) {
        if (!sel.remove(cle)) sel += cle
        a.afficher()
    }

    /** Une course : heure, plateforme, lieux, km d'approche et avec client ; montant à droite. */
    private fun ligne(r: Ride, sel: MutableSet<String>?): View {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val cle = "r${r.debut}"
        val possible = true
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.touch(a, Ui.RAISE, if (sel?.contains(cle) == true) Ui.STOP else Ui.LINE, 18)
            val p = Ui.dp(a, 14); setPadding(p, p, Ui.dp(a, 8), p)
        }
        if (sel != null) l.addView(caseSel(cle in sel, possible))
        val t = Ui.vertical(a, 5)
        t.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(Ui.text(a, "${h.format(Date(r.debut))} → ${h.format(Date(r.fin))}", 16f, Ui.FG, true))
            addView(W.puce(a, r.source, W.couleurSource(r.source)), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = Ui.dp(a, 10) })
        })
        val lieux = listOf(r.lieuPrise, r.lieuArrivee).map { it.substringBefore(" (").substringAfterLast(", ") }.filter { it.isNotBlank() && !it[0].isDigit() }
        if (lieux.isNotEmpty()) t.addView(Ui.text(a, lieux.joinToString("  →  "), 14f).apply { maxLines = 2 })
        t.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            if (!r.manuelle && r.kmApproche > 0) addView(W.pastille(a, Ui.WARN, "${Analyzer.fmt2(r.kmApproche)} km", 12f),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(a, 12) })
            addView(W.pastille(a, Ui.GO, "${Analyzer.fmt2(r.kmCourse)} km", 12f),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = Ui.dp(a, 12) })
            addView(Ui.text(a, "${r.minTotal.roundToInt()} min" + if (r.manuelle) " · à la main" else "", 12f, Ui.MUTED))
        })
        when {
            r.prive && r.facture.isBlank() && store.dejaSignee(r.debut) -> t.addView(Ui.text(a, "Signée · facture à finir", 13f, Ui.WARN, true))
            r.prive && r.facture.isBlank() -> t.addView(Ui.text(a, "À faire signer", 13f, Ui.WARN, true))
            r.facture.isNotBlank() -> t.addView(Ui.text(a, "✓ Facture ${r.facture}", 13f, Ui.GO))
        }
        l.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, if (r.prix > 0) W.eur2(r.prix) else "—", 17f, Ui.FG, true).apply { setPadding(Ui.dp(a, 8), 0, 0, 0) })
        if (sel == null) l.addView(W.icone(a, R.drawable.ic_chevron, Ui.MUTED, 20))
        l.setOnClickListener {
            if (sel != null) { if (possible) basculer(sel, cle) else a.toast("Course facturée : elle ne se supprime pas.") }
            else a.ouvrirCourse(r)
        }
        l.setOnLongClickListener {
            if (sel == null) supprimer(r) else basculer(sel, cle)
            true
        }
        return l
    }

    /** Trajet domicile ↔ service (carnet kilométrique). */
    private fun ligneSegment(sg: Segment, sel: MutableSet<String>?): View {
        val h = SimpleDateFormat("HH:mm", Locale.FRANCE)
        val cle = "s${sg.debut}"
        val l = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.touch(a, Ui.SURFACE, if (sel?.contains(cle) == true) Ui.STOP else Ui.LINE, 18)
            val p = Ui.dp(a, 14); setPadding(p, Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12))
        }
        if (sel != null) l.addView(caseSel(cle in sel, true))
        else l.addView(W.icone(a, R.drawable.ic_rouler, Ui.ACCENT, 20).apply {
            (layoutParams as LinearLayout.LayoutParams).marginEnd = Ui.dp(a, 12)
        })
        val t = Ui.vertical(a, 3)
        t.addView(Ui.text(a, "${sg.nom} · ${h.format(Date(sg.debut))} → ${h.format(Date(sg.fin))}", 15f, Ui.FG, true))
        t.addView(W.aide(a, "${sg.minutes.roundToInt()} min · " + listOf(sg.lieuDepart, sg.lieuArrivee)
            .map { it.substringBefore(" (").substringAfterLast(", ") }.filter { it.isNotBlank() && !it[0].isDigit() }.joinToString(" → ")))
        l.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        l.addView(Ui.text(a, "${Analyzer.fmt2(sg.km)} km", 15f, Ui.ACCENT, true).apply { setPadding(Ui.dp(a, 8), 0, 0, 0) })
        if (sel == null) l.addView(W.icone(a, R.drawable.ic_chevron, Ui.MUTED, 20))
        l.setOnClickListener { if (sel != null) basculer(sel, cle) else a.ouvrirSegment(sg) }
        l.setOnLongClickListener {
            if (sel != null) { basculer(sel, cle); return@setOnLongClickListener true }
            W.confirmer(a, "Supprimer ce trajet ?", "${sg.nom} · ${Analyzer.fmt2(sg.km)} km. C'est définitif.", "Supprimer") {
                store.deleteSegment(sg.debut); a.toast("Trajet supprimé"); a.afficher()
            }; true
        }
        return l
    }

    // ---------------------------------------------------------------- Suppression

    private fun barreSelection(sel: MutableSet<String>, rs: List<Ride>, sgs: List<Segment>): View {
        val c = W.carte(a)
        c.addView(Ui.text(a, if (sel.isEmpty()) "Touche les courses à supprimer" else "${sel.size} sélectionnée${if (sel.size > 1) "s" else ""}", 16f, Ui.FG, true))
        val tout = rs.map { "r${it.debut}" } + sgs.map { "s${it.debut}" }
        c.addView(Ui.buttonRow(a,
            W.bouton(a, if (sel.containsAll(tout) && tout.isNotEmpty()) "Tout désélectionner" else "Tout le mois") {
                if (sel.containsAll(tout)) sel.clear() else sel.addAll(tout); a.afficher()
            },
            W.bouton(a, "Annuler") { a.selection = null; a.afficher() }))
        if (sel.isNotEmpty()) c.addView(W.boutonDanger(a, "Supprimer (${sel.size})") {
            Suppression.plusieurs(a, store, sel.toSet()) { a.selection = null; a.afficher() }
        })

        return c
    }

    private fun supprimer(r: Ride) = Suppression.course(a, store, r) { a.afficher() }
}
