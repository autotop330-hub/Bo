package fr.bonnecourse

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import kotlin.math.roundToInt

/**
 * Trafic réel et itinéraires.
 *
 * Avec une clé TomTom (gratuite : 20 000 itinéraires et 20 000 adresses par mois, sans carte bancaire) :
 *  - temps de trajet avec les bouchons du moment, de la position du chauffeur au client, puis jusqu'à la destination ;
 *  - tracé des courses recalé sur les routes (à partir des positions GPS enregistrées).
 * Sans clé : trafic habituel selon le jour et l'heure (heures de pointe, nuit, week-end).
 */
object Trafic {

    /** Un trajet calculé : distance, durée avec trafic, minutes perdues dans les bouchons. */
    data class Trajet(val km: Double, val min: Double, val bouchonsMin: Double)

    /** Résultat pour une offre : approche (chauffeur → client) et course (client → destination). */
    data class Estimation(val approche: Trajet?, val course: Trajet?, val enDirect: Boolean, val note: String)

    private const val BASE = "https://api.tomtom.com"

    private fun get(url: String): JSONObject? = requete(url, null)

    private fun requete(url: String, corps: String?): JSONObject? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "BonneCourse/2 (Android)")
        if (corps != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(corps.toByteArray()) }
        }
        if (c.responseCode in 200..299) JSONObject(c.inputStream.bufferedReader().use { it.readText() }) else null
    } catch (_: Exception) { null }

    /** Adresse → position, en cherchant d'abord près d'un point connu (position du chauffeur, du client). */
    fun geocoder(cle: String, adresse: String, pres: Pair<Double, Double>?): Pair<Double, Double>? {
        if (adresse.isBlank()) return null
        val q = URLEncoder.encode(adresse.trim(), "UTF-8").replace("+", "%20")
        var url = "$BASE/search/2/geocode/$q.json?key=$cle&countrySet=FR&limit=1&language=fr-FR"
        if (pres != null) url += "&lat=${pres.first}&lon=${pres.second}"
        val r = get(url)?.optJSONArray("results")?.optJSONObject(0)?.optJSONObject("position") ?: return null
        return r.getDouble("lat") to r.getDouble("lon")
    }

    /** Itinéraire voiture le plus rapide avec le trafic en temps réel. */
    fun itineraire(cle: String, a: Pair<Double, Double>, b: Pair<Double, Double>): Trajet? {
        val url = "$BASE/routing/1/calculateRoute/${a.first},${a.second}:${b.first},${b.second}/json" +
            "?key=$cle&traffic=true&travelMode=car&routeType=fastest&routeRepresentation=summaryOnly"
        val s = get(url)?.optJSONArray("routes")?.optJSONObject(0)?.optJSONObject("summary") ?: return null
        return Trajet(s.optDouble("lengthInMeters", 0.0) / 1000.0, s.optDouble("travelTimeInSeconds", 0.0) / 60.0,
            s.optDouble("trafficDelayInSeconds", 0.0) / 60.0)
    }

    /**
     * Trafic réel pour une offre lue à l'écran.
     * @param ici position actuelle du chauffeur ; prise / depose : adresses lues sur l'offre
     */
    fun estimer(cle: String, ici: Pair<Double, Double>?, prise: String, depose: String): Estimation? {
        if (cle.isBlank()) return null
        val pPrise = geocoder(cle, prise, ici) ?: return null
        val app = if (ici != null) itineraire(cle, ici, pPrise) else null
        val pDepose = if (depose.isNotBlank()) geocoder(cle, depose, pPrise) else null
        val cou = if (pDepose != null) itineraire(cle, pPrise, pDepose) else null
        if (app == null && cou == null) return null
        val bouchons = (app?.bouchonsMin ?: 0.0) + (cou?.bouchonsMin ?: 0.0)
        val note = "Trafic en direct : " + listOfNotNull(
            app?.let { "approche ${it.min.roundToInt()} min" }, cou?.let { "course ${it.min.roundToInt()} min" }).joinToString(", ") +
            if (bouchons >= 1) " (dont ${bouchons.roundToInt()} min de bouchons)" else " · fluide"
        return Estimation(app, cou, true, note)
    }

    /**
     * Trafic habituel, sans connexion : coefficient sur la durée selon le jour et l'heure.
     * Semaine : pointe du matin 7 h–9 h 30 et du soir 16 h 30–19 h 30 ; nuit plus rapide ; samedi après-midi chargé.
     */
    fun facteurHoraire(cal: Calendar = Calendar.getInstance()): Double {
        val h = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
        val j = cal.get(Calendar.DAY_OF_WEEK)
        val semaine = j in Calendar.MONDAY..Calendar.FRIDAY
        return when {
            h < 6 || h >= 22 -> 0.85
            semaine && h in 7.0..9.5 -> 1.45
            semaine && h in 16.5..19.5 -> 1.5
            semaine && h in 9.5..16.5 -> 1.15
            j == Calendar.SATURDAY && h in 11.0..19.0 -> 1.2
            else -> 1.0
        }
    }

    fun libelleHoraire(f: Double) = when {
        f >= 1.4 -> "heure de pointe"
        f > 1.05 -> "circulation chargée"
        f < 0.95 -> "circulation de nuit, fluide"
        else -> "circulation normale"
    }

    // ---------------------------------------------------------------- Tracé recalé sur les routes

    /**
     * Reconstruit la route réellement suivie à partir des positions GPS (TomTom, « supporting points »).
     * Renvoie la suite de points [lat, lon] le long des routes, ou null.
     */
    fun recaler(cle: String, pts: List<Point>): List<Pair<Double, Double>>? {
        if (cle.isBlank() || pts.size < 2) return null
        // 150 points au plus, répartis sur tout le trajet
        val ech = if (pts.size <= 150) pts else (0 until 150).map { pts[it * (pts.size - 1) / 149] }
        val a = ech.first(); val b = ech.last()
        val corps = JSONObject().put("supportingPoints", JSONArray().apply {
            ech.forEach { put(JSONObject().put("latitude", it.lat).put("longitude", it.lon)) }
        }).toString()
        val url = "$BASE/routing/1/calculateRoute/${a.lat},${a.lon}:${b.lat},${b.lon}/json" +
            "?key=$cle&traffic=false&travelMode=car&routeType=fastest&routeRepresentation=polyline"
        val legs = requete(url, corps)?.optJSONArray("routes")?.optJSONObject(0)?.optJSONArray("legs") ?: return null
        val out = ArrayList<Pair<Double, Double>>()
        for (i in 0 until legs.length()) {
            val p = legs.getJSONObject(i).optJSONArray("points") ?: continue
            for (k in 0 until p.length()) p.getJSONObject(k).let { out += it.getDouble("latitude") to it.getDouble("longitude") }
        }
        return out.takeIf { it.size >= 2 }
    }

    /** Vérifie la clé (une recherche d'adresse). */
    fun tester(cle: String) = geocoder(cle, "Place de la Comédie, Montpellier", null) != null
}
