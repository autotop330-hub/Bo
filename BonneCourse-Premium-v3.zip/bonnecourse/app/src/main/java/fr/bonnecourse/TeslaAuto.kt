package fr.bonnecourse

import android.os.Handler
import android.os.Looper
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Automatismes Tesla pour l'activité VTC :
 *  - relevé du compteur et de la batterie à chaque étape (début/fin de service, course acceptée, client à bord, déposé, domicile) ;
 *  - recharges détectées et ajoutées aux frais (domicile ou borne rapide) ;
 *  - consommation réelle mesurée (kWh/100 km), utilisée pour juger les offres ;
 *  - autonomie comparée à la course proposée.
 */
object TeslaAuto {
    private val main = Handler(Looper.getMainLooper())

    /** Lit la voiture en arrière-plan, enregistre un relevé du [type] donné, puis rappelle [apres] (fil principal). */
    fun relever(store: Store, type: String?, note: String = "", apres: ((Tesla.Etat?) -> Unit)? = null) {
        if (!store.teslaActive) { apres?.let { main.post { it(null) } }; return }
        val jeton = store.teslaJeton; val vin = store.teslaVin
        Thread {
            val e = try { Tesla.lire(jeton, vin) } catch (_: Exception) { null }
            if (e != null) {
                store.derniereTesla = e
                if (type != null && e.odoKm != null)
                    store.addReleve(Releve(System.currentTimeMillis(), type, e.odoKm, e.batterie ?: -1.0, e.autonomieKm ?: -1.0,
                        e.lat ?: 0.0, e.lon ?: 0.0, e.maj, note))
                try { analyserRecharge(store, e) } catch (_: Exception) {}
            }
            apres?.let { main.post { it(e) } }
        }.start()
    }

    // ---------------------------------------------------------------- Recharges

    private const val RENDEMENT_AC = 0.90   // pertes de charge sur prise ou wallbox (~10 %)

    /**
     * Compare l'état actuel à la référence (dernier état hors charge) :
     * si la batterie a été rechargée entre les deux, ajoute la recharge aux frais.
     */
    fun analyserRecharge(store: Store, e: Tesla.Etat) {
        if (e.enCharge) return                     // on attend la fin de la charge
        val ref = store.teslaReference
        store.teslaReference = e
        if (ref == null || !store.rechargesAuto) return
        val cap = e.capaciteKwh ?: ref.capaciteKwh ?: 75.0
        var kwhDc = 0.0
        var kwhTotal = 0.0
        if (ref.chargeTotaleKwh != null && e.chargeTotaleKwh != null) {
            // Compteurs d'énergie de la voiture : mesure exacte
            kwhTotal = e.chargeTotaleKwh - ref.chargeTotaleKwh
            if (ref.chargeDcKwh != null && e.chargeDcKwh != null) kwhDc = (e.chargeDcKwh - ref.chargeDcKwh).coerceIn(0.0, kwhTotal)
        } else if (ref.batterie != null && e.batterie != null && e.batterie - ref.batterie >= 2.0) {
            // Sinon : hausse de la batterie × capacité (à 1 % près)
            kwhTotal = (e.batterie - ref.batterie) / 100.0 * cap
            if (e.rapide == true || ref.rapide == true) kwhDc = kwhTotal
            else if (!aDomicile(store, e)) kwhDc = kwhTotal    // hors domicile : borne publique
        }
        if (kwhTotal < 1.0) return
        val kwhAc = (kwhTotal - kwhDc).coerceAtLeast(0.0)
        val maintenant = System.currentTimeMillis()
        if (kwhAc >= 1.0) {
            val mur = kwhAc / RENDEMENT_AC
            store.addFrais(Frais(maintenant, maintenant, Categorie.RECHARGE, arrondi(mur * store.prixKwhDomicile), 0.0,
                "Auto Tesla · ${un(kwhAc)} kWh en batterie, ${un(mur)} kWh au compteur électrique (domicile, ${prix(store.prixKwhDomicile)}/kWh)"))
        }
        if (kwhDc >= 1.0) {
            store.addFrais(Frais(maintenant + 1, maintenant, Categorie.RECHARGE, arrondi(kwhDc * store.prixKwhBorne), 20.0,
                "Auto Tesla · ${un(kwhDc)} kWh sur borne rapide (${prix(store.prixKwhBorne)}/kWh) · montant à corriger avec la facture Superchargeur"))
        }
        e.odoKm?.let { store.addReleve(Releve(maintenant, "recharge", it, e.batterie ?: -1.0, e.autonomieKm ?: -1.0, e.lat ?: 0.0, e.lon ?: 0.0, e.maj,
            "+${un(kwhTotal)} kWh" + if (kwhDc >= 1) " dont ${un(kwhDc)} en charge rapide" else "")) }
    }

    private fun aDomicile(store: Store, e: Tesla.Etat): Boolean {
        val d = store.domicile ?: return false
        val la = e.lat ?: return false; val lo = e.lon ?: return false
        return Odometer.distanceM(la, lo, d.first, d.second) < 300
    }

    private fun arrondi(x: Double) = (x * 100).roundToInt() / 100.0
    private fun un(x: Double) = String.format(java.util.Locale.FRANCE, "%.1f", x)
    private fun prix(x: Double) = String.format(java.util.Locale.FRANCE, "%.2f €", x)

    // ---------------------------------------------------------------- Consommation réelle

    /** Consommation mesurée sur les services depuis [depuis] : (kWh/100 km, km mesurés), ou null si trop peu de données. */
    fun consommation(store: Store, depuis: Long): Pair<Double, Double>? {
        val r = store.releves().filter { it.t >= depuis && it.batterie >= 0 }
        val cap = store.derniereTesla?.capaciteKwh ?: 75.0
        var kwh = 0.0; var km = 0.0
        var debut: Releve? = null
        for (x in r) {
            when (x.type) {
                "debut_service" -> debut = x
                "recharge" -> debut = null                         // une recharge fausse le calcul : on repart
                "fin_service" -> {
                    val d = debut
                    if (d != null && x.odoKm > d.odoKm && d.batterie > x.batterie) {
                        km += x.odoKm - d.odoKm
                        kwh += (d.batterie - x.batterie) / 100.0 * cap
                    }
                    debut = null
                }
            }
        }
        if (km < 50) return null
        return kwh / km * 100 to km
    }

    /** Met à jour la consommation du profil (calcul des offres) avec la mesure des 30 derniers jours. */
    fun appliquerConso(store: Store) {
        if (!store.consoAuto) return
        val (c, km) = consommation(store, System.currentTimeMillis() - 30L * 24 * 3600_000) ?: return
        if (km < 100 || c !in 8.0..35.0) return
        val p = store.profile
        val arr = (c * 10).roundToInt() / 10.0
        if (abs(p.conso - arr) >= 0.1) store.profile = p.copy(conso = arr)
    }

    // ---------------------------------------------------------------- Bilan du mois au compteur

    /** Compteur Tesla sur un mois : premier et dernier relevé, km totaux, km en service (bulle lancée), le reste. */
    data class BilanCompteur(val premier: Releve, val dernier: Releve, val total: Double, val service: Double, val releves: Int) {
        val horsService get() = (total - service).coerceAtLeast(0.0)
    }

    fun bilanMois(store: Store, annee: Int, mois: Int): BilanCompteur? {
        val cal = java.util.Calendar.getInstance()
        val r = store.releves().filter {
            cal.timeInMillis = it.t
            cal.get(java.util.Calendar.YEAR) == annee && cal.get(java.util.Calendar.MONTH) + 1 == mois && it.odoKm > 0
        }.sortedBy { it.t }
        if (r.size < 2) return null
        var service = 0.0
        var debut: Releve? = null
        r.forEach { x ->
            if (x.type == "debut_service") debut = x
            if (x.type == "fin_service") { debut?.let { d -> if (x.odoKm >= d.odoKm) service += x.odoKm - d.odoKm }; debut = null }
        }
        return BilanCompteur(r.first(), r.last(), (r.last().odoKm - r.first().odoKm).coerceAtLeast(0.0), service, r.size)
    }

    // ---------------------------------------------------------------- Autonomie

    /** Alerte sur la tuile : (texte, gravité 0 = info, 1 = juste, 2 = insuffisante) ; null si pas de donnée récente. */
    fun autonomie(store: Store, kmOffre: Double): Pair<String, Int>? {
        val e = store.derniereTesla ?: return null
        val aut = e.autonomieKm ?: return null
        if (System.currentTimeMillis() - e.lu > 45 * 60_000L) return null
        val bat = e.batterie?.let { "${it.roundToInt()} %" } ?: ""
        val reste = aut - kmOffre
        return when {
            reste < 10 -> "🔋 $bat · ${aut.roundToInt()} km d'autonomie : pas assez pour cette course (${kmOffre.roundToInt()} km)" to 2
            reste < 40 -> "🔋 $bat · il restera ~${reste.roundToInt()} km après la course : recharge à prévoir" to 1
            else -> "🔋 $bat · ${aut.roundToInt()} km d'autonomie" to 0
        }
    }
}
