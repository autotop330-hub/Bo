package fr.bonnecourse

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Mise en page de la facture (A4, 595 × 842 points), aux couleurs de La Bonne Course : noir, or, ivoire.
 *
 * Mentions (France, 2026) :
 *  - vendeur : dénomination, forme, capital, siège, SIRET, RCS, n° de TVA intracommunautaire, n° au registre des VTC ;
 *  - client : nom ou dénomination, adresse ; SIREN s'il est professionnel (mention obligatoire depuis septembre 2026) ;
 *  - numéro unique et chronologique, date d'émission, date de la prestation ;
 *  - désignation, quantité, prix unitaire HT, taux et montant de TVA, totaux HT et TTC ;
 *  - date et mode de règlement, nature de l'opération (prestation de services), escompte ;
 *  - client professionnel : pénalités de retard et indemnité forfaitaire de 40 € ;
 *  - VTC : réservation préalable (date et heure), date, heure et lieu de prise en charge, prix convenu à la réservation.
 */
object FactureDessin {
    private val loc = Locale.FRANCE
    private val jour = SimpleDateFormat("dd/MM/yyyy", loc)
    private val heure = SimpleDateFormat("HH:mm", loc)
    private val heureS = SimpleDateFormat("HH:mm:ss", loc)

    private val NOIR = Color.parseColor("#14161A")
    private val OR = Color.parseColor("#B8892E")
    private val OR_TEXTE = Color.parseColor("#8A6418")
    private val IVOIRE = Color.parseColor("#FAF6EC")
    private val GRIS = Color.parseColor("#5B616B")
    private val TRAIT = Color.parseColor("#E3DAC4")
    private val VERT = Color.parseColor("#2E9E6B")

    private fun eur(x: Double) = String.format(loc, "%,.2f €", x)
    private fun lieu(s: String) = s.substringBefore(" (").trim()
    private fun ville(s: String) = lieu(s).substringAfterLast(", ").ifBlank { lieu(s) }

    /** Montants : (HT, TVA, TTC) à partir du prix TTC encaissé (TVA 10 % du transport de personnes). */
    fun montants(ttc: Double, tva: Boolean): Triple<Double, Double, Double> {
        if (!tva) return Triple(ttc, 0.0, ttc)
        val ht = Math.round(ttc / 1.10 * 100) / 100.0
        return Triple(ht, Math.round((ttc - ht) * 100) / 100.0, ttc)
    }

    fun dessiner(c: Canvas, e: Entreprise, p: Profile, r: Ride, f: Facture, logo: Bitmap?, signature: Bitmap?) {
        fun tp(size: Float, gras: Boolean = false, couleur: Int = NOIR, espace: Float = 0f) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; color = couleur; letterSpacing = espace
            typeface = if (gras) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        }
        fun layout(t: String, w: Float, paint: TextPaint, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL) =
            StaticLayout.Builder.obtain(t, 0, t.length, paint, max(1f, w).toInt()).setAlignment(align).setLineSpacing(1.2f, 1f).build()
        /** Texte sur plusieurs lignes ; renvoie la hauteur occupée. */
        fun bloc(t: String, x: Float, y: Float, w: Float, paint: TextPaint, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): Float {
            val l = layout(t, w, paint, align)
            c.save(); c.translate(x, y); l.draw(c); c.restore()
            return l.height.toFloat()
        }
        fun hauteur(t: String, w: Float, paint: TextPaint) = layout(t, w, paint).height.toFloat()
        fun rect(x0: Float, y0: Float, x1: Float, y1: Float, fond: Int, rayon: Float = 0f, contour: Int? = null) {
            val pf = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fond }
            if (rayon > 0) c.drawRoundRect(RectF(x0, y0, x1, y1), rayon, rayon, pf) else c.drawRect(x0, y0, x1, y1, pf)
            if (contour != null) c.drawRoundRect(RectF(x0, y0, x1, y1), rayon, rayon,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { color = contour; style = Paint.Style.STROKE; strokeWidth = 0.8f })
        }
        fun ligne(x0: Float, y0: Float, x1: Float, y1: Float, couleur: Int, ep: Float) =
            c.drawLine(x0, y0, x1, y1, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = couleur; strokeWidth = ep })
        fun etiquette(t: String, x: Float, y: Float, w: Float) = bloc(t.uppercase(), x, y, w, tp(7.5f, true, OR_TEXTE, 0.12f))

        val m = 36f
        val w = 595f - 2 * m
        val droite = m + w
        var y = m

        // ---------------------------------------------------------------- En-tête : logo, FACTURE, numéro
        var hLogo = 0f
        if (logo != null) {
            val k = minOf(150f / logo.width, 86f / logo.height)
            hLogo = logo.height * k
            c.drawBitmap(logo, null, RectF(m, y, m + logo.width * k, y + hLogo), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        } else {
            hLogo = bloc(e.raisonSociale.ifBlank { "La Bonne Course" }, m, y + 10, w * 0.5f, tp(20f, true))
        }
        val xd = m + w * 0.5f; val wd = w * 0.5f
        bloc("FACTURE", xd, y, wd, tp(28f, true, NOIR, 0.06f), Layout.Alignment.ALIGN_OPPOSITE)
        rect(droite - 110f, y + 38f, droite, y + 40.5f, OR)
        val infos = "N° ${f.numero}\nÉmise le ${jour.format(Date(f.emission))}\nCourse du ${jour.format(Date(r.priseEnCharge))}"
        val hInfos = hauteur(infos, wd - 24, tp(10f))
        rect(xd + 40f, y + 50f, droite, y + 50f + hInfos + 16, IVOIRE, 8f, TRAIT)
        val premiere = infos.substringBefore("\n")
        bloc(premiere, xd + 52f, y + 58f, wd - 64, tp(11f, true))
        bloc(infos.substringAfter("\n"), xd + 52f, y + 58f + hauteur(premiere, wd, tp(11f, true)), wd - 64, tp(9.5f, couleur = GRIS))
        y += max(hLogo, 50f + hInfos + 16) + 10
        ligne(m, y, droite, y, OR, 1.2f)
        y += 12

        // ---------------------------------------------------------------- Émetteur et client
        val wc = (w - 12) / 2
        val emetteurNom = e.raisonSociale.ifBlank { "(dénomination de la société)" }
        val emetteur = buildString {
            append(listOf(e.forme, e.capital.takeIf { it.isNotBlank() }?.let { "au capital de $it €" }).filterNotNull().joinToString(" "))
            if (e.adresse.isNotBlank()) append("\n").append(e.adresse)
            append("\nSIRET ").append(e.siret.ifBlank { "—" })
            if (e.rcs.isNotBlank()) append(" · RCS ").append(e.rcs)
            if (e.tvaIntra.isNotBlank()) append("\nTVA intracommunautaire ").append(e.tvaIntra)
            append("\nInscription au registre VTC n° ").append(e.evtc.ifBlank { "—" })
            listOf(e.tel, e.email).filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { append("\n").append(it.joinToString(" · ")) }
        }
        val cl = f.client
        val clientNom = cl.societe.ifBlank { cl.nom.ifBlank { "—" } }
        val client = buildString {
            if (cl.societe.isNotBlank() && cl.nom.isNotBlank()) append("À l'attention de ").append(cl.nom).append("\n")
            if (cl.siren.isNotBlank()) append("SIREN ").append(cl.siren).append("\n")
            if (cl.adresse.isNotBlank()) append(cl.adresse).append("\n")
            listOf(cl.email, cl.tel).filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { append(it.joinToString(" · ")).append("\n") }
            if (!cl.pro) append("Client particulier")
        }.trim()
        val pNom = tp(11f, true); val pTxt = tp(9f, couleur = Color.parseColor("#2A2D33"))
        val hE = 16 + hauteur(emetteurNom, wc - 26, pNom) + 3 + hauteur(emetteur, wc - 26, pTxt)
        val hC = 16 + hauteur(clientNom, wc - 26, pNom) + 3 + hauteur(client, wc - 26, pTxt)
        val hCartes = max(hE, hC) + 18
        listOf(Triple(m, "Émetteur", emetteurNom to emetteur), Triple(m + wc + 12, "Facturé à", clientNom to client)).forEach { (x, titre, contenu) ->
            rect(x, y, x + wc, y + hCartes, IVOIRE, 8f)
            rect(x, y, x + 3.5f, y + hCartes, OR)
            etiquette(titre, x + 14, y + 11, wc - 26)
            val hn = bloc(contenu.first, x + 14, y + 25, wc - 26, pNom)
            bloc(contenu.second, x + 14, y + 28 + hn, wc - 26, pTxt)
        }
        y += hCartes + 13

        // ---------------------------------------------------------------- Détail de la course
        // À gauche : prise en charge → dépose, reliées par un trait (comme un reçu de course).
        // À droite : réservation, distance, durée, véhicule.
        etiquette("Détail de la course · réservation préalable", m, y, w)
        y += 14
        val wg = w * 0.60f
        val xTxt = m + 36f
        val wTxt = wg - 36f - 12f
        val pEtape = tp(7.5f, true, OR_TEXTE, 0.1f)
        val pHeure = tp(10.5f, true)
        val pAdr = tp(9.5f, couleur = Color.parseColor("#2A2D33"))
        fun etape(titre: String, quand: String, adresse: String) = Triple(titre, quand, adresse.ifBlank { "—" })
        val etapes = listOf(
            etape("Prise en charge", "${jour.format(Date(r.priseEnCharge))} à ${heure.format(Date(r.priseEnCharge))}", lieu(r.lieuPrise)),
            etape("Dépose", "${jour.format(Date(r.fin))} à ${heure.format(Date(r.fin))}", lieu(r.lieuArrivee)))
        fun hEtape(e: Triple<String, String, String>) = 11f + hauteur(e.second, wTxt, pHeure) + 2 + hauteur(e.third, wTxt, pAdr)
        val chiffres = mutableListOf<Pair<String, String>>()
        if (f.reservation > 0) chiffres += "Réservée le" to "${jour.format(Date(f.reservation))} à ${heure.format(Date(f.reservation))}"
        chiffres += "Distance" to (if (r.kmCourse > 0) String.format(loc, "%.3f km", r.kmCourse) else "—")
        chiffres += "Durée" to "${r.minCourse.roundToInt()} min"
        chiffres += "Véhicule" to "Tesla Model Y électrique"
        val xd2 = m + wg + 14; val wd2 = droite - xd2 - 14
        val pChLab = tp(7.5f, true, OR_TEXTE, 0.1f); val pChVal = tp(10.5f, true)
        val wCase = (wd2 - 10) / 2
        val lignesCh = chiffres.chunked(2)
        val hRang = lignesCh.map { rang -> rang.maxOf { (_, b) -> 11f + hauteur(b, wCase, pChVal) } + 12 }
        val hDroite = hRang.sum()
        val hGauche = hEtape(etapes[0]) + 16 + hEtape(etapes[1])
        val hBloc = max(hGauche, hDroite) + 26
        rect(m, y, droite, y + hBloc, IVOIRE, 8f)
        ligne(m + wg, y + 14, m + wg, y + hBloc - 14, TRAIT, 1f)

        // Étapes avec leur pastille et le trait qui les relie
        var ye = y + 13
        val yPoints = mutableListOf<Float>()
        etapes.forEachIndexed { i, e ->
            yPoints += ye + 4
            bloc(e.first.uppercase(), xTxt, ye, wTxt, pEtape)
            val h1 = bloc(e.second, xTxt, ye + 11, wTxt, pHeure)
            val h2 = bloc(e.third, xTxt, ye + 13 + h1, wTxt, pAdr)
            ye += 13 + h1 + h2 + if (i == 0) 16 else 0
        }
        val xPt = m + 18f
        ligne(xPt, yPoints[0] + 6, xPt, yPoints[1] - 6, OR, 2f)
        c.drawCircle(xPt, yPoints[0], 5.5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = VERT })
        c.drawCircle(xPt, yPoints[0], 2.2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        c.drawRect(xPt - 5f, yPoints[1] - 5f, xPt + 5f, yPoints[1] + 5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = NOIR })

        // Chiffres clés
        var yc = y + 13
        lignesCh.forEachIndexed { i, rang ->
            rang.forEachIndexed { k, (lab, v) ->
                val xc = xd2 + k * (wCase + 10)
                bloc(lab.uppercase(), xc, yc, wCase, pChLab)
                bloc(v, xc, yc + 11, wCase, pChVal)
            }
            yc += hRang[i]
        }
        y += hBloc + 13

        // ---------------------------------------------------------------- Tableau
        val (ht, tva, ttc) = montants(r.prix, p.tva)
        val cols = floatArrayOf(m, m + w * 0.56f, m + w * 0.64f, m + w * 0.77f, m + w * 0.85f, droite)
        rect(m, y, droite, y + 22, NOIR, 4f)
        listOf("Désignation", "Qté", "P.U. HT", "TVA", "Montant HT").forEachIndexed { i, t ->
            bloc(t.uppercase(), cols[i] + 8, y + 7, cols[i + 1] - cols[i] - 16, tp(7.5f, true, OR, 0.1f),
                if (i == 0) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE)
        }
        y += 22
        val designation = "Transport particulier de personne en VTC sur réservation préalable\n" +
            "De ${ville(r.lieuPrise).ifBlank { "la prise en charge" }} à ${ville(r.lieuArrivee).ifBlank { "la destination" }}" +
            (if (r.kmCourse > 0) " · " + String.format(loc, "%.1f km", r.kmCourse) else "")
        val hd = bloc(designation, cols[0] + 8, y + 8, cols[1] - cols[0] - 12, tp(9.5f))
        listOf("1", eur(ht), if (p.tva) "10 %" else "—", eur(ht)).forEachIndexed { i, t ->
            bloc(t, cols[i + 1] + 4, y + 9, cols[i + 2] - cols[i + 1] - 12, tp(10f, i == 3), Layout.Alignment.ALIGN_OPPOSITE)
        }
        y += hd + 13
        ligne(m, y, droite, y, TRAIT, 1f)
        y += 11

        // ---------------------------------------------------------------- Totaux (droite) et règlement (gauche)
        val wt = 210f; val xt = droite - wt
        var yt = y
        fun total(lab: String, v: String) {
            bloc(lab, xt + 10, yt, wt * 0.55f, tp(10f, couleur = GRIS))
            bloc(v, xt + wt * 0.45f, yt, wt * 0.55f - 10, tp(10f), Layout.Alignment.ALIGN_OPPOSITE)
            yt += 17
        }
        total("Total HT", eur(ht))
        total(if (p.tva) "TVA 10 %" else "TVA", if (p.tva) eur(tva) else "0,00 €")
        rect(xt, yt + 2, droite, yt + 34, NOIR, 6f)
        bloc("TOTAL TTC", xt + 12, yt + 11, wt * 0.5f, tp(10f, true, OR, 0.1f))
        bloc(eur(ttc), xt + wt * 0.4f, yt + 8, wt * 0.6f - 12, tp(15f, true, Color.WHITE), Layout.Alignment.ALIGN_OPPOSITE)
        yt += 34
        bloc("Merci de votre confiance.", xt, yt + 12, wt, tp(11.5f, true, OR_TEXTE), Layout.Alignment.ALIGN_OPPOSITE)
        yt += 30

        // Colonne de gauche : règlement, puis signature du client
        val wl = w - wt - 24
        val reglement = "Réglée le ${jour.format(Date(r.fin))}" + (if (f.paiement.isNotBlank()) " par ${f.paiement.lowercase()}" else "") + ".\n" +
            "Prix convenu lors de la réservation.\nNature de l'opération : prestation de services."
        etiquette("Règlement", m, y, wl)
        var yg = y + 12 + bloc(reglement, m, y + 12, wl, tp(9f)) + 10
        etiquette("Signature du client · course effectuée", m, yg, wl)
        yg += 12
        val cadre = RectF(m, yg, m + 190f, yg + 62f)
        rect(cadre.left, cadre.top, cadre.right, cadre.bottom, Color.WHITE, 6f, TRAIT)
        if (signature != null) {
            val k = minOf((cadre.width() - 12) / signature.width, (cadre.height() - 10) / signature.height)
            val bw = signature.width * k; val bh = signature.height * k
            val x0 = cadre.centerX() - bw / 2; val y0 = cadre.centerY() - bh / 2
            c.drawBitmap(signature, null, RectF(x0, y0, x0 + bw, y0 + bh), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        if (f.signeLe > 0) bloc("Signée électroniquement\nle ${jour.format(Date(f.signeLe))}\nà ${heure.format(Date(f.signeLe))}",
            cadre.right + 8, yg + 8, wl - 198, tp(8f, couleur = GRIS))
        yg += 62f
        y = max(yt, yg) + 12

        val mentions = buildString {
            append("Pas d'escompte pour paiement anticipé.")
            if (!p.tva) append(" TVA non applicable, art. 293 B du CGI.")
            if (cl.pro) append(" En cas de retard de paiement : pénalités au taux de 3 fois le taux d'intérêt légal et indemnité forfaitaire " +
                "de 40 € pour frais de recouvrement (art. L441-10 du code de commerce).")
        }
        bloc(mentions, m, y, w, tp(7.5f, couleur = GRIS))

        // ---------------------------------------------------------------- Pied de page
        val yp = 842f - m - 20
        ligne(m, yp, droite, yp, OR, 0.8f)
        val pied = listOf(e.raisonSociale, e.forme + (if (e.capital.isNotBlank()) " au capital de ${e.capital} €" else ""),
            e.adresse.replace("\n", ", "), "SIRET ${e.siret}", e.rcs.takeIf { it.isNotBlank() }?.let { "RCS $it" },
            e.tvaIntra.takeIf { it.isNotBlank() }?.let { "TVA $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" · ")
        bloc("$pied\nFacture ${f.numero} · page 1/1", m, yp + 5, w, tp(7f, couleur = GRIS), Layout.Alignment.ALIGN_CENTER)
    }
}
