package fr.bonnecourse

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Facture PDF d'une course privée et envoi par Outlook.
 *
 * Mentions : vendeur (dénomination, forme, capital, siège, SIRET, RCS, TVA intracommunautaire),
 * n° d'inscription au registre VTC, client (et son SIREN s'il est professionnel), numéro unique
 * chronologique, dates d'émission et de la prestation, désignation, quantité, prix unitaire HT,
 * taux et montant de TVA, totaux HT et TTC, date et mode de paiement, catégorie de l'opération
 * (prestation de services), pénalités de retard et indemnité de 40 € pour un client professionnel,
 * réservation préalable (date et heure de réservation, de prise en charge et lieu).
 */
object FacturePdf {
    const val AUTORITE = "fr.bonnecourse.fichiers"
    const val OUTLOOK = "com.microsoft.office.outlook"
    const val TVA_VTC = 10.0

    private val loc = Locale.FRANCE
    private val jour = SimpleDateFormat("dd/MM/yyyy", loc)
    private val heure = SimpleDateFormat("HH:mm", loc)

    fun dossier(ctx: Context) = File(ctx.filesDir, "factures").apply { mkdirs() }

    /** Logo choisi dans les Réglages, sinon le logo La Bonne Course fourni avec l'appli. */
    fun fichierLogo(ctx: Context) = File(ctx.filesDir, "logo.png")

    fun logo(ctx: Context): android.graphics.Bitmap? = try {
        val f = fichierLogo(ctx)
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)
        else BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_facture)
    } catch (_: Exception) { null }
    fun fichier(ctx: Context, numero: String) = File(dossier(ctx), "Facture-$numero.pdf")

    private fun eur(x: Double) = String.format(loc, "%,.2f €", x)
    private fun lieu(s: String) = s.substringBefore(" (").ifBlank { s }

    fun montants(ttc: Double, tva: Boolean) = FactureDessin.montants(ttc, tva)

    /** Crée (ou recrée, après modification du client) le PDF de la facture. */
    fun creer(ctx: Context, e: Entreprise, p: Profile, r: Ride, f: Facture): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val sig = f.signature.takeIf { it.isNotBlank() }?.let { BitmapFactory.decodeFile(it) }
        FactureDessin.dessiner(page.canvas, e, p, r, f, logo(ctx), sig)
        doc.finishPage(page)
        val out = fichier(ctx, f.numero)
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
        return out
    }

    /** Facture d'exemple (fausse course), pour vérifier le logo et les infos de la société. */
    fun exemple(ctx: Context, e: Entreprise, p: Profile): File {
        val t = System.currentTimeMillis()
        val r = Ride(t - 50 * 60000, t - 40 * 60000, t - 5 * 60000, 1.2, 18.4, 45.0,
            lieuPrise = "Gare Saint-Roch, Montpellier", lieuArrivee = "Aéroport Montpellier Méditerranée, Mauguio", type = "prive")
        val f = Facture("EXEMPLE", r.debut, t, Client("Marie Exemple", adresse = "1 place de la Comédie, 34000 Montpellier", email = "marie@exemple.fr"),
            "Carte bancaire", t - 24 * 3600_000L, "", 0L)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        FactureDessin.dessiner(page.canvas, e, p, r, f, logo(ctx), null)
        doc.finishPage(page)
        val out = File(dossier(ctx), "Facture-EXEMPLE.pdf")
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
        return out
    }

    // ------------------------------------------------------------------ Envoi

    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, AUTORITE, f)

    fun outlookInstalle(ctx: Context) = try { ctx.packageManager.getPackageInfo(OUTLOOK, 0); true } catch (_: Exception) { false }

    /** Le message de sympathie, à partir du modèle de la société. */
    fun message(e: Entreprise, r: Ride, f: Facture): String = e.message
        .replace("{client}", f.client.appel.ifBlank { "Madame, Monsieur" })
        .replace("{numero}", f.numero)
        .replace("{date}", jour.format(Date(r.priseEnCharge)))
        .replace("{depart}", lieu(r.lieuPrise).substringAfterLast(", ").ifBlank { "départ" })
        .replace("{arrivee}", lieu(r.lieuArrivee).substringAfterLast(", ").ifBlank { "arrivée" })
        .replace("{chauffeur}", e.chauffeur)
        .replace("{societe}", e.raisonSociale)
        .replace("{telephone}", e.tel)
        .replace(Regex("\n{3,}"), "\n\n").trim()

    fun objet(r: Ride, f: Facture) = "Votre facture ${f.numero} · course du ${jour.format(Date(r.priseEnCharge))}"

    /** Ouvre Outlook avec le PDF déjà joint, l'adresse du client, l'objet et le message. Sinon, le choix de l'appli. */
    fun envoyer(a: Activity, pdf: File, e: Entreprise, r: Ride, f: Facture) {
        val u = uri(a, pdf)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, u)
            if (f.client.email.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(f.client.email.trim()))
            putExtra(Intent.EXTRA_SUBJECT, objet(r, f))
            putExtra(Intent.EXTRA_TEXT, message(e, r, f))
            clipData = ClipData.newRawUri("Facture", u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            a.startActivity(Intent(base).setPackage(OUTLOOK))
        } catch (_: ActivityNotFoundException) {
            a.startActivity(Intent.createChooser(base, "Envoyer la facture"))
        }
    }

    fun ouvrir(a: Activity, pdf: File) {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri(a, pdf), "application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { a.startActivity(i) } catch (_: ActivityNotFoundException) {
            android.widget.Toast.makeText(a, "Aucune appli pour lire les PDF sur ce téléphone", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
