package fr.bonnecourse

import kotlin.math.abs

/**
 * Transforme le texte lu à l'écran en offre de course.
 *
 * Exemples de textes reconnus :
 *   Uber   : "14,20 €"  "À 7 min (3,1 km)"  "Course de 18 min (8,4 km)"  ou  "Course de 21.1 km" (sans durée)
 *   Bolt   : "14,20 €"  "7 min · 3,1 km"     "18 min · 8,4 km"  ou  "Asnières-sur-Seine • 25.7 km" (sans durée)
 *   Heetch : "3,1 km - 7 min" ... ou n'importe quel ordre km / min
 *
 * La 1re distance trouvée = l'approche, la plus longue des suivantes = la course.
 * Une distance sans durée à côté reçoit une durée estimée.
 */
object OfferParser {

    data class Parsed(val offer: Offer?, val erreur: String?)

    private data class Tok(val pos: Int, val value: Double)

    private val PRIX = Regex("""(\+\s*)?(\d{1,3}(?:[.,]\d{1,2})?)\s*(€|EUR|CHF)|(€|CHF)\s*(\d{1,3}(?:[.,]\d{1,2})?)""")
    private val KM = Regex("""(\d{1,3}(?:[.,]\d{1,2})?)\s*km""", RegexOption.IGNORE_CASE)
    private val METRES = Regex("""\b(\d{2,4})\s?m\b""")
    private val HEURE_MIN = Regex("""\b(\d{1,2})\s*h\s*(\d{1,2})(?:\s*min\w*)?""", RegexOption.IGNORE_CASE)
    private val MIN = Regex("""\b(\d{1,3})\s*min""", RegexOption.IGNORE_CASE)

    private fun num(s: String) = s.replace(',', '.').toDouble()

    /** Lit l'offre, puis les adresses du client et de la destination (pour le trafic réel). */
    fun parse(raw: String): Parsed {
        val p = parseChiffres(raw)
        val o = p.offer ?: return p
        val a = adresses(raw)
        return p.copy(offer = o.copy(prise = a.getOrElse(0) { "" }, depose = if (a.size >= 2) a.last() else ""))
    }

    private val CP = Regex("\\b\\d{5}\\b")
    private val VOIE = Regex("\\b(rue|bd|boulevard|avenue|av\\.?|place|pl\\.|chemin|route|rte|allée|allee|quai|impasse|cours|esplanade|square|aéroport|aeroport|gare|terminal|zac|za|rond-point)\\b", RegexOption.IGNORE_CASE)
    private val BRUIT = Regex("[•·]?\\s*\\d+(?:[.,]\\d+)?\\s*(?:km|min)\\b.*$", RegexOption.IGNORE_CASE)

    /**
     * Adresses lues sur l'offre, dans l'ordre (client puis destination).
     * Une ligne d'adresse a un code postal, ou un mot de voie et une virgule (« 6 Rue Yvonne De Gaulle, Asnières »).
     * Les noms de rue seuls (étiquettes de la carte) sont ignorés. Une ligne coupée par « - » est recollée.
     */
    fun adresses(raw: String): List<String> {
        val lignes = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val recollees = mutableListOf<String>()
        var i = 0
        while (i < lignes.size) {
            var l = lignes[i]
            while (l.endsWith("-") && i + 1 < lignes.size) { i++; l += lignes[i] }
            recollees += l; i++
        }
        return recollees.mapNotNull { l0 ->
            if ('€' in l0) return@mapNotNull null
            val l = l0.replace(BRUIT, "").replace(Regex("^(à|a)\\s+\\d+\\s*min.*?\\)\\s*", RegexOption.IGNORE_CASE), "").trim().trimEnd(',', '•', '·').trim()
            val ok = CP.containsMatchIn(l) || (VOIE.containsMatchIn(l) && ',' in l)
            if (ok && l.length >= 8) l else null
        }
    }

    private fun parseChiffres(raw: String): Parsed {
        val t = raw.replace(' ', ' ').replace(' ', ' ')

        // Prix : le plus gros montant, hors suppléments "+2,00 € inclus"
        val prix = PRIX.findAll(t).mapNotNull { m ->
            if (m.groupValues[1].isNotBlank()) null
            else (m.groupValues[2].ifEmpty { m.groupValues[5] }).let { if (it.isEmpty()) null else num(it) }
        }.filter { it in 2.0..999.0 }.maxOrNull()
            ?: return Parsed(null, "Prix non trouvé à l'écran")

        // Distances
        val dist = mutableListOf<Tok>()
        KM.findAll(t).forEach { dist += Tok(it.range.first, num(it.groupValues[1])) }
        METRES.findAll(t).forEach { dist += Tok(it.range.first, it.groupValues[1].toDouble() / 1000.0) }
        dist.sortBy { it.pos }

        // Durées (les "1 h 05" d'abord, pour ne pas les recompter comme "05 min")
        val dur = mutableListOf<Tok>()
        val prises = mutableListOf<IntRange>()
        HEURE_MIN.findAll(t).forEach {
            dur += Tok(it.range.first, it.groupValues[1].toDouble() * 60 + it.groupValues[2].toDouble())
            prises += it.range
        }
        MIN.findAll(t).forEach { m ->
            if (prises.none { m.range.first in it }) dur += Tok(m.range.first, m.groupValues[1].toDouble())
        }

        // Chaque distance est une étape (approche puis course), avec la durée la plus proche dans le texte si elle existe.
        // Uber et Bolt n'affichent souvent pas la durée de la course (« Course de 21.1 km », « • 25.7 km ») : elle est alors estimée.
        val utilisees = mutableSetOf<Int>()
        val etapes = mutableListOf<Etape>()
        for (d in dist) {
            if (d.value <= 0.0 || d.value > 400) continue
            fun ligne(pos: Int) = t.substring(0, pos.coerceIn(0, t.length)).count { it == '\n' }
            val libres = dur.withIndex().filter { it.index !in utilisees }
            // D'abord une durée sur la même ligne (« 5 min • 1.1 km », « à 2 min (0.4 km) »)…
            val best = libres.filter { ligne(it.value.pos) == ligne(d.pos) }.minByOrNull { abs(it.value.pos - d.pos) }
                // …sinon la plus proche, à condition qu'elle ne soit pas sur la ligne d'une autre distance
                ?: libres.filter { dt -> abs(dt.value.pos - d.pos) <= 30 && dist.none { o -> o !== d && ligne(o.pos) == ligne(dt.value.pos) } }
                    .minByOrNull { abs(it.value.pos - d.pos) }
            if (best != null) utilisees += best.index
            etapes += Etape(d.pos, d.value, best?.value?.value)
        }
        if (etapes.isEmpty()) return Parsed(null, "Distances non trouvées à l'écran")

        // Une seule étape : c'est la course si le texte le dit (« Course de… »), sinon on ne sait pas
        if (etapes.size == 1) {
            val e = etapes[0]
            return Parsed(Offer(prix, 0.0, 0.0, e.km, e.min ?: estimerMinutes(e.km), approcheLue = false, dureeEstimee = e.min == null), null)
        }
        // Plusieurs : la 1re = l'approche, la plus longue des suivantes = la course
        val app = etapes[0]
        val course = etapes.drop(1).maxByOrNull { it.km }!!
        return Parsed(Offer(prix, app.km, app.min ?: estimerMinutes(app.km), course.km, course.min ?: estimerMinutes(course.km),
            dureeEstimee = course.min == null || app.min == null), null)
    }

    private data class Etape(val pos: Int, val km: Double, val min: Double?)

    /**
     * Durée estimée quand l'offre ne l'affiche pas : vitesse moyenne selon la distance
     * (ville, périphérie, voie rapide), avec un minimum de 3 minutes.
     */
    fun estimerMinutes(km: Double): Double {
        val vitesse = when {
            km < 3 -> 18.0
            km < 8 -> 25.0
            km < 15 -> 32.0
            km < 30 -> 40.0
            else -> 55.0
        }
        return maxOf(3.0, Math.round(km / vitesse * 60).toDouble())
    }
}

/** Reconnaît la plateforme d'après le texte lu sur l'offre. null si rien ne la nomme. */
object Plateforme {
    val TOUTES = listOf("Uber", "Bolt", "Heetch", "FreeNow")

    fun detecter(texte: String): String? {
        val t = texte.lowercase()
        return when {
            "bolt" in t -> "Bolt"
            "heetch" in t -> "Heetch"
            "free now" in t || "freenow" in t -> "FreeNow"
            "uber" in t || Regex("\\b(comfort|green|berline|van)\\b").containsMatchIn(t) -> "Uber"
            else -> null
        }
    }
}
