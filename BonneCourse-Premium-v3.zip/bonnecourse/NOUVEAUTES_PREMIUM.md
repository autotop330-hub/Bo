# La Bonne Course · Premium 3.0

## Nouveautés de cette version

Cette livraison modifie **le code de l'application Android réelle**, et non une image de concept.

- **Identité « Obsidian / Champagne »** : fonds bleu nuit, or champagne, cartes plus fines, typographie et contrastes harmonisés ; identité graphique d'origine conservée pour les factures et les ressources.
- **Accueil façon cockpit** : marque compacte, état « en ligne / hors ligne », priorité aux chiffres de la journée, raccourcis *Activer l'assistant*, *Course privée*, *Saisie manuelle* ; explications et options de trafic repliables.
- **Statistiques intelligibles** : chiffre d'affaires du jour, net estimé et CA/h clairement distingués ; progression et taux d'occupation ; détail kilométrique accessible sans surcharge initiale.
- **Bulle Uber / Bolt** : mise en avant du net estimé et du revenu horaire avec deux blocs lisibles, au lieu des quatre colonnes trop petites ; rentabilité et €/km en seconde lecture.
- **Navigation** : barre inférieure harmonisée ; toucher l'onglet déjà actif remonte au début ; changement de mois depuis un sélecteur mois/année au milieu de la barre.
- **Courses** : filtres horizontaux utilisables même avec beaucoup de plateformes ; affichage progressif de 7 jours et chargement d'autres journées sur demande ; le mode sélection protège contre la suppression déclenchée par appui long.
- **Dépenses** : état vide orientant vers une action, lignes de dépenses cliquables, meilleur contraste et bloc de total.
- **Analyse** : montant présenté explicitement comme estimation, non comme somme réellement disponible ; messages plus prudents sur les hypothèses.
- **Réglages** : regroupement en sections claires : entreprise, véhicule/traffic, rentabilité/fiscalité et outils ; vue d'ensemble rapide.
- **Interactions** : zones tactiles plus grandes, retour d'appui sur les boutons, descriptions d'accessibilité.

## Ce qui est conservé

Le package Android (`fr.bonnecourse`), le stockage, les modèles métier, la clé de signature, les exports CSV, le GPS, la bulle, le suivi Tesla, les factures et la configuration de l'activité. La version Android passe de **2** à **3** pour permettre l'installation comme mise à jour sans désinstallation lorsque l'APK est compilé avec la clé incluse.

## Générer l'APK

Le ZIP est un **projet source Android**. Pour le compiler :

1. Ouvrir le dossier `bonnecourse` dans Android Studio (SDK Android 34 et JDK 17), puis exécuter `:app:assembleRelease`.
2. Ou pousser le contenu du dossier sur GitHub puis lancer le workflow **Construire l'APK** dans *Actions* (qui produit une Release téléchargeable).

**Vérification dans ce contexte :** inspection de la structure du projet et contrôle des sources ; compilation complète Android et essai sur téléphone **non effectués ici**, faute de SDK Android / Gradle installés. Il faut vérifier la compilation puis les écrans sur le téléphone avant usage en service.

**Important :** le projet contient la clé de signature originale `bonnecourse.keystore` avec sa configuration. Ne pas publier cette clé dans un dépôt public.
